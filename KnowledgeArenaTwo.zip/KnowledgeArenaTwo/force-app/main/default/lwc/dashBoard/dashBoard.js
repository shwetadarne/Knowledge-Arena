import { LightningElement } from 'lwc';

export default class DashBoard extends LightningElement {}