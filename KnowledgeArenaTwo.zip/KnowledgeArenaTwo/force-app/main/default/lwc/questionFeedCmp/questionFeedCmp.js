import { LightningElement,track,wire,api } from 'lwc';

import getUserDetails from '@salesforce/apex/enterQuestionDetails.getUserDetails';
import getAllFacts from '@salesforce/apex/enterQuestionDetails.getAllFacts';

//import getSearchedTags from '@salesforce/apex/knowledgeArena.getSearchedTags';
//import getAllQuestionsForTag from '@salesforce/apex/enterQuestionDetails.getAllQuestionsForTag';
import {CurrentPageReference} from 'lightning/navigation'
import { fireEvent } from 'c/pubsub';
import { registerListener,unregisterAllListeners } from 'c/pubsub';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Category__c from '@salesforce/schema/Question__c.Category__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Question_OBJECT from '@salesforce/schema/Question__c';
//import getTagsForEachQuestion from '@salesforce/apex/enterQuestionDetails.getTagsForEachQuestion';



import postFact from '@salesforce/apex/factController.postFact';
import insertQuestion from '@salesforce/apex/factController.insertQuestion';
//import getListOfQuestion from '@salesforce/apex/factController.getListOfQuestion';
import getListOfQuestionCat from '@salesforce/apex/factController.getListOfQuestionCat';
import getListOfQuestionTag from '@salesforce/apex/factController.getListOfQuestionTag';
import getSearchedTags from '@salesforce/apex/factController.getSearchedTags';
import getListOfQuestionTagCat from '@salesforce/apex/factController.getListOfQuestionTagCat';
// import getQuestionTags from '@salesforce/apex/factController.getQuestionTags';

import allTagList from '@salesforce/apex/factController.getAllTags';
import getTag from '@salesforce/apex/factController.getTag';

import getListOfFact from '@salesforce/apex/factController.getListOfFact';  
import getListOfFactCat from '@salesforce/apex/factController.getListOfFactCat';
import getListOfFactTag from '@salesforce/apex/factController.getListOfFactTag';
import getListOfQuestionClickTag from '@salesforce/apex/factController.getListOfQuestionClickTag';
import alllQuestionMethods from '@salesforce/apex/QuestionTagController.alllQuestionMethods';



import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import SystemModstamp from '@salesforce/schema/Account.SystemModstamp';
export default class QuestionFeedCmp extends LightningElement {
   
    isShowModal=false;
    @track
    askedSubQuestion;
    @track
    askedQuestion;
    //@wire(getUserDetails)allQuestions;
    description;
    postedQuestion;
    postedSubQuestion;
    @track
    QAValue;
    HomeValue;
    FactValue;
    allQuestions;
    @track
    QuestionFeed=[];
    searchedRecords=[];
    searchedFactRecords=[];
    recordId;
    onlySearchedQuestion=[];
    onlySearchedFact=[];
    giveAnswerOpenModal;
    publisherName;
    qList;
    allTags;
    holdsLazyLoading=[];
    lazyLoadingAll=[]
    @track alreadyLoadedData=[];
    @track alreadyLoadFact=[];
    @track alreadyLoadedQuestion=[];
    onlyQuestions=[];
    onlyFacts=[];
    //index for lazy loading
    indexAlreadyLoadedData = 0;
    indexAlreadyLoadedQuestion = 0;
    indexAlreadyLoadedFact=0;
    
    @api payload;
    @wire(CurrentPageReference)pageRef;

    isShowqaTab=false;
    isShowHomeTab=false;
    isShowFactTab=false;
    hasSearchResults=false;
    allTagsForQuestion;
    questionIdForTags;
    allQueBaseOnTag;
    tagggggggggg=true;
    showTages=false;
    fromHeaderOffset;
    Offset=0;
    offSetMore=false;
    showLoaded=false;
    showSearchedRecords=false;
    isQuestion=false;
    isFact=false;
    @track allFacts = [];
    @track inputTag;
    tagWrapper={};
    @track questionTagWrapper;


    // tagOnClickHandler(event){
    //     this.questionIdForTags=event.target.value;
    //     console.log('answer id for tags '+this.questionIdForTags);
    //      getAllQuestionsForTag({AllTagesForQue:this.questionIdForTags})
    //      .then(result=>{
    //         this.allQueBaseOnTag=result;
    //         console.log('question of tag  '+this.allQueBaseOnTag);
    //         this.tagggggggggg = false;
    //         this.showTages=true;
    //       console.log('in result');
    //       console.log(result);
    //  })
    //  .catch(error=>{
    //       console.error(error);
    //   })
    // }

    getFeed(){
        this.alreadyLoadedData=[];
        this.questionTag=[];
            alllQuestionMethods()
            .then(result=>{
                console.log('result'+result.successRespObj);
                console.log(result);
               // console.log('Parse' +JSON.parse(result.successRespObj));
                this.questionTagWrapper=result.successRespObj;
                
                //console.log('resultWrapper'+this.questionTagWrapper[15].tagWrapper);
         })
         .catch(error=>{
              console.error(error);
          })  
       }

    
    //    resultString()
    //    {

    //    }



       getFactFeed(){
        this.alreadyLoadedData=[];
        this.fact=[];
        getAllFacts()
        .then(result=>{
            this.allFacts=result;
    
            console.log('all facts  '+this.allFacts);
            
     })
     .catch(error=>{
          console.error(error);
      })  
       }
    
    
    
       publisherOnClick(event){
        this.publisherName=event.target.id;
        this.payload=this.publisherName;
        console.log('publisher id  '+this.publisherName);
        fireEvent(this.pageRef,"Publisher",this.payload);
    
       }
       giveAnswerClick(event){
          
            this.recordId=event.target.value;
            console.log('the id'+this.recordId);
            this.payload=this.recordId;
            this.giveAnswerOpenModal=true;
            fireEvent(this.pageRef,"AnswerOpenModal",this.giveAnswerOpenModal);
            fireEvent(this.pageRef,"userPublisher",this.payload);
    
       }
       connectedCallback(){
        registerListener("myfirstpubsub",this.getSearchedRecord,this);
        registerListener("mysecpubsub",this.getSearchedFactRecord,this);
        registerListener("soslQuestionEvent",this.getQuestionRecord,this);
        registerListener("soslFactEvent",this.getFactRecord,this);
        registerListener("tabEvent",this.QATab,this);
        registerListener("tabEventHome",this.homeTab,this);
        registerListener("tabEventFact",this.factTab,this);
        registerListener("searchOrQaFeed",this.booleansearchValue,this);
        registerListener("filterAllEvent",this.onlyAll,this);
        registerListener("filterqaEvent",this.onlyQuestion,this);
        registerListener("filterFactEvent",this.onlyFact,this);
        //registerListener("myOffsetAfter",this.afterOffset,this);
        this.getFeed();
        this.getFactFeed();
       }
       onlyAll(eventData){
            if(eventData==true){
                this.onlySearchedQuestion=[];
                this.onlySearchedFact=[];
            }
       }
       onlyQuestion(eventData){
            if(eventData==true){
                this.searchedRecords=[];
                this.searchedFactRecords=[];
                this.onlySearchedFact=[];
            }
       }
       onlyFact(eventData){
            if(eventData==true){
                this.searchedRecords=[];
                this.searchedFactRecords=[];
                this.onlySearchedQuestion=[];
            }
    
       }
       getSearchedRecord(eventData){
        this.showSearchedRecords=true;
        for(let i=0;i<eventData.length;i++){
            this.holdsLazyLoading.push({...eventData[i], icon: 'utility:question'});
        }
        //this.concatAlreadyLoadedData(this.holdsLazyLoading);
            
       }
       getSearchedFactRecord(eventData){
        
        for(let i=0;i<eventData.length;i++){
            this.lazyLoadingAll.push({...eventData[i], icon: 'utility:bookmark_alt'});
        }
        console.log('in facts'+this.lazyLoadingAll);
        this.concatAlreadyLoadedData(this.holdsLazyLoading);
    }
    
    concatAlreadyLoadedData(list){
        const temp = list.slice(this.indexAlreadyLoadedData, this.indexAlreadyLoadedData+2);
        console.log('temp'+temp);
        console.log(this.alreadyLoadedData);
        this.alreadyLoadedData = this.alreadyLoadedData.concat(temp);
        console.log(this.alreadyLoadedData);
        this.indexAlreadyLoadedData += 2;
        console.log('this.holdsLazyLoading = ');
        console.log(this.holdsLazyLoading);
        console.log('this.indexAlreadyLoadedData = ');
        console.log(this.alreadyLoadedData);
    }
    getQuestionRecord(eventData){
        this.holdsLazyLoading=[];
        this.lazyLoadingAll=[];
        this.isQuestion=true;
        this.onlySearchedQuestion=eventData;
        console.log('onlySearched'+onlySearchedQuestion);
        for(let i=0;i<this.onlySearchedQuestion.length;i++){
            this.onlyQuestions.push({...onlySearchedQuestion[i], icon: 'utility:question'});
        }
        //this.concatAlreadyLoadedData(this.onlyQuestions);
    }
    getFactRecord(eventData){
        this.onlySearchedFact=eventData;
        this.holdsLazyLoading=[];
        this.lazyLoadingAll=[];
        console.log('onlyfactSearched'+onlySearchedFact);
        // for(let i=0;i<this.onlySearchedFact.length;i++){
        //     this.lazyLoadingAll.push({...onlySearchedFact[i], icon: 'utility:bookmark_alt'});
        // }
    }
    QATab(eventData){
        this.QAValue=eventData;
        console.log('this home tab value  '+this.QAValue);
        if(this.QAValue=='tab-2'){
            this.isShowqaTab=true;
            this.searchTag=[];
            console.log('value:'+this.isShowqaTab);
            this.isShowHomeTab=false;
            this.isShowFactTab=false;
        }
    
    }
    homeTab(eventData){
        this.HomeValue=eventData;
        console.log('this home tab value  '+this.HomeValue);
        if(this.HomeValue=='tab-1'){
            this.isShowHomeTab=true;
            
            console.log('value:'+this.isShowHomeTab);
            this.isShowqaTab=false;
            this.isShowFactTab=false;
        }
    }
    factTab(eventData){
        this.FactValue=eventData;
        console.log('this home tab value  '+this.FactValue);
        if(this.FactValue=='tab-3'){
            this.searchTag=[];
            this.isShowFactTab=true;
            console.log('value:'+this.isShowFactTab);
            this.isShowqaTab=false;
            this.isShowHomeTab=false;
        }
    
    }
    booleansearchValue(eventData){
        this.hasSearchResults=eventData;
        console.log('search boolean'+this.hasSearchResults);
        if(this.hasSearchResults==true){
            this.allQuestions=[];
        }
    
    }
    afterOffset(eventData){
        this.fromHeaderOffset=eventData;
        console.log('from heder offset'+fromHeaderOffset);
    }
    factsStarted=false;
    
    
    handleScroll(event){
        console.log('scrollTop'+event.target.scrollTop);
        this.scrollTopValue=Math.floor(event.target.scrollTop);
    
        console.log(this.scrollTopValue);
        console.log('offsetHeight'+event.target.offsetHeight);
        this.scrollOffSetHeight=event.target.offsetHeight;
        console.log(this.scrollOffSetHeight);
        console.log('scrollHeight'+event.target.scrollHeight);
        this.scrollHeightValue=event.target.scrollHeight;
        console.log(this.scrollHeightValue);
        if((((this.scrollHeightValue-this.scrollOffSetHeight)+1)===this.scrollTopValue)||(((this.scrollHeightValue-this.scrollOffSetHeight)+2)===this.scrollTopValue)){
            //this.holdsLazyLoading.push(this.searchedFactRecords);
            this.showLoaded=true;
            this.showSearchedRecords=false;
            //this.Offset=this.Offset+2;
            console.log('offset qfeed fire before'+this.Offset);
            //fireEvent(this.pageRef,"offsetEvent",this.Offset);
            console.log('offset after scrolling'+this.Offset);
            // this.searchedRecords=[];
            // this.searchedFactRecords=[];
            if(this.indexAlreadyLoadedData >= this.holdsLazyLoading.length || this.factsStarted){
                if(!this.factsStarted){
                    this.indexAlreadyLoadedData = 0;
                    this.factsStarted = true;
                }
                this.concatAlreadyLoadedData(this.lazyLoadingAll);
            }else{
                this.concatAlreadyLoadedData(this.holdsLazyLoading);
            }
            //this.concatAlreadyLoadedQuestion(this.onlyQuestions);
            //this.concatAlreadyLoadedDataFact();
        }
        else if(this.Offset>(this.searchedRecords.length+this.searchedFactRecords.length)){
            console.log(this.Offset);
            console.log('end');
            for(let i=0;i<this.holdsLazyLoading.length;i++){
                console.log(this.holdsLazyLoading[i].Question_Header__c);
            }
            console.log(this.holdsLazyLoading);
            this.searchedRecords=[];
            this.searchedFactRecords=[];
            //console.log(this.holdsLazyLoading);
            //fireEvent(this.pageRef,"stopOffSet",this.Offset);
        }
        
        
    }






     showModal(event){
        this.isShowModal=true;
        this.allValues1=[];
        this.containsTag=null;
        this.containsAllTags=[];
    }
   hideModalBox() {  
       this.isShowModal = false;
       
    }
   questionSubHandleChange(event){
        this.askedSubQuestion=event.target.value;
        console.log(this.askedSubQuestion);
    }
 
    
    questionDesHandleChange(event){
        this.askedQuestion=event.target.value;
        console.log("Description: " + this.askedQuestion)
    }
    

    @track pickListTag2;
    @track pickListTag;
    @track category;
    @track newArray=[];
    postClickQuestion(){
        
        this.category=this.selecteCat;
        this.postedSubQuestion=this.askedSubQuestion;
        this.description=this.askedQuestion;
        this.newArray=this.allValues1;
        
        if(this.handleCheckValidation()&& this.allValues1.length>2)
        {
        insertQuestion({Qtitle:this.postedSubQuestion,Qdescription:this.description,tagArray:this.newArray,Qcategory:this.category})
        .then(result=>{

          console.log(result);
         })
        .catch(error=>{
          console.error(error);
        })

      this.isShowModal = false;
      this.handleSuccess();
    } 
    else{
        this.handleUnSuccess();
    }
      
}


    handleSuccess (){
    const evt = new ShowToastEvent({
        title: "Success!",
        message: "Congrats, You  Asked a question",
        variant: "success",
    });
   this.dispatchEvent(evt);
}

handleUnSuccess(){
    console.log('handleunsuccess');
    const evt = new ShowToastEvent({
        title: "ERROR",
        message: "Please insert Title,description and add minimum of three tags",
        variant: "warning",
    });
   this.dispatchEvent(evt);
}



   






//PickList of tags for filtering
@track allTags;
@track picklistOptions;
@track tagsfromApex;
@track tagsfromApex1=[];

@wire(allTagList, {})

tagsfromApex({ error, data }) {

    if (data) {
       
        try {
           
            //this.allTags = data;
            let options = [];
            for (var key in data) {
                // Here key will have index of list of records starting from 0,1,2,....
                options.push({ label: data[key].Name, value: data[key].Name });
                // Here Name and Id are fields from sObject list.
            }
            this.picklistOptions = options;

        } catch (error) {
            console.error('check error here', error);
        }
    } else if (error) {
        console.error('check error here', error);
    }
}






    @wire(getObjectInfo, { objectApiName: Question_OBJECT })
    categoryInfo;

    @wire(getPicklistValues,
        {
            recordTypeId: '$categoryInfo.data.defaultRecordTypeId',
            fieldApiName: Category__c
        }
    )
    categoryValue;


   





    @track selecteCat;


    handleCategoryChange(event){
      this.selecteCat=event.target.value;
    }





   //fact 
   @track pickListTag2;
   @track pickListTag;
   @track category;
   @track factTagArray=[];
   postClickFact(){
       
       this.category=this.selecteCat;
       this.postedSubQuestion=this.factTitle;
       this.description=this.factDescription;
       this.factTagArray=this.allValues1;
       
     
       if(this.handleCheckValidation() && this.allValues1.length>2)
       {
        this.isShowModal = false;
        console.log('creating question')
        postFact({factTitle:this.postedSubQuestion,factDescription:this.description,tagArray:this.factTagArray,factCategory:this.category})
       .then(result=>{
           
         console.log('in result');
         console.log(result);
    })
    .catch(error=>{
         console.error(error);
     })
   }
   else{
    this.handleUnSuccess();
   }
   }




   factTitle;
   factDescription;
   factHandleChange(event)
   {
        this.factTitle=event.target.value;
   }
   factDesHandleChange(event)
   {
        this.factDescription=event.target.value;
   }



   @track isTagAdded;
  // @track tagNotAdded;
   handleEnter(event) {
    if(event.keyCode === 13) {
        //alert ('added tag new tag for further question');
            this.postTagTosf=this.containsTag;
            //this.tagModal=false;
            getTag({tagName:this.postTagTosf})
            .then(result=>{
                console.log('adding tag');
                console.log(result);
                this.isTagAdded=result;
                console.log(this.isTagAdded);

             })
             .catch(error=>{
                 console.error(error);
             })
            //this.handleChange1();
            if(this.isTagAdded==false)
            {
                alert('Tag already exist');
                console.log('Already');
           
            }
            else{
                console.log('in handle enter');
                this.allValues1.push(this.containsTag);
            }
        }
    }
   

 



//filtering facts
quest;
questionCategory;
searchCategory;
handleGetSelectedValue(event)
{
  console.log(event.target.value);
  this.searchCategory=event.target.value;
  
  //this.handleSelectCategory();
}

removeCategory()
{
    this.searchCategory=null;
    this.categoryValue.data=null;
    //this.template.querySelector('lightning-combobox').reset();
    this.template.querySelectorAll('lightning-combobox').forEach(each => {
        each.value = null;
    });
    console.log('Category' + this.searchCategory);
}





//filtering of question and fact
  @track searchTag=[];
  @track sortTags=[];
  handleGetSelectedTag(event)
  {
    console.log(event.target.value);
    if(!this.searchTag.includes(event.target.value))
    {
    this.searchTag.push(event.target.value);
    console.log(this.searchTag);
    }
   
  }
//   blurHandle(){
//     this.inputTag=null;
//   }

 




  @track questionTag;
  @track questionFilterTag=false;
  @track questionFilterCategory=false;
  getSelectedTagQuestion()
  {
    this.allQuestions=[];
    this.questionTag=[];
    
       if (!this.searchCategory && this.searchTag){
            console.log(this.searchTag);
        getListOfQuestionTag({searchArray:this.searchTag}) 
        .then(result => {
            this.questionTag = result;
            console.log(result);
            //this.questionFilterTag=true;
            console.log('filtered'+this.questionTag);
            
      
        })
        .catch(error => {
            console.log()
        });
        
    }

    

       else if(!this.searchTag && this.searchCategory){
    
        getListOfQuestionCat({searchCategory:this.searchCategory}) 
        .then(result => {
            this.questionTag = result;
            console.log(this.questionTag);
            //this.questionFilterCategory=true;
            
        })
        .catch(error => {
            console.log()
        });
        
     }

    
       else {
    
        getListOfQuestionTagCat({searchArray:this.searchTag,searchCategory:this.searchCategory}) 
        .then(result => {
            this.questionTag = result;
            console.log(this.questionTag);
            this.questionFilterCategory=true;
            
        })
        .catch(error => {
            console.log()
        });
        
     }
         
    
         
        
    }
   
    


  
 






  //multipicklist

  @track allValues1=[];
  @track sortAllValues=[];
  seaTag;
    handleChange1(event)
    {
        //this.containsAllTags=[];

        this.seaTag=event.currentTarget.dataset.name;
        console.log(this.seaTag);
        if(!this.allValues1.includes(this.seaTag))
        {
            this.allValues1.push(this.seaTag);
            this.inputTag=null;
        }
  
        console.log('PickListTag'+this.pickListTag1);
        console.log(this.allValues1);
        this.containsAllTags=[];
        this.inputTag=null;
        
    }

    handleRemove1(event)
    {
        const removeValue=event.target.name;
        this.allValues1.splice(this.allValues1.indexOf(removeValue),1);
    }
  

    handleRemove(event)
    {
        const removeValue=event.target.name;
        this.searchTag.splice(this.searchTag.indexOf(removeValue),1);
    }

    




    handleCheckValidation() {
        let isValid = true;
        let inputFields = this.template.querySelectorAll('.fieldvalidate');
        inputFields.forEach(inputField => {
            if(!inputField.checkValidity()) {
                inputField.reportValidity();
                isValid = false;
            }
        });
        return isValid;
    }
 
    
    @track containsTag;
    containsAllTags=[];
    handleChangeTag(event){
        //this.containsTag=[];
        this.containsAllTags=[];
        this.containsTag=event.target.value;
        console.log(event.target.value);
        if(this.containsTag!='')
        {
        getSearchedTags({tagSearched:this.containsTag})
        .then(result => {
            this.containsAllTags = result;
            console.log(result);
      
        })
        .catch(error => {
            console.log(error);
        });
    }
    }





    //filter fact;
    @track fact;
    getSelectedFact(){
        this.allFacts=[];
        this.alreadyLoadedData=[];
        this.allQuestions=[];
        this.fact=[];
        if(this.searchCategory==null && this.searchTag!=null)
        {
            getListOfFactTag({searchArray:this.searchTag}) 
            .then(result => {
                this.fact = result;
          
            })
            .catch(error => {
                console.log()
            });
         }
    
           else if(this.searchCategory!=null && this.searchTag==null)
           {
            
            getListOfFactCat({searchCategory:this.searchCategory}) 
            .then(result => {
                this.fact = result;
          
            })
            .catch(error => {
                console.log()
            });
            }

            else
            {
            getListOfFact({searchArray:this.searchTag,searchCategory:this.searchCategory})
            .then(result => {
            this.fact = result;
    
            })
             .catch(error => {
          console.log()
            });
        }
        
    }


    handleBlur(event)
    {
        event.target.value=" ";
        this.containsTag=" ";
        //this.containsAllTags=[];
    }


    handleSuccessFact()
    {
        const evt = new ShowToastEvent({
            title: "Success!",
            message: "Congrats, You  Posted A Fact",
            variant: "success",
        });
       this.dispatchEvent(evt);
    }

   
    @track catValue;
    categoryOnClick(event)
    {
       this.catValue=event.target.value;
       console.log(this.catValue);
       getListOfQuestionCat({searchCategory:this.catValue}) 
        .then(result => {
            this.questionTag = result;
            console.log(this.questionTag);
            fireEvent(this.pageRef,"questionCategory",this.questionTag);
            //this.questionFilterCategory=true;
            
        })
        .catch(error => {
            console.log()
        });
    

   
        
}

@track tagValue;
tagOnClick(event)
{
    this.tagValue=event.target.value;
    console.log('Tag'+this.tagValue);
    getListOfQuestionClickTag({searchCategory:this.tagValue}) 
    .then(result => {
        this.questionTag = result;
        console.log(result);
        //this.questionFilterTag=true;
        console.log('filtered'+this.questionTag);
        fireEvent(this.pageRef,"questionTag",this.questionTag);
        
  
    })
    .catch(error => {
        console.log()
    });
}






}