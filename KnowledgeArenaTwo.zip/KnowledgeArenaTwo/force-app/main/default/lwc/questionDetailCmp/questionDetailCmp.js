import { LightningElement ,track,wire} from 'lwc';
import {CurrentPageReference} from 'lightning/navigation'
import { registerListener,unregisterAllListeners } from 'c/pubsub';
import getQuestionDetail from '@salesforce/apex/enterQuestionDetails.getQuestionDetail';
import insertAnswer from '@salesforce/apex/enterQuestionDetails.insertAnswer';
import getAllAnswerForQuestion from '@salesforce/apex/enterQuestionDetails.getAllAnswerForQuestion';
import allAnswersOfQuestion from '@salesforce/apex/QuestionTagController.allAnswersOfQuestion';
// import updateBestAnswer from '@salesforce/apex/enterQuestionDetails.updateBestAnswer';
// import upvoteOnAnswer from '@salesforce/apex/enterQuestionDetails.upvoteOnAnswer';

import giveBonus from '@salesforce/apex/BonuslyApiCallouts.giveBonus';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import StayInTouchSignature from '@salesforce/schema/User.StayInTouchSignature';
export default class QuestionDetailCmp extends LightningElement {
     @wire(CurrentPageReference) pageRef;
    @track
     containsIDForQuestion;
     containsIDForAnswer;
     @track answerRecord;
     @track test=false;
    @track
     updatedAsnswerRecord;
     quesRecord;
     answerIdForBonusly;
     bonuslyModalOpen=false;
     @track
     submit;
     answeredSubmit='';
     isShowCard=false;
     GiveAnswerButton=false;
     GiveAnswerClick=false;
    isShowVotes=false;
    commentDisable=false;
    commentEnable=false;
    isBonusly=false;
    answerIdForBstAns;
    @track
    countUpVote=0;
    countDown=0;
    recipent;
    amt;
    msg;
    hashtags;
    bonusResponse;
    targetId;
    answerIdForVote;
    upVoteForAnswer;
    blureValue;
    noOfVoteForAnswer;
    connectedCallback(){
        registerListener("userPublisher",this.getQuestion,this);
        registerListener("userPublisher",this.getAnswer,this);
        registerListener("AnswerOpenModal",this.giveAnswerOpenModal,this);
        registerListener("questionCategory",this.showQusetionCategory,this);
        registerListener("questionTag",this.showTagQuestion,this);
        
        //registerListener("DetailEvent",this.getQuestion,this);
        //registerListener("DetailEvent",this.getAnswer,this);
        
    }
    giveAnswerOpenModal(){
        this.GiveAnswerButton=true;
    }
    disconnectedCallback(){
        unregisterAllListeners(this);
    }
    GiveAnswerButtonClick(event){
        this.GiveAnswerClick=true;
    }
    getQuestion(eventData){
        this.containsID=eventData;
        console.log('selectrd question id'+this.containsID);
        // questionByIdMethods({queid:this.containsID})
        getQuestionDetail({queid:this.containsID})
        .then(result=>{
            this.quesRecord=result;
            console.log('id for question  '+this.quesRecord);
        })
        .catch(error=>{
            console.log(error);
        })
    }
    getAnswer(eventData){
         this.containsIDForAnswer=eventData;
        console.log('id for answer  '+this.containsIDForAnswer);
        // getAllAnswerForQuestion({recordId:this.containsIDForAnswer})
        allAnswersOfQuestion({recordId:this.containsIDForAnswer})
        .then(result=>{
            this.answerRecord=result;
            for(let i=0;this.answerRecord.length;i++){
            if(this.answerRecord[i].Best_Answer__c==true){
                this.answerRecord[i].rowClass="btn";
                break;
            }
        }
            console.log(' record for answer'+this.answerRecord.length);
        })
        .catch(error=>{
            console.log(error);
        })
        
    }
    
    handleUpvoteButtonClick(event){
        
        this.countUpVote=this.countUpVote+1;
        this.answerForVote=event.target.value;
        upvoteOnAnswer({upVote: this.countUpVote,answerVt:this.answerForVote})
        // .then(result=>{
        //      this.noOfVoteForAnswer=result;
        //      console.log(this.noOfVoteForAnswer)

        //     if(this.noOfVoteForAnswer.Vote__c > 2){
        //         console.log('vote is grater than 1')
        //         document.querySelector('utility:arrowup').disable=true;
        //         console.log('button disable');
        //     }
        // })
        // .catch(error=>{
        //     console.log(error);
        // })

        .then(result=>{
             this.noOfVoteForAnswer=result;
             console.log(this.noOfVoteForAnswer)

            
        })
        .catch(error=>{
            console.log(error);
        })
    }
	
	handleDownvoteButtonClick(){
        this.countDown=this.countDown+1;
        console.log(this.countDown);
    }
	
	commentCard(event){
        this.answeredSubmit=event.target.value;
        this.commentDisable=true;
        if(this.commentDisable==true){
            this.commentEnable=true;
        }
        console.log(this.answeredSubmit);
    }
    cancleHandler(){
        this.GiveAnswerClick=false;
    }
    submitHandleClick(event){
        //this.answeredSubmit='';
        this.isShowVotes=true;
        this.isShowCard=true;
        this.submit = this.answeredSubmit;
        this.recordId=event.target.value;
        
        console.log('reset input field '+this.answeredSubmit);
        console.log('id and ans'+ this.submit);
        console.log('qid'+ this.recordId);

        

        insertAnswer({Ans:this.submit,recordId:this.recordId})
         .then(result=>{
             this.answerRecord=result;
            console.log(' record for answer'+this.answerRecord.length);
        })
        .catch(error=>{
            console.log(error);
        })
        this.answeredSubmit='';

        // *****************reset the submit button
        
    }

    blurFunction(){
        this.blureValue='';
       console.log('onblur'+this.blureValue) ;
    }

    BonuslyHandler(event){
        this.answerIdForBonusly=event.target.value;
        console.log('id for bonusly'+this.answerIdForBonusly);
        // this.bonuslyModalOpen=true;
        this.isBonusly=true;
        this.recipent=event.target.value;
    }
    closeHandler(){
        this.isBonusly=false;
    }
    BestAnswerHandler(event){
        if(event.target.dataset.id){
           let data = JSON.parse(JSON.stringify(this.answerRecord));

            console.log(JSON.stringify(data));
            for( let i=0;i< data.length;i++){
                console.log(JSON.stringify(data[i]));

                if(event.target.dataset.id==data[i].Id){
                    data[i]['rowClass']="btn";
                    let temp=data[0];
                    data[0]=data[i];
                    data[i]=temp;
                    console.log('inside if',JSON.stringify(data[i]));
                    updateBestAnswer({bestAnswer:event.target.dataset.id,questionId:this.containsID});
                }
                else{
                    data[i]['rowClass']="";
                    console.log('inside else');
                }
            }
            this.answerRecord=data;
             console.log('outside loop ',JSON.stringify(this.answerRecord));
            this.targetId = event.target.dataset.id;
            console.log('data id for best answer'+this.targetId);
            //  this.targetId.classList.add("mystyle");
            //  this.template.querySelector('.btn').classList.add('mystyle');
         
        }
        
    }
   
     onchAmount(event)
     {
         this.amt=event.target.value;
          console.log(this.amt);
     }
      onchmsg(event)
      {
        this.msg=event.target.value;
      }
     onchhashtag(event)
     {

         this.hashtags=event.target.value;
       }
       submitforbonus(event)
       {
        this.isBonusly=false;
         console.log(this.recipent);
         giveBonus({userId:this.recipent,amount: this.amt,msg:this.msg,hasgtag:this.hashtags})
        .then(result=>{
            this.bonusResponse=result;
            if(this.bonusResponse==true)
            this.handleSuccess(this.bonusResponse);
            else
             this.handlefail(this.bonusResponse);

        })
        .catch(error=>{
            console.log(error);
        })

        
       }
       handleSuccess(){
        console.log('aaa'+arguments[0]);
    const evt = new ShowToastEvent({
        title: "Success!",
        message: "Congrats, You  Asked a question",
        variant: "success",
    });
   this.dispatchEvent(evt);
}
 handlefail(){
        console.log('aaa'+arguments[0]);
    const evt = new ShowToastEvent({
        title: "Failed!",
        message: "You cannot give bonus points to yourself",
        variant: "warning",
    });
   this.dispatchEvent(evt);
}
    @track
    questionCategory;  
    @track showCategory=false; 
showQusetionCategory(eventdata){
    this.questionCategory=eventdata;
    console.log('seleted category are'+this.questionCategory);
    this.GiveAnswerButton=true;
    this.showCategory=true;
    
}

    @track questionRelatedTag=false;
    @track showTagQuestion;
    showTagQuestion(eventdata)
    {
        this.questionRelatedTag=eventdata;
        console.log(eventdata);
        this.GiveAnswerButton=true;
        this.showTagQuestion=true;
    }
                               
}