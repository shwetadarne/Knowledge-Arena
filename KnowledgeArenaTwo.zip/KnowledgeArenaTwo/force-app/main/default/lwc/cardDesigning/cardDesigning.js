import { LightningElement } from 'lwc';

export default class CardDesigning extends LightningElement {}