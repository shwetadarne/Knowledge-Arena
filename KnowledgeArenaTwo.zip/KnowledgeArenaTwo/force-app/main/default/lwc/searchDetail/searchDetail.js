import { LightningElement } from 'lwc';

export default class SearchDetail extends LightningElement {
    isExpand=false;
    expandOnClick(){
        this.isExpand=true;
    }

}