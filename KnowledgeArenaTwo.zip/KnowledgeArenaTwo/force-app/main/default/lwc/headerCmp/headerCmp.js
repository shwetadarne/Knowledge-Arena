import { LightningElement,wire,api,track } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation'; 
import { fireEvent } from 'c/pubsub'; 
import { registerListener,unregisterAllListeners } from 'c/pubsub';
import globalSearchWithLazyLoading from '@salesforce/apex/knowledgeArena.globalSearchWithLazyLoading';

export default class HeaderCmp extends LightningElement {
    @wire(CurrentPageReference) pageRef; 
    @api
    payload;
    @api
    payloadFact;
    @api
    payloadTag;
    isShowTabQnA=true;
    isShowTabFact=true;
    searchWord;
    parseQuestion=[];
    parseFact=[];
    parseTag=[];
    parseQuestionName=[];
    containsSearchResults=false;
    @track
    parsedQuestionObj=[];
    @track
    parsedFactObj=[];
    allSearch=false;
    questionSearch=false;
    factSearch=false;
    value = 'All';
    parseQuestionHeader=[];
    offSet=0;
    //holdsLazyLoading=[];

    tabHome;
    tabQAContent;
    tabHomeContent;
    tabFactContent;
    isShowdropDown=false;
    totalrecordslength;
    searchLoadOffset;
    

    get options() {
        return [
            { label: 'All', value: 'All' },
            { label: 'Questions', value: 'questions' },
            { label: 'facts', value: 'facts' },
        ];
    }
    handleSelectChange(event){
        this.value = event.detail.value;
        console.log(this.value);
    }

    handleChange(event){
        this.searchWord=event.target.value;
        //c/cWerxOneWerx_Phase2_TimeCardApprovalfireEvent(this.pageRef,"sendWord",this.searchWord);
    } 
    // qnaClickHandler(){
    //     this.payload=true;
    //     fireEvent(this.pageRef,"tabChangeEvent",this.payload);
    // }

    //for the dropDown of Global search
    getAllSearchRecords(){
        this.offSet=0;
        globalSearchWithLazyLoading({searchKey:this.searchWord,offSet:this.offSet})
        .then(result=>{
            this.isShowdropDown=true;
            let parsedData=JSON.parse(result);
            //console.log('the parsed data'+parsedData); 
            //console.log(parsedData[0]);
            this.parsedQuestionObj=parsedData[0];
            console.log('parsedquestionobj'+this.parsedQuestionObj);
        
            //console.log('parsed question'+this.parseQuestion);
            //console.log(this.parseQuestion[0].Question_Header__c);
            for(let i=0;i<this.parsedQuestionObj.length;i++){
                this.parseQuestionHeader.push(this.parsedQuestionObj[i]);
                console.log(this.parseQuestionHeader);
            }
            this.offSet=this.offSet+3;
            
        })
        .catch(error=>{
            console.error(error);
        })
    }
    connectedCallback(){
        //registerListener("recordLengthEvent",this.recordlength,this);
        registerListener("offsetEvent",this.searchLoad,this);
        //registerListener("stopOffSet",this.stopOffset,this);
    }
    // stopOffset(eventData){
    //     this.passData=eventData;
    //     this.searchLoad(this.passData);
    //     console.log('stopOffset'+this.passData);
    // }
    // recordlength(eventData){
    //     this.totalrecordslength=eventData;
    //     console.log('the length'+this.totalrecordslength);
    // }
    // searchLoad(eventData){
    //     this.containsSearchResults=true;
    //     this.isShowdropDown=false;
    //     fireEvent(this.pageRef,"searchOrQaFeed",this.containsSearchResults);
    //     this.parsedQuestionObj=[];
    //     this.parseQuestion=[];
    //     this.parseFact=[];
    //     this.parsedFactObj=[];
    //     if(this.value=='All'){
    //         this.allSearch=true;
    //         this.questionSearch=false;
    //         this.factSearch=false;
    //         console.log(eventData+'event data');
    //         this.searchLoadOffset=eventData;
    //     globalSearchWithLazyLoading({searchKey:this.searchWord,offSet: eventData})
    //     .then(result=>{
    //         let parsedData=JSON.parse(result);
    //         console.log('after scroll in haeder '+ eventData);
    //         console.log('the parsed data'+parsedData); 
    //         console.log(parsedData[0]);
    //         this.parsedQuestionObj=parsedData[0];
    //         console.log('parsedquestionobj'+this.parsedQuestionObj);
    //         for(let i=0;i<this.parsedQuestionObj.length;i++){
    //             if(this.parsedQuestionObj[i].RecordTypeId=='0121e000000og5ZAAQ'){
    //                 this.parseQuestion.push(this.parsedQuestionObj[i]);
    //             }
    //             if(this.parsedQuestionObj[i].RecordTypeId=='0121e000000okmUAAQ'){
    //                 this.parseFact.push(this.parsedQuestionObj[i]);
    //             }

    //         }
        
    //         //console.log('parsed question'+this.parseQuestion);
    //         //console.log(this.parseQuestion[0].Question_Header__c);
            
    //         this.payload=this.parseQuestion;
    //         console.log('payload'+this.payload);
    //         fireEvent(this.pageRef,"myfirstpubsub",this.payload);
    //         this.payloadFact=this.parseFact;
    //         fireEvent(this.pageRef,"mysecpubsub",this.payloadFact);
    //         console.log('parsed answer'+this.payloadFact);
    //         this.parseTag=parsedData[1];
    //         console.log(this.parseTag);
    //         //fireEvent(this.pageRef,"mythirdpubsub",this.payloadTag);
    //         fireEvent(this.pageRef,"myOffsetAfter",this.offSet);
    //         console.log('after fire event'+this.offSet);

    //         if(result!=null){
    //             this.containsSearchResults=true;
    //         }
            
    //     })
    //     .catch(error=>{
    //         console.error(error);
    //     })
    //     }
        
    //     if(this.value=='questions'){
    //         this.questionSearch=true;
    //         this.allSearch=false;
    //         this.factSearch=false;
            
    //         //console.log('in question value');
    //         //console.log(this.parseQuestion);
    //         globalSearchWithLazyLoading({searchKey:this.searchWord,offSet:eventData})
    //         .then(result=>{
    //         let parsedData=JSON.parse(result);
    //         console.log('the parsed data'+parsedData); 
    //         console.log(parsedData[0]);
    //         this.parsedQuestionObj=parsedData[0];
    //         console.log('parsedquestionobj'+this.parsedQuestionObj);
    //         for(let i=0;i<this.parsedQuestionObj.length;i++){
    //             if(this.parsedQuestionObj[i].RecordTypeId=='0121e000000og5ZAAQ'){
    //                 this.parseQuestion.push(this.parsedQuestionObj[i]);
    //             }
    //         }
        
    //         //console.log('parsed question'+this.parseQuestion);
    //         //console.log(this.parseQuestion[0].Question_Header__c);
            
    //         this.payload=this.parseQuestion;
    //         console.log('payload'+this.payload);
    //         fireEvent(this.pageRef,"soslQuestionEvent",this.payload);
    //         //fireEvent(this.pageRef,"myfirstpubsub",this.payload);
            
    //         //fireEvent(this.pageRef,"mythirdpubsub",this.payloadTag);

    //         if(result!=null){
    //             this.containsSearchResults=true;
    //         }
            
    //         })
    //         .catch(error=>{
    //             console.error(error);
    //         })
            
    //     }
    //     if(this.value=='facts'){
    //         this.factSearch=true;
    //         this.questionSearch=false;
    //         this.allSearch=false;
            
    //         globalSearchWithLazyLoading({searchKey:this.searchWord,offSet:eventData})
    //         .then(result=>{
    //         let parsedData=JSON.parse(result);
    //         console.log('the parsed data'+parsedData); 
    //         console.log(parsedData[0]);
    //         this.parsedFactObj=parsedData[0];
    //         console.log('parsedFactObj'+this.parsedFactObj);
    //         for(let i=0;i<this.parsedFactObj.length;i++){
    //             if(this.parsedFactObj[i].RecordTypeId=='0121e000000okmUAAQ'){
    //                 this.parseFact.push(this.parsedFactObj[i]);
    //             }
    //         }
        
    //         //console.log('parsed question'+this.parseQuestion);
    //         //console.log(this.parseQuestion[0].Question_Header__c);
            
    //         this.payload=this.parseFact;
    //         console.log('payload'+this.payload);
    //         fireEvent(this.pageRef,"soslFactEvent",this.payload);
    //         //fireEvent(this.pageRef,"myfirstpubsub",this.payload);
            
    //         //fireEvent(this.pageRef,"mythirdpubsub",this.payloadTag);

    //         if(result!=null){
    //             this.containsSearchResults=true;
    //         }
            
    //         })
    //         .catch(error=>{
    //             console.error(error);
    //         })
                
    //     }
    // }
    search(){

        this.containsSearchResults=true;
        this.isShowdropDown=false;
        fireEvent(this.pageRef,"searchOrQaFeed",this.containsSearchResults);
        this.parsedQuestionObj=[];
        this.parseQuestion=[];
        this.parseFact=[];
        this.parsedFactObj=[];
        this.offSet=0;
        if(this.value=='All'){
            this.allSearch=true;
            this.questionSearch=false;
            this.factSearch=false;
            this.parsedQuestionObj=[];
            this.parseQuestion=[];
            this.parseFact=[];
            this.parsedFactObj=[];
        
        globalSearchWithLazyLoading({searchKey:this.searchWord})
        .then(result=>{
            console.log('before'+result);
            let parsedData=JSON.parse(result);
            console.log('AFter'+parsedData);
            console.log('the parsed data'+parsedData[0]); 
            console.log(parsedData[0]);
            this.parsedQuestionObj=parsedData[0];
            console.log('parsedquestionobj'+this.parsedQuestionObj);
            for(let i=0;i<this.parsedQuestionObj.length;i++){
                if(this.parsedQuestionObj[i].RecordTypeId=='0121e000000og5ZAAQ'){
                    this.parseQuestion.push(this.parsedQuestionObj[i]);

                }
                if(this.parsedQuestionObj[i].RecordTypeId=='0121e000000okmUAAQ'){
                    this.parseFact.push(this.parsedQuestionObj[i]);
                }

            }
        
            //console.log('parsed question'+this.parseQuestion);
            //console.log(this.parseQuestion[0].Question_Header__c);
            
            this.payload=this.parseQuestion;
            console.log('payload'+this.payload);
            fireEvent(this.pageRef,"myfirstpubsub",this.payload);
            this.payloadFact=this.parseFact;
            fireEvent(this.pageRef,"mysecpubsub",this.payloadFact);
            console.log('parsed answer'+this.payloadFact);
            this.parseTag=parsedData[1];
            console.log(this.parseTag);
            //fireEvent(this.pageRef,"mythirdpubsub",this.payloadTag);
            //fireEvent(this.pageRef,"myOffset",this.offSet);
            fireEvent(this.pageRef,"filterAllEvent",this.allSearch);
            //  console.log('after fire event');

            if(result!=null){
                this.containsSearchResults=true;
            }
            
        })
        .catch(error=>{
            console.error(error);
        })
        }
        
        if(this.value=='questions'){
            this.questionSearch=true;
            this.allSearch=false;
            this.factSearch=false;
            this.parsedQuestionObj=[];
            this.parseQuestion=[];
            this.parseFact=[];
            this.parsedFactObj=[];
            
            //console.log('in question value');
            //console.log(this.parseQuestion);
            globalSearchWithLazyLoading({searchKey:this.searchWord})
            .then(result=>{
            let parsedData=JSON.parse(result);
            console.log('the parsed data'+parsedData); 
            console.log(parsedData[0]);
            this.parsedQuestionObj=parsedData[0];
            console.log('parsedquestionobj'+this.parsedQuestionObj);
            for(let i=0;i<this.parsedQuestionObj.length;i++){
                if(this.parsedQuestionObj[i].RecordTypeId=='0121e000000og5ZAAQ'){
                    this.parseQuestion.push(this.parsedQuestionObj[i]);
                }
            }
        
            //console.log('parsed question'+this.parseQuestion);
            //console.log(this.parseQuestion[0].Question_Header__c);
            
            this.payload=this.parseQuestion;
            console.log('payload'+this.payload);
            fireEvent(this.pageRef,"soslQuestionEvent",this.payload);
            //fireEvent(this.pageRef,"myfirstpubsub",this.payload);
            
            //fireEvent(this.pageRef,"mythirdpubsub",this.payloadTag);
            fireEvent(this.pageRef,"filterqaEvent",this.questionSearch);

            if(result!=null){
                this.containsSearchResults=true;
            }
            
            })
            .catch(error=>{
                console.error(error);
            })
            
        }
        if(this.value=='facts'){
            this.factSearch=true;
            this.questionSearch=false;
            this.allSearch=false;
            this.parsedQuestionObj=[];
            this.parseQuestion=[];
            this.parseFact=[];
            this.parsedFactObj=[];
            
            globalSearchWithLazyLoading({searchKey:this.searchWord})
            .then(result=>{
            let parsedData=JSON.parse(result);
            console.log('the parsed data'+parsedData); 
            console.log(parsedData[0]);
            this.parsedFactObj=parsedData[0];
            console.log('parsedFactObj'+this.parsedFactObj);
            for(let i=0;i<this.parsedFactObj.length;i++){
                if(this.parsedFactObj[i].RecordTypeId=='0121e000000okmUAAQ'){
                    this.parseFact.push(this.parsedFactObj[i]);
                }
            }
        
            //console.log('parsed question'+this.parseQuestion);
            //console.log(this.parseQuestion[0].Question_Header__c);
            
            this.payload=this.parseFact;
            console.log('payload'+this.payload);
            fireEvent(this.pageRef,"soslFactEvent",this.payload);
            //fireEvent(this.pageRef,"myfirstpubsub",this.payload);
            
            //fireEvent(this.pageRef,"mythirdpubsub",this.payloadTag);
            fireEvent(this.pageRef,"filterFactEvent",this.factSearch);

            if(result!=null){
                this.containsSearchResults=true;
            }
            
            })
            .catch(error=>{
                console.error(error);
            })
                
        }
        
    }
    tabQAHandle(event){
        //this.tabHome=event.target;
        this.tabQAContent=event.target.value;
        //console.log(this.tabHome);
        console.log(this.tabQAContent);
        fireEvent(this.pageRef,"tabEvent",this.tabQAContent);
    }
    tabHomeHandle(event){
        this.tabHomeContent=event.target.value;
        console.log(this.tabHomeContent);
        fireEvent(this.pageRef,"tabEventHome",this.tabHomeContent);

    }
    tabFactHandle(event){
        this.tabFactContent=event.target.value;
        console.log(this.tabFactContent);
        fireEvent(this.pageRef,"tabEventFact",this.tabFactContent);
    }
    onSelect(event){
        let selectedId = event.currentTarget.dataset.id;
		let selectedName = event.currentTarget.dataset.name;
        console.log(selectedId);
        console.log(selectedName);
        fireEvent(this.pageRef,"DetailEvent",selectedId);
    }

}