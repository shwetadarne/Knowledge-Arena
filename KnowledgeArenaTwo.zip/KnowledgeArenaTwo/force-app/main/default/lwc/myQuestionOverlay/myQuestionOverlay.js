import { LightningElement, track,api } from 'lwc';

export default class MyQuestionOverlay extends LightningElement {
   @track
   isShowModal=true;
   @api myquestion;
   openQuestion=false;
   editForm=false;
   qaTabName='Question';
   categoryValue;
   @track
   myQuestionList;
    hideModalBox() {  
        this.isShowModal = false;
        const custEvent = new CustomEvent('callpasstoparent', {detail: 'false'});
        this.dispatchEvent(custEvent);
    }
    openQuestionDetails(){
        this.openQuestion=true;
    }
    openEditForm(){
        this.editForm=true;
    }
    connectedCallback()
    {
            this.myQuestionList=this.myquestion;
            console.log(this.myQuestionList);
    }
}