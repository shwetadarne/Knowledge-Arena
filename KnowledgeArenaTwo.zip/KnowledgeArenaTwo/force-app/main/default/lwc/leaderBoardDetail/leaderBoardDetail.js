import { LightningElement,api,track } from 'lwc';
import advisorImg from '@salesforce/resourceUrl/advisor';
const columns = [
    { label: 'Rank', fieldName: 'rank' ,type: 'integer'},
   { label: 'Profile Picture', fieldName: 'profileImg', type: 'jpg' },
   { label: 'Name', fieldName: 'name', type: 'string' },
   { label: 'Career Rank', fieldName: 'badge', type: 'integer' },
   { label: 'Career Points', fieldName: 'badge', type: 'integer' },
];
export default class LeaderBoardDetail extends LightningElement {

     careerImg=advisorImg;
    @api weeklist;
    @api monthlist;
    @api ranklist;
    @api from;
    @track
    wselect='active';
    @track
    mselect;
    
    @track 
    data;
    //this.data = this.weeklist;
    columns = columns;
    showLeaderBoard=true;
    connectedCallback()
    {
        if(this.from==false)
        {
            this.data=this.weeklist;
        }
        else{
            this.data=this.ranklist;
        }
       


    }

    get getdata()
    {
        console.log(this.weeklist);
        return this.data;

    }
    weekClick()
    {
        this.data=this.weeklist;
        this.wselect='active';
        this.mselect='';
    }
    monthClick()
    {
        this.data=this.monthlist;
        this.wselect='';
        this.mselect='active';

    }
    
    hideModalBox(){
        this.showLeaderBoard=false;
        const custEvent = new CustomEvent('callpasstoparent', {detail: 'false'});
        this.dispatchEvent(custEvent);
    }
}