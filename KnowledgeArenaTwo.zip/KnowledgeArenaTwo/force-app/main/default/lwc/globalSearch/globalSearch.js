import { LightningElement, track } from 'lwc';
import QuestionTagMethods from '@salesforce/apex/QuestionTagController.QuestionTagMethods';

export default class ComboboxBasic extends LightningElement {
    value = 'All';
    isClickedSearch=false;
    searchInput;
    @track
    searchWord;
    get options() {
        return [
            { label: 'All', value: 'All' },
            { label: 'Question', value: 'Question' },
            { label: 'Fact', value: 'Fact' },
        ];
    }
    filterChange(event){
        this.value = event.detail.value;
    }

    handleChange(event){
        this.searchInput=event.target.value;
    }

    searchClick(){
        this.isClickedSearch=true;
        this.searchWord=this.searchInput;
        const selectedEvent = new CustomEvent("opensearchtab", {
            detail: {boolOpenClose:this.isClickedSearch,
            searchedWord:this.searchWord,filter:this.value}});
        this.dispatchEvent(selectedEvent);
        console.log(this.isClickedSearch);
    }

    enterKeyPress(event){
        if(event.keyCode==13){
            this.searchClick();
        }
    }

    
}