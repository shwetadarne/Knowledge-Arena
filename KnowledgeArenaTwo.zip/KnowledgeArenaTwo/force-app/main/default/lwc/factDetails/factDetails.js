import { LightningElement,api } from 'lwc';
import VoteInsertion from '@salesforce/apex/QuestionTagController.VoteInsertion';
export default class FactDetails extends LightningElement {
    isExpand=false;
    factId;
    @api  recordFromFactCmp;
    expandOnClick(){
        this.isExpand=true;
    }

    connectedCallback()
    {
        console.log('fact details'+this.recordFromFactCmp);
        console.log(this.recordFromFactCmp);
        
    }

    handleUpvoteButtonClick(event){
        this.factId = event.target.value;
        console.log('answerId',this.factId);
        VoteInsertion({TypeOfVote:'up',answerOrFactId:this.factId,ansOrFact:'fact'})
        .then(result=>{
            console.log(result);
        })
        .catch(error=>{
            console.log(error);
        })
    }
    handleDownvoteButtonClick(event){
        this.factId = event.target.value;
        VoteInsertion({TypeOfVote:'down',answerOrFactId:this.factId,ansOrFact:'fact'})
        .then(result=>{
            console.log(result);
        })
        .catch(error=>{
            console.log(error);
        })
    }
}