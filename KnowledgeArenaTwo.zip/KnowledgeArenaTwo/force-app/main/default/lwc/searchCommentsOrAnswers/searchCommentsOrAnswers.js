import { LightningElement } from 'lwc';

export default class SearchCommentsOrAnswers extends LightningElement {}