import sendingaccountDatatoXero from '@salesforce/apex/XeroIntegrationController.sendingaccountDatatoXero';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CurrentPageReference } from 'lightning/navigation';
import { CloseActionScreenEvent } from 'lightning/actions';
import { LightningElement,track,api,wire } from 'lwc';

export default class CreateContactinXeroOnewerx extends LightningElement {
    @track spinner = false;
    @api recordId;
    @track sendSurvey = false;
    @track validation = '';
    @track idList = [];

    @wire(CurrentPageReference)
        getStateParameters(currentPageReference) {
            if (currentPageReference) {
                this.recordId = currentPageReference.state.recordId;
                this.idList.push(this.recordId);
            }
            console.log('Inside Wire'+this.idList);
        }

        

    renderedCallback(){
        this.spinner = true;
        console.log('Inside Renderedcallback')
        sendingaccountDatatoXero({idList:this.idList})
            .then(result => {
                var message;
                message = result;
                console.log('result-->'+JSON.stringify(result));
                console.log('message--->'+JSON.stringify(message));
                if(message == 'Successfully published event.'){

                    const toastEvent = new ShowToastEvent({
                        title:'Success',
                        message:message,
                        variant:'Success',
                      })
                      this.dispatchEvent(toastEvent);
                      
                this.spinner = false;
                this.dispatchEvent(new CloseActionScreenEvent());

                }
                
            else{

            const toastEvent = new ShowToastEvent({
                title:'Error',
                message:message,
                variant:'Error',
                  })
                  this.dispatchEvent(toastEvent);
                  
            this.spinner = false;
            this.dispatchEvent(new CloseActionScreenEvent());

            }
            })
            
            .catch(error => {
                this.error = error;
            });
        
            
        
        
            
            
    }
}