import { LightningElement ,api, track} from 'lwc';
export default class MyQuestionDetails extends LightningElement {
    @api
    myq;
    @api
    aname;
    @track
    authorName='me';
    @track
    copyOfApi;
   openMyQuestionDetails=true;
    hideModalBox(){
        this.openMyQuestionDetails=false;
        const custEvent = new CustomEvent('callpasstoparent', {detail: 'false'});
        this.dispatchEvent(custEvent);
    }
    connectedCallback()
    {
        // this.copyOfApi=this.myq;
        console.log('gere');
        this.copyOfApi=JSON.parse(this.myq);
        // this.copyOfApi=JSON.parse(JSON.stringify((this.myq)));
        console.log(this.copyOfApi);
    }
}