import { LightningElement,track,api,wire } from 'lwc';
import skillAndParent from '@salesforce/apex/ProductSelectionController.skillAndParent';
import projectSpecializationManupulation from '@salesforce/apex/ProductSelectionController.projectSpecializationManupulation';
import projectSpecialization from '@salesforce/apex/ProductSelectionController.projectSpecialization';
import { CurrentPageReference } from 'lightning/navigation';
import { CloseActionScreenEvent } from 'lightning/actions';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import Error_message from '@salesforce/label/c.Error_message';
import Success_Toast from '@salesforce/label/c.Success_Toast';

// bhjbhj
export default class ProductSelection extends LightningElement {
    @track section;
    checkedSkills = [];
    unCheckedSkills = [];
    projectSpecialisationRecordList;
    @track allCategories=[];
    @track pseSkills = [];
    recordId;
    projectSpecialisationRecord= {};

    connectedCallback(){
        skillAndParent({projectId: this.recordId})
            .then(result => {
                this.allCategories = result;
            }).catch(error => {
                console.log('error');
            });

        projectSpecialization({projectId: this.recordId})
        .then((result) => {
            this.projectSpecialisationRecordList = result;
        })
        .catch((error) => {
            this.error = error;
            this.contacts = undefined;
        });           
    }

    @wire(CurrentPageReference)
        getStateParameters(currentPageReference) {
            if (currentPageReference) {
                this.recordId = currentPageReference.state.recordId;
            }
        }
    
    handleToggleSection(event) {
        this.section = event.detail.openSections;
    }

    handleReason(event){
        let notDuplicate = true;
        if (event.target.checked) {
            if(!this.checkedSkills.includes(event.target.dataset.id) && notDuplicate){
                this.checkedSkills.push(event.target.dataset.id);
            }
            for(let i=0;i<this.projectSpecialisationRecordList.length ; i++){
                    if(event.target.dataset.id == this.projectSpecialisationRecordList[i].skillId){
                        const index = this.unCheckedSkills.indexOf(this.projectSpecialisationRecordList[i].skillId);
                        if (index > -1) {
                            this.unCheckedSkills.splice(index, 1);
                        }        
                    }
            }
        }
        else {
            if(!this.unCheckedSkills.includes(event.target.dataset.id)){
                for(let i=0;i<this.projectSpecialisationRecordList.length ; i++){
                    if(event.target.dataset.id == this.projectSpecialisationRecordList[i].skillId){
                        this.unCheckedSkills.push(this.projectSpecialisationRecordList[i].skillId);                   
                    }
                }
            }
            const index = this.checkedSkills.indexOf(event.target.dataset.id);
            if (index > -1) {
                this.checkedSkills.splice(index, 1);
            }
        }
    }

    submitDetails() {
        if(this.checkedSkills.length > 0 || this.projectSpecialisationRecordList.length > 0){
            projectSpecializationManupulation({ selectedProducts: this.checkedSkills, pSId :  this.unCheckedSkills, projectId: this.recordId})
            .then((result) => {
                 this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: Success_Toast,
                        variant: 'success',
                    }),
                    );
                    this.dispatchEvent(new CloseActionScreenEvent());
                
            })
            .catch((error) => {
                this.error = e.getMessage();
            });
        }else {
            this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error',
                message: Error_message,
                variant: 'error',
            }),
            );                   
        }    
    }        

    closeModal(){
        this.dispatchEvent(new CloseActionScreenEvent());
    }


    activeSectionMessage = '';
    activeSections = ['tutorialW3web'];
    handleToggleSection(event) {
        this.activeSectionMessage =
            'Open section name:  ' + event.detail.openSections;
    }

    handleSetActiveSectionC() {
        const accordion = this.template.querySelector('.example-accordion');
        accordion.activeSectionName = 'C';
    }
}