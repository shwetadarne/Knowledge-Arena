import { api, LightningElement } from 'lwc';

export default class MyFactDetails extends LightningElement {
   
    openMyFactDetails=true;
    hideModalBox(){
        this.openMyFactDetails=false;
    }

    // connectedCallback()
    // {
    //     console.log(this.myq);
    // }


}