import { LightningElement,track,wire,api} from 'lwc';
import QuestionDetailMethod from '@salesforce/apex/KnowledgeArenaWrapperClass.QuestionDetailMethod';

export default class AskAQuestionCmp extends LightningElement {
    // isShowAskQuestion=true;
    // tagValue = 'Salesforce';
    // categoryValue='Good';
    // hideAskQuestion(){
    //     this.isShowAskQuestion=false;
    //     console.log('It became false');
    // }
    // get options() {
    //     return [
    //         { label: 'Salesforce', value: 'Salesforce' },
    //         { label: 'MuleSoft', value: 'MuleSoft' },
    //         { label: 'RPA', value: 'RPA' },
    //     ];
    // }
    // get CategoryOptions(){
    //     return [
    //         { label: 'Good', value: 'Good' },
    //         { label: 'Better', value: 'Better' },
    //         { label: 'Best', value: 'Best' },
    //     ];
    // }

    // handleTagChange(event) {
    //     this.tagValue = event.detail.value;
    // }
    // handleCategoryChange(event){
    //     this.categoryValue = event.detail.value;
    // }
    @track questionWrapper;
    @track error;
    handleclick(){
        QuestionDetailMethod()
        .then(result=>{
            this.questionWrapper=result;
            console.log(this.questionWrapper);
            console.log(JSON.parse(this.questionWrapper));
        })
        .catch(error=>{
            console.error(error);
        })
    
    }
}