import { LightningElement } from 'lwc';

export default class Fileupload extends LightningElement {

    handleUploadFinished(event) {
        // Get the list of uploaded files
        const uploadedFiles = event.detail.files;
        console.log(uploadedFiles);
        console.log(result);
        // let contents:result.split(/,/);
        let theFile = event.target.files;
        let reader = new FileReader();
        let temp = this;
        console.log(this);


        alert('No. of files uploaded : ' + uploadedFiles.length);
    }
}