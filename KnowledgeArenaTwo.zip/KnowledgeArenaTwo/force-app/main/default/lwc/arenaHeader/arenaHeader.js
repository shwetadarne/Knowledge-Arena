import { LightningElement, track } from 'lwc';

import knowledgelogo from '@salesforce/resourceUrl/knowledgeArenaNewLogo';
export default class ArenaHeader extends LightningElement {
    logoimg=knowledgelogo;
    searchTabOpen=false;
    @track containsParameters;
    openSearchTabHandle(event){
        this.searchTabOpen=event.detail.boolOpenClose;
        this.containsParameters=event.detail;
        const selectedTabEvent = new CustomEvent("redirectsearchtab", {
            detail: this.containsParameters});
        this.dispatchEvent(selectedTabEvent);
        console.log('in arenaHeader'+this.containsParameters);
    }
}