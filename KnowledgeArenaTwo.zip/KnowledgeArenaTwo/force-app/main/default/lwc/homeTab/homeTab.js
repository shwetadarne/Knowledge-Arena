import { LightningElement } from 'lwc';

export default class HomeTab extends LightningElement {}