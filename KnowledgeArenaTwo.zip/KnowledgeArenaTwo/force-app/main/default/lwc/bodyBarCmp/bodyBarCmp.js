import { LightningElement,track } from 'lwc';
// import personimage from '@salesforce/resourceUrl/personlogo';
export default class BodyBarCmp extends LightningElement {
//     img=personimage;
    isShowModal=false;
    questionFeed=[];
    @track
    askedSubQuestion;
    @track
    askedQuestion;
    postedQuestion;
    postedSubQuestion;
    showModal(event){
        this.isShowModal=true;
   }
   hideModalBox() {  
       this.isShowModal = false;
   }
   questionSubHandleChange(event){
        this.askedSubQuestion=event.target.value;
        console.log(this.askedSubQuestion);
   }
   questionHandleChange(event){
    this.askedQuestion=event.target.value;
    console.log(this.askedQuestion);
   }
   postClick(){
        this.isShowModal = false;
        this.postedSubQuestion=this.askedSubQuestion;
        this.postedQuestion=this.askedQuestion;
        console.log(this.postedSubQuestion);
        console.log(this.postedQuestion);
        
   }
}