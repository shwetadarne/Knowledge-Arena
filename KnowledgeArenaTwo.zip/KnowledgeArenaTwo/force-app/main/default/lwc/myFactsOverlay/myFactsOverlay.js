import { api, LightningElement ,track} from 'lwc';
export default class MyFactsOverlay extends LightningElement {
    @track
   isShowModal=true;
   @api
   myfact;
   @track
   myfactlist;
   factDetails=false;
   editForm=false;
   qaTabName='Question';
   categoryValue;
    hideModalBox() {
        this.isShowModal = false;
        const custEvent = new CustomEvent('callpasstoparent', {detail: 'false'});
        this.dispatchEvent(custEvent);
    }
    openFactDetails(){
        this.factDetails=true;
    }
    openEditForm(){
        this.editForm=true;
    }
    connectedCallback()
    {
        this.myfactlist=this.myfact;
    }
}