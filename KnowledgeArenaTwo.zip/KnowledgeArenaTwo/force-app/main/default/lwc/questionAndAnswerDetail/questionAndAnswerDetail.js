import { LightningElement,wire,track } from 'lwc';
import {CurrentPageReference} from 'lightning/navigation'
import { registerListener,unregisterAllListeners } from 'c/pubsub';
import getUserDetailCard from '@salesforce/apex/enterQuestionDetails.getUserDetailCard';
import insertAnswer from '@salesforce/apex/enterQuestionDetails.insertAnswer';
import getAllAnswerForQuestion from '@salesforce/apex/enterQuestionDetails.getAllAnswerForQuestion';
import insertCountVoteForAnswer from '@salesforce/apex/enterQuestionDetails.insertCountVoteForAnswer';
export default class QuestionAndAnswerDetail extends LightningElement {

     @wire(CurrentPageReference) pageRef;
    @track
     containsIDForQuestion;
     containsIDForAnswer;
     @track
     answerRecord;
     quesRecord;
     @track
     submit;
     answeredSubmit;
     isShowCard=false;
     GiveAnswerButton=false;
     GiveAnswerClick=false;
    isShowVotes=false;
    commentDisable=false;
    commentEnable=false;
    publisherName;
    colorChange;
    closeHandlerClick=true;
    votesForAnswer;
    questionIdForVotes;
    qList;
    @track
    voteRecord;
   count=0;
    countUp=0;
    countDown=0;
    answerVote;
    answers;
    divblock;

    connectedCallback(){
       // registerListener("userPublisher",this.getQuestion,this);
       // registerListener("userPublisher",this.getAnswer,this);
    registerListener("AnswerOpenModal",this.giveAnswerOpenModal,this);
}
giveAnswerOpenModal(eventData){
        this.GiveAnswerButton=true;
    }
    publisherNameHandler(eventData){
    this.publisherName=eventData;
    console.log('publisher name id  '+this.publisherName);
    getUserDetailCard({userid:this.publisherName})
        .then(result=>{
            this.quesRecord=result;
            console.log('id for question  '+this.quesRecord);
        })
        .catch(error=>{
            console.log(error);
        })
    }
    getQuestion(eventData){
        this.containsID=eventData;
        console.log(this.containsID);
        getUserDetailCard({userid:this.containsID})
        .then(result=>{
            this.quesRecord=result;
            console.log('id for question  '+this.quesRecord);
        })
        .catch(error=>{
            console.log(error);
        })
    }
    cancleHandler(){
        this.closeHandlerClick=false;
    }
    submitHandleClick(event){
        this.isShowVotes=true;
        this.isShowCard=true;
        this.submit = this.answeredSubmit;
        this.recordId=event.target.value;
        console.log('id and ans'+ this.submit);
        console.log('id and ans'+ this.recordId);

        insertAnswer({Ans:this.submit,recordId:this.recordId});
    }

    getAnswer(eventData){
         this.containsIDForAnswer=eventData;
        console.log('id for answer  '+this.containsIDForAnswer);
        getAllAnswerForQuestion({recordId:this.containsIDForAnswer})
        .then(result=>{
            this.answerRecord=result;
            console.log(' record for vote '+this.answerRecord);
        })
        .catch(error=>{
            console.log(error);
        })
    }

    handleUpvoteButtonClick(event){
        this.countUp=this.countUp+1;
        console.log(this.countUp);
        console.log(this.submit);
        this.answerVote=event.target.value;
        console.log('id of answer for vote '+this.answerVote);
        this.count=this.count+1;
        // if(this.count%2!=0){
        //     insertCountVoteForAnswer({answerForVote:this.answerVote,voteUp:this.countUp})
        //     
        // else
        // {
        //     deleteVoteForAnswer();
        //     console.log('delete vote for twice');
        // }
        insertCountVoteForAnswer({answerForVote:this.answerVote,voteUp:this.countUp});
        getAllVotes({answerForVote:this.answerVote})
        .then(result=>{
            this.voteRecord=result;

            console.log(' record for votes'+this.voteRecord);
        })
        .catch(error=>{
            console.log(error);
        })

    }

    handleDownvoteButtonClick(){
        this.countDown=this.countDown+1;
        console.log(this.countDown);
    }
	
    commentCard(event){
        this.answeredSubmit=event.target.value;
        console.log(this.answeredSubmit);
        this.commentDisable=true;
        if(this.commentDisable==true){
            this.commentEnable=true;
        }
    }
    
}