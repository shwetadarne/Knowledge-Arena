import { LightningElement ,api,track,wire} from 'lwc';
import { deleteRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import insertAnswerComments from '@salesforce/apex/QuestionTagController.insertAnswerComments';
import FactCategoryResponse from '@salesforce/apex/QuestionTagController.QuestionCategoryResponse';
import VoteInsertion from '@salesforce/apex/QuestionTagController.VoteInsertion';
import { fireEvent } from 'c/pubsub';
import { CurrentPageReference } from 'lightning/navigation';
import uId from '@salesforce/user/Id';
import bonuslylogo from '@salesforce/resourceUrl/bonuslylogo';

export default class FactComments extends LightningElement {
    // @api recordId;
    // @wire(CurrentPageReference) pageRef;
    // @api objectApiName;
    // @track factid;
    // userId = uId;
    // offSet=0;
    // bonuslyLogoImg=bonuslylogo;
    
    // isShowCommentButton=false;
    // @track
    // copyOfFacts;
    // isBonusly=false;
    // @track buttonDisable=true;
    // @track inputValue;
    // comment;
    // recordTypeName='Fact';
    // @track visibilityOfVotes;
    // @track factVotes;
    // commentList;
    // answerId;
    // factList;
    // questionId;

    // buttonDisableHandler(event){
 
    //     this.comment=event.target.value;

    //     if(this.comment.length>0)
    //     {
    //         this.buttonDisable=false;
    //     }


    // }


    // expandOnClick(){
    //     this.isExpand=true;
    // }

    // editButtonDisable;
    // editAnswerButton;
    // connectedCallback()
    // {
        
    //     //console.log('Fcat Comment Wrapper'+this.factCommentWrapper);
        
    //     // let newComments=this.allComments;
    //     // let AuthorIdOfQue =newComments.AuthorId;
        
    //     // this.copyOfFacts=JSON.parse(JSON.stringify(this.allComments));
    //     // let CUserId=this.copyOfFacts.CurrentUserId;
    //     // if(this.copyOfFacts.AuthorId==CUserId){
    //     //     this.copyOfFacts.isDisabled=true;
    //     // }
    //     // else{
    //     //     this.copyOfFacts.isDisabled=false;
    //     // }
    //     // for(let i=0;i<this.copyOfFacts.AnswerDetailsWrapper.length;i++){
    //     //     console.log(this.copyOfFacts.AnswerDetailsWrapper[i].answeredBy);
    //     //         if(this.copyOfFacts.AnswerDetailsWrapper[i].answeredBy==CUserId){
    //     //             this.copyOfFacts.AnswerDetailsWrapper[i].isDisabled=true;
                    
    //     //         }
    //     //         else{
    //     //             this.copyOfFacts.AnswerDetailsWrapper[i].isDisabled=false;
                    
    //     //         }
    //     // }


    //     // console.log('Author Id',AuthorIdOfQue);
        
    //     // let UserId=newComments.CurrentUserId;
    //     // console.log('User Id',UserId);
    //     // let answeredId=newComments.AnswerDetailsWrapper.answeredBy;
    //     // console.log('Answered By Id',answeredId);
    //    // this.disableButton();
    // //     disableButton()
    // //     {
    // //     if(AuthorIdOfQue===UserId)
    // //         {
            
    // //             this.editButtonDisable=false;
    // //         }
    // //         else{
    // //             this.editButtonDisable=true;
    // //         }


    // //     if(answeredId===UserId)
    // //     {
    // //         this.editAnswerButton=false;
    // //     }
    // //     else
    // //     {
    // //         this.editAnswerButton=true;
    // //     }
    // // }
    // }



    // answerEdit;
    // get disableButton()
    // {
        
    //     let newComments=this.allComments;
    //     let AuthorIdOfQue =newComments.AuthorId;

    //     console.log('Author Id',AuthorIdOfQue);

    //     let UserId=newComments.CurrentUserId;
    //     console.log('User Id',UserId);
    //     let answeredId=newComments.AnswerDetailsWrapper.answeredBy;
    //     console.log('Answered By Id',answeredId);
   
    //     if(AuthorIdOfQue===UserId)
    //         {
            
    //             return false;
    //         }
    //         else{
    //             return true;
    //         }


       
    // }
       
    // get editButton()
    // {

    //     let newComments=this.allComments;
    //     let UserId=newComments.CurrentUserId;
    //     console.log('UserId',UserId);
    //     let answeredId=newComments.AnswerDetailsWrapper.answeredBy;
    //     console.log('Answerer Id',answeredId)
    //     if(answeredId===UserId)
    //     {
    //         this.answerEdit=true;
    //         return false;
    //     }
    //     else
    //     {
    //         return true;
    //     }
    
    // }
    


    // @track authOrEmail;
    // BonuslyOnClickHandler(event){
    //     this.isBonusly=true;
    //     this.factid=event.currentTarget.dataset.id;
    //     console.log('this.factid '+this.factid);
    //     this.authOrEmail=event.currentTarget.dataset.email;

    // }


    // @track allComments;
    // @api get factCommentWrapper(){
    //     console.log('All comments',this.allComments)
    //     return this.allComments;
    //   }
    
    //   set factCommentWrapper(value){
    //     this.allComments={...value};
    //     console.log('Setter all commenst',this.allComments);
    //   }


    // recordId1;
    // insertAnswerOnclick(event)
    // {
    //     let tempAllComments;
    //     this.recordId1=event.target.value;
    //     console.log('Question Id'+this.recordId)
    //     insertAnswerComments({Ans:this.comment,recordId:this.recordId1})
    //         .then(result=>{
    //             console.log('Result in insertAnswer'+JSON.stringify(result));
    //             console.log('result succesres--',result.successRespObj);
    //             tempAllComments=[...result.successRespObj.AnswerDetailsWrapper];
    //             console.log('temp',tempAllComments);
    //             console.log('AnswerdetailWrapperBefore--',this.allComments.AnswerDetailsWrapper);
    //             // this.allComments.AnswerDetailsWrapper=[...tempAllComments];
    //             this.copyOfFacts.AnswerDetailsWrapper=[...tempAllComments];
    //             this.sendupdatedFactCount();
    //             console.log('AnswerdetailWrapperAfter--',this.allComments.AnswerDetailsWrapper);
    //                 if(result.successRespObj && result.successRespObj.length>0){
    //                     const evt = new ShowToastEvent({
    //                     title: "Success!",
    //                     message: "Congrats, Your comment get posted",
    //                     variant: "success",
    //                      });
    //                          this.dispatchEvent(evt);
    //                 }
                    
                
    //          })
    //           .catch(error=>{
    //             console.error(error);
    //           })

    //           this.comment=null;
    //           this.handleClearInputField();
              
    //     }


    //     @track newCount;
    //     sendupdatedFactCount(event)
    //     {
    //         console.log('event fired for updated count');
    //         this.newCount=this.copyOfFacts.AnswerDetailsWrapper.length;
    //         console.log('this.copyOfFacts.AnswerDetailsWrapper.length',this.copyOfFacts.AnswerDetailsWrapper.length)
    //         const selectedEvent = new CustomEvent("commentvaluechange", {
    //             detail: this.newCount
    //           });

    //           this.dispatchEvent(selectedEvent);

    //           console.log('event fired');
    //     }

 
    //     handleClearInputField()
    //     {
    //         this.template.querySelector('lightning-textarea').value=null;
    //     }
    //     type;

    //     handleUpvoteButtonClick(event){
    //         this.answerId = event.target.value;
    //         this.type=event.currentTarget.dataset.type;

    //         console.log(this.type);
    //         console.log('answerId',this.answerId);
    //         VoteInsertion({TypeOfVote:'up',answerOrFactId:this.answerId,ansOrFact:'answer',questionOfAnswer:this.copyOfFacts.QuestionId})
    //         .then(result=>{
    //             this.visibilityOfVotes=result.successRespObj;
    //             this.commentList=JSON.parse(JSON.stringify(this.copyOfFacts.AnswerDetailsWrapper));
    //             for(let i=0;i<this.commentList.length;i++){
    //                 if(this.answerId==this.commentList[i].ansId){
    //                 if(this.visibilityOfVotes && this.visibilityOfVotes.answerId==this.commentList[i].ansId ){
    //                     console.log('Inside if');
    //                     this.commentList[i].isUpVote=true;
    //                     this.commentList[i].isDownVote=false;
    //                     this.commentList[i].isDisabled=false;
    //                     this.commentList[i].upVotes=this.visibilityOfVotes.updatedUpVote;
    //                     this.commentList[i].downVotes=this.visibilityOfVotes.updatedDownVote;
    //                     console.log('new updated vote'+this.commentList[i].upVotes);
    //                     console.log('new updated vote'+this.commentList[i].downVotes);
    //                     this.copyOfFacts.AnswerDetailsWrapper[i]=this.commentList[i];
    //                     console.log('after');
    //                     console.log(this.copyOfFacts.AnswerDetailsWrapper[i]);
    //                     console.log(this.commentList[i]);
                         
    //                 }
    //                 else{
    //                     console.log('Inside else');
    //                     this.commentList[i].isUpVote=false;
    //                     this.commentList[i].isDownVote=false;
    //                     this.commentList[i].isDisabled=false;
    //                     this.commentList[i].upVotes=this.visibilityOfVotes.updatedUpVote;
    //                     this.commentList[i].downVotes=this.visibilityOfVotes.updatedDownVote;
    //                     console.log('new updated vote'+this.commentList[i].upVotes);
    //                     console.log('new updated vote'+this.commentList[i].downVotes);
    //                     this.copyOfFacts.AnswerDetailsWrapper[i]=this.commentList[i];
    //                 }
    //                 }
                   
    //             }
    //             let handleVoteUpEvent = new CustomEvent('upvotemessage',{
    //                 detail: {
    //                     value: this.copyOfFacts.AnswerDetailsWrapper
    //                 },
    //                 bubbles: true,
    //                 composed: true
    //                 });
    //                 this.dispatchEvent(handleVoteUpEvent);
    //             console.log(result);
    //         })
    //         .catch(error=>{
    //             console.log(error);
    //         })
            
    //     }

    //     handleDownvoteButtonClick(event){
    //         this.answerId = event.target.value;
    //         VoteInsertion({TypeOfVote:'down',answerOrFactId:this.answerId,ansOrFact:'answer',questionOfAnswer:this.copyOfFacts.QuestionId})
    //         .then(result=>{
    //             this.visibilityOfVotes=result.successRespObj;
    //             console.log(result.successRespObj);
    //             this.commentList=JSON.parse(JSON.stringify(this.copyOfFacts.AnswerDetailsWrapper));
    //             for(let i=0;i<this.commentList.length;i++){
    //                 if(this.answerId==this.commentList[i].ansId){
    //                 if(this.visibilityOfVotes.answerId==this.commentList[i].ansId){
    //                     this.commentList[i].isUpVote=false;
    //                     this.commentList[i].isDownVote=true;
    //                     this.commentList[i].isDisabled=false;
    //                     this.commentList[i].downVotes=this.visibilityOfVotes.updatedDownVote;
    //                     this.commentList[i].upVotes=this.visibilityOfVotes.updatedUpVote;
    //                     this.copyOfFacts.AnswerDetailsWrapper[i]=this.commentList[i];
    //                     // console.log('after');
    //                     // console.log(this.copyOfans.AnswerDetailsWrapper[i]);
    //                     // console.log(this.answerList[i]);
    //                     console.log('new updated vote'+this.commentList[i].upVotes);
    //                     console.log('new updated vote'+this.commentList[i].downVotes);
    //                 }
    //                 else{
    //                     console.log('Inside else');
    //                     this.commentList[i].isUpVote=false;
    //                     this.commentList[i].isDownVote=false;
    //                     this.commentList[i].isDisabled=false;
    //                     this.commentList[i].downVotes=this.visibilityOfVotes.updatedDownVote;
    //                     this.commentList[i].upVotes=this.visibilityOfVotes.updatedUpVote;
    //                     this.copyOfFacts.AnswerDetailsWrapper[i]=this.commentList[i];
    //                     console.log('new updated vote'+this.commentList[i].upVotes);
    //                     console.log('new updated vote'+this.commentList[i].downVotes);
    //                 }
    //             }
    //             }
    //             let handleVoteDownEvent = new CustomEvent('downvotemessage',{
    //                 detail: {
    //                     value: this.copyOfFacts.AnswerDetailsWrapper
    //                 },
    //                 bubbles: true,
    //                 composed: true
    //                 });
    //                 this.dispatchEvent(handleVoteDownEvent);
    //         })
    //         .catch(error=>{
    //             console.log(error);
    //         })

    //     }
    //     handleUpvoteFactButtonClick(event){
    //         this.questionId=event.target.value;
    //         VoteInsertion({TypeOfVote:'up',answerOrFactId:this.questionId,ansOrFact:'fact'})
    //         .then(result=>{
    //             console.log(result);
    //             this.factVotes=result.successRespObj;
    //             console.log(this.factVotes);
    //             this.factList=JSON.parse(JSON.stringify(this.copyOfFacts));
    //             console.log(this.factList);
    //             if(this.factVotes.questionId ){
    //                 this.factList.isUpVote=true;
    //                 this.factList.isDownVote=false;
    //                 this.factList.isDisabled=false;
    //                 this.factList.upVotes=this.factVotes.updatedUpVote;                        
    //                 this.factList.downVotes=this.factVotes.updatedDownVote;
    //                 console.log('new updated vote'+this.factList.upVotes);
    //                 console.log('new updated vote'+this.factList.downVotes);
    //                 this.copyOfFacts=this.factList;
    //                 }else{
    //                     this.factList.isUpVote=false;
    //                     this.factList.isDownVote=false;
    //                     this.factList.isDisabled=false;
    //                     this.factList.upVotes=this.factVotes.updatedUpVote;                        
    //                     this.factList.downVotes=this.factVotes.updatedDownVote;
    //                     this.copyOfFacts=this.factList;
    //                     console.log(this.factList);
    //                 }

    //                 let handleVoteFactUpEvent = new CustomEvent('upvotefactmessage',{
    //                     detail: {
    //                         value: this.copyOfFacts
    //                     },
    //                     bubbles: true,
    //                     composed: true
    //                     });
    //                     this.dispatchEvent(handleVoteFactUpEvent);
    //                 console.log(result);



    //         })
    //         .catch(error=>{
    //             console.log(error);
    //         })
    //     }
    //     handleDownvoteFactButtonClick(event){
    //         this.questionId=event.target.value;
    //         VoteInsertion({TypeOfVote:'down',answerOrFactId:this.questionId,ansOrFact:'fact'})
    //         .then(result=>{
    //             console.log(result);
    //             this.factVotes=result.successRespObj;
    //             console.log(this.factVotes);
    //             this.factList=JSON.parse(JSON.stringify(this.copyOfFacts));
    //             console.log(this.factList);
    //             if(this.factVotes){
    //                 this.factList.isUpVote=false;
    //                 this.factList.isDownVote=true;
    //                 this.factList.isDisabled=false;
    //                 this.factList.upVotes=this.factVotes.updatedUpVote;                        
    //                 this.factList.downVotes=this.factVotes.updatedDownVote;
    //                 console.log('new updated vote'+this.factList.upVotes);
    //                 console.log('new updated vote'+this.factList.downVotes);
    //                 this.copyOfFacts=this.factList;
    //                 }else{
    //                     this.factList.isUpVote=false;
    //                     this.factList.isDownVote=false;
    //                     this.factList.isDisabled=false;
    //                     this.factList.upVotes=this.factVotes.updatedUpVote;                        
    //                     this.factList.downVotes=this.factVotes.updatedDownVote;
    //                     this.copyOfFacts=this.factList;
    //                 }
    //                 let handleVoteFactDownEvent = new CustomEvent('downvotefactmessage',{
    //                     detail: {
    //                         value: this.copyOfFacts
    //                     },
    //                     bubbles: true,
    //                     composed: true
    //                     });
    //                     this.dispatchEvent(handleVoteFactDownEvent);
    //                 console.log(result);

    //         })
    //         .catch(error=>{
    //             console.log(error);
    //         })
    //     }

        


    // ///clicking on the tag 
    //  selectedTag;
    //  tagRelatedQuestion;
    //  @track allComments1;
    //  tagClickHandler(event)
    //  {
    //     let factsBasedOnTags;
    //     this.selectedTag=event.target.value;
    //     console.log('Selected Tag--',this.selectedTag);
    //     if((this.selectedTag.length>0) && (this.selectedCategory==null))
    //     FactCategoryResponse({searchArray:this.selectedTag,searchCategory:this.selectedCategory,recordType:this.recordTypeName,offSet:this.offSet}) 
    //     .then(result => {
    //         factsBasedOnTags =[...result.successRespObj];
    //         console.log('factsBasedOnTags--',factsBasedOnTags);
    //         console.log('result'+result.successRespObj);
    //         this.allComments1=[...factsBasedOnTags];
    //         console.log('This allcomments',this.allComments1)
        
    //     this.handleEvent();
    //     })
    //     .catch(error => {
    //         console.log()
    //     });



        
    // }


    // CategoryClickHandler(event)
    // {
    //     let factsBasedOnTags;
    //     this.selectedCategory=event.target.value;
    //     console.log('selectedCategory --',this.selectedCategory);
    //     if(this.selectedCategory!=null)
    //     FactCategoryResponse({searchArray:this.selectedTag,searchCategory:this.selectedCategory,recordType:this.recordTypeName,offSet:this.offSet}) 
    //     .then(result => {
    //         //this.allComments=[];
    //         factsBasedOnTags =[...result.successRespObj];
    //         console.log('factsBasedOnTags--',factsBasedOnTags);
    //         console.log('result'+result.successRespObj);
    //         this.allComments1=[...factsBasedOnTags];
    //         console.log('This allcomments',this.allComments1)
        
    //         this.handleEvent();
    //     })
    //     .catch(error => {
    //         console.log()
    //     });
    // }


       

    
        

   
    // @wire(CurrentPageReference) pageRef;
    // handleEvent(){
    //     fireEvent(this.pageRef, 'selectedCategoryTagEvent', this.allComments1);
    // }

    // recordEdit=true;
    // // editRecordHandler(event)
    // // {
    // //     this.recordEdit=true;
    // //     //this.handleEvent1();
    // // }

    // @wire(CurrentPageReference) pageRef;
    // handleEvent1(){
    //     this.recordEdit=true;
    //     console.log('AllComments',this.allComments);
    //     fireEvent(this.pageRef, 'editableData', this.copyOfFacts);
    //     console.log('Event fired',JSON.stringify(this.allComments));
    // }



    // //editing record
   

    // handleSubmit(event) {
    //     console.log('onsubmit event recordEditForm'+ event.detail.fields);
    // }
    // handleSuccess(event) {
    //     console.log('onsuccess event recordEditForm', event.detail.id);
    // }


    //     msg;
    //     @track error;
    //     recordDelete(event) {
    //         this.msg='Success';
    //         this.hideDeleteModalBox();
    //         this.recordId=event.target.value;
    //         console.log('Record Id',this.recordId);
    //         deleteRecord(this.recordId)
    //             .then(() => {
    //                 this.updateRecordView();
    //                 console.log('Delete event fired');
    //                 this.dispatchEvent(
    //                     new ShowToastEvent({
    //                         title: 'Success',
    //                         message: 'Record deleted',
    //                         variant: 'success'
    //                     })
    //                 );
    //                 // Navigate to a record home page after
    //                 // the record is deleted, such as to the
    //                 // contact home page
                   
    //             })
    //             .catch(error => {

                   
    //             });
    //     }

    //     msg;
    //     @wire(CurrentPageReference) pageRef;
    //     updateRecordView() {
            
    //         this.msg='Success';
    //         console.log('event fired');
    //         fireEvent(this.pageRef, 'getupdatedFeedAfterDelete', this.msg);
    //         this.dispatchEvent(updateEvent);
    //     } 


    // passToParent(event)
    // {
    //     console.log('false');
    //     this.isBonusly=false;
    // }

    // @track isDeleteShowModal = false;

    // showModalBox() {  
    //     this.isDeleteShowModal = true;
    //     console.log('isDelete Show modal true');
    // }

    // hideDeleteModalBox() {  
    //     this.isDeleteShowModal = false;
    //     console.log('isDelete Show modal false');
    // }
    
}