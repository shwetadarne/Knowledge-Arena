import { LightningElement,api } from 'lwc';

export default class DynamicSearchDetail extends LightningElement {
    @api 
    myq;
    isShowModal=true;
    copyOfApi;
    hideModalBox(){
        this.isShowModal=false;
    }
    connectedCallback(){
        // this.copyOfApi=JSON.parse(JSON.stringify((this.myq)));
    }
    
}