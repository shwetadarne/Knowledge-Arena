import createUpdateProject from '@salesforce/apex/CreateUpdateProjectController.createUpdateProject';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { CurrentPageReference } from 'lightning/navigation';
import { CloseActionScreenEvent } from 'lightning/actions';
import { LightningElement,track,api,wire } from 'lwc';

export default class CreateUpdateOnewerx extends LightningElement {
    @track spinner = false;
    @api recordId;
    @track sendSurvey = false;
    @track validation = '';

    @wire(CurrentPageReference)
        getStateParameters(currentPageReference) {
            if (currentPageReference) {
                this.recordId = currentPageReference.state.recordId;
            }
        }

        

    renderedCallback(){
        this.spinner = true;
        var projectId = this.recordId;


            createUpdateProject({projectId:projectId,sendSurvey:this.sendSurvey})
            .then(result => {
                var message;
                message = result;
                message = message.split(':');
                var boolValue = message[1];
                var failureMessage = message[0];
                if(boolValue == 'false'){

                    const toastEvent = new ShowToastEvent({
                        title:'Error',
                        message:failureMessage,
                        variant:'Error',
                      })
                      this.dispatchEvent(toastEvent);
                      
                this.spinner = false;
                this.dispatchEvent(new CloseActionScreenEvent());

                }
                else{
                    
                 const toastEvent = new ShowToastEvent({
                    title:'Record Sent To UIPath',
                    message:failureMessage+':'+boolValue,
                    variant:'success',
                  })
                  this.dispatchEvent(toastEvent);
                  
            this.spinner = false;
            this.dispatchEvent(new CloseActionScreenEvent());

                }

            })
            
            .catch(error => {
                this.error = error;
            });
        

        
        
            
            
    }


}