import { LightningElement,api, track } from 'lwc';
import QuestionTagMethods from '@salesforce/apex/QuestionTagController.QuestionTagMethods';

export default class Search extends LightningElement {
    factDetailAndComments=false;
    openfactDetailAndComments=false;
    openfactDetailAndComments1=false;
    openQuestionAndAnswerDetail=false;
    @api searching;
    @api searchingFacts;
    @api openSearch;
    @api filteredBy;   
    @api searchWord; 
    @track
    isNoResultsFound;
    connectedCallback(){
        // console.log(this.searchResults);
        // this.searchResults=this.searchRecords;
        
        console.log('in search'+this.searching);
        console.log('in search'+this.searchingFacts);
        console.log(this.filteredBy);
        console.log(this.searchWord);
        console.log(this.searching.length);
        // if(this.searching.length==0){
        //     this.isNoResultsFound=true;
        //     console.log('plane'+this.isNoResultsFound);
        //     console.log(this.searching.length);
        // }
        // else{
        //     this.isNoResultsFound=false;
        //     console.log('not'+this.isNoResultsFound);
        // }
    }
    // openQuestionDetail(){
    //     this.questionDetailAnswer=true;
    // }
    // cardOnClickHandler(){
    //     this.openfactDetailAndComments=true;
    // }
    // cardOnClickHandler1(){
    //     this.openfactDetailAndComments1=true;
    // }
    cardOnClickHandler(event){
        
        // if(this.openQuestionAndAnswerDetail===true){
        //     this.openQuestionAndAnswerDetail=false;
        // }
        // else{
        //     this.openQuestionAndAnswerDetail=true;
        // }
        this.openQuestionAndAnswerDetail=true;
       
        //console.log(this.searchingFacts);
    }
    cardOnClickHandler1(){
        this.openfactDetailAndComments=true;
    }
    offSet=0;
    isDisableLoadMore=false;
    loadMoreClick(){
        this.isNoResultsFound=false;
        this.offSet=this.offSet+10;
        QuestionTagMethods({filterType:this.filteredBy,searchKey:this.searchWord,offSet:this.offSet})
        .then(result=>{
            console.log(result);
            this.searchRecords=result.successRespObj;
            this.searching.concat(this.searchRecords);
            if(this.searchRecords.length<=10){
                this.isDisableLoadMore=true;
                //console.log('in loadmore '+this.loadedData.length);
            }
        })
        .catch(error=>{
            console.log(error);
        });
    }
}