import { LightningElement,track,api,wire } from 'lwc';

import postFact from '@salesforce/apex/factController.postFact';
import allTagList from "@salesforce/apex/factController.getAllTags"



import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Category__c from '@salesforce/schema/Question__c.Category__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Question_OBJECT from '@salesforce/schema/Question__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent'; 


import { fireEvent } from 'c/pubsub';


export default class PostFact extends LightningElement {

    @track askedFact;
    @track decsriptionText;
    
    @track isShowModal=false;


    @track postedFact;
    @track decsription;
    @track pickListTag2;
    @track category;
    postClick(){
        //this.validateFields();
        this.isShowModal = false;
        this.postedFact=this.askedFact;
        this.decsription=this.descriptionText;
        this.pickListTag2=this.pickListTag;
       
        this.category=this.selecteCat;
        console.log('postclick'+this.pickListTag);
        console.log(this.postedSubQuestion);
        console.log(this.decsription);
        this.handleSuccess();
        console.log(this.pickListTag.length);

        this.clickHandler();
      
      }


clickHandler(){
 console.log('creating question')
 postFact({sub:this.postedFact,main:this.decsription,val:this.pickListTag2,cat:this.category})
    .then(result=>{
      console.log('in result');
      console.log(result)
 })
 .catch(error=>{
      console.error(error);
  })
}
    
    
    


showModal(event){
        this.isShowModal=true;
        console.log('Showmodal True');
   }
   hideModalBox() {  
       this.isShowModal = false;
   }


    
    factHandleChange(event){
        this.askedFact=event.target.value;
        
        console.log(this.askedSubQuestion);
    }
    factDisHandleChange(event){
        this.descriptionText=event.target.value;
        console.log("Description: " + this.descriptionText)
    
    }




    @track template;
    @track category;
    @track pickListTag;


    @track allTags;
    @track picklistOptions;
 
    @wire(allTagList, {})
   objectData({ error, data }) {
 
        if (data) {
            try {
                this.allTags = data; 
                let options = [];
                 
                for (var key in data) {
                    // Here key will have index of list of records starting from 0,1,2,....
                    options.push({ label: data[key].Name, value: data[key].Name });
 
                    // Here Name and Id are fields from sObject list.
                }
                this.picklistOptions = options;
                 
            } catch (error) {
                console.error('check error here', error);
            }
        } else if (error) {
            console.error('check error here', error);
        }
 
    }


    @track allValues=[];
    handleChange(event)
    {
        if(!this.allValues.includes(event.target.value))
        {
            this.allValues.push(event.target.value);
        }
        // if(this.allValues.length<1)
        // {
        //   this.buttonTrue=false;
        // }
        //console.log(this.allValues);

        this.pickListTag = this.allValues.join(',');
    }



    handleRemove(event)
    {
        const removeValue=event.target.name;
        this.allValues.splice(this.allValues.indexOf(removeValue),1);
    }




    ////adding tag
    @track tagModal=false;
    openTagModal(){
        this.tagModal=true;
    
     }
    
     closeTagModal(){
        this.tagModal=false;
     }





     //category picklist
     @wire(getObjectInfo, { objectApiName: Question_OBJECT })
    categoryInfo;

    @wire(getPicklistValues,
        {
            recordTypeId: '$categoryInfo.data.defaultRecordTypeId',
            fieldApiName: Category__c
        }
    )
    categoryValue;


    @track selecteCat;
    handleCategoryChange(event){
      this.selecteCat=event.target.value;
      
    }



    @track arrLength=this.allValues.length;
    get disableButton(){
        return !( this.selecteCat && this.askedFact &&(this.arrLength<2));
    }
  


    handleSuccess (){
        const evt = new ShowToastEvent({
            title: "Success!",
            message: "Congrats, Fact has been added successfully",
            variant: "success",
        });
        this.dispatchEvent(evt);
    }
 
}