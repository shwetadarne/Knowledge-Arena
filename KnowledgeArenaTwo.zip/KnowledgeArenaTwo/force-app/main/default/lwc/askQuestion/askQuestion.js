import { LightningElement,api ,wire,track} from 'lwc';
import {CurrentPageReference} from 'lightning/navigation'
import { fireEvent } from 'c/pubsub';
import { registerListener, unregisterAllListeners } from 'c/pubsub'; 
import userDeatil from '@salesforce/apex/enterQuestionDetails.insertUserDetails';
import userDeatilForDisplay from '@salesforce/apex/enterQuestionDetails.getUserDetails';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class AskQuestionCmp extends LightningElement {
     @api
    getPostedSubQuestion;
    @api
    getPostedQuestion;
    
    isShowCommentCard=false;
    noOfTimesButtonPressed=0;
    
    isShowModal=false;
    questionFeed=[];
    @track
    askedSubQuestion;
    @track
    askedQuestion;
    postedQuestion;
    postedSubQuestion;
    tagForQuestion;
    tag;
    @track
    detailsOfQuestion;

    @wire(CurrentPageReference)pageRef;
    // img=personimage;
    showModal(event){
        this.isShowModal=true;
   }
   hideModalBox() {  
       this.isShowModal = false;
   }
     questionSubHandleChange(event){
        this.askedSubQuestion=event.target.value;
        console.log(this.askedSubQuestion);
   }
   questionHandleChange(event){
    this.askedQuestion=event.target.value;
    console.log(this.askedQuestion);
   }
   tagHandleChange(event){
   this.tag=event.target.value;
   }
    postClick(){
        this.isShowModal = false;
        this.postedSubQuestion=this.askedSubQuestion;
        this.postedQuestion=this.askedQuestion;
        this.tagForQuestion=this.tag;
        console.log(this.postedSubQuestion);
        console.log(this.postedQuestion);
        this.clickHandler();
    }
    clickHandler(){
     console.log('creating question')
     userDeatil({sub:this.postedSubQuestion,main:this.postedQuestion,tag:this.tagForQuestion})
        .then(result=>{
            
          console.log('in result');
          console.log(result)
     })
     .catch(error=>{
          console.error(error);
      })
   }
// **************** for subsub event handling


    UserClickHandler(event){
        this.name=event.target.name;
        fireEvent(this.pageRef,
            "userPublisher",this.name);
        this.getUserDetails();
       
        
   }
   getUserDetails(){
    userDeatilForDisplay()
        .then(result=>{
            this.allQuestions=result;
          console.log('in result');
          console.log(this.allQuestions)
     })
     .catch(error=>{
          console.error(error);
      })
      fireEvent(this.pageRef,
            "userPublisher",this.allQuestions);
   }

    showCommentCard(){
        this.noOfTimesButtonPressed=this.noOfTimesButtonPressed+1;
        console.log(this.noOfTimesButtonPressed);
        if((this.noOfTimesButtonPressed%2)==0){
            this.isShowCommentCard=false;
            console.log('in comment card');
        }
        else{
            this.isShowCommentCard=true;
        }
    }

    connectedCallback(){
        registerListener("myfirstpubsub", this.getDetails, this); 
    }
    disconnectedCallback(){
        //console.log('child disconnected call back');
        unregisterAllListeners(this); 
    }
    getDetails(eventData){
        this.detailsOfQuestion=eventData;
        console.log('Details'+this.details)
    }
}