import { LightningElement,api,wire } from 'lwc';
import QuestionCategoryResponse from '@salesforce/apex/QuestionTagController.QuestionCategoryResponse';
// import QuestionTagResponse from '@salesforce/apex/QuestionTagController.QuestionTagResponse';



export default class QuestionDetails extends LightningElement {
   @api categoryWrapper;
   questionsFromParent


   connectedCallback()
   {
     console.log('Question Wrapper'+this.categoryWrapper)
   }
   
    @api
    get recordFromParent()
    {
       // console.log('Wrapper2'+this.questionsFromParent.successRespObj)
        //console.log(this.questionsFromParent[0].QuestionDesc);
        return this.questionsFromParent;
    }

    set recordFromParent(value)
    {
        this.questionsFromParent=value;
        console.log('WrapperSet'+this.questionsFromParent);
       // console.log(this.questionsFromParent[0].QuestionDesc);
    }

    
    isExpand=false;
    openModalForTag=false;
    expandOnClick(){
        this.isExpand=true;
        console.log('test'+categoryWrapper);
    }
    closeHandler(){
         this.isExpand=false;
    }


    //clicking on the category show results
    selectedCategory;
    categoryRelatedQuestion;
    newWrapper;
    categoryClickClickHandler(event){
    this.selectedCategory=event.target.value;
    QuestionCategoryResponse({searchCategory:this.selectedCategory}) 
        .then(result => {
            this.categoryWrapper =result.successRespObj;
            console.log('result'+result.successRespObj);
            console.log(this.categoryRelatedAuestion);
            //this.questionFilterCategory=true;
            
        })
        .catch(error => {
            console.log();
        });

    }

    // previousHandler(){
    //     this.dispatchEvent(new CustomEvent(this.newWrapper));
    // }
        
    



     ///clicking on the tag 
     selectedTag;
     tagRelatedQuestion;
     tagClickHandler(event)
     {
        this.selectedTag=event.target.value;
        QuestionTagResponse({searchArray:this.selectedTag}) 
        .then(result => {
            this.categoryWrapper = result.successRespObj;
            console.log('result'+result.successRespObj);
            
      
        })
        .catch(error => {
            console.log()
        });

        
    }

   

}