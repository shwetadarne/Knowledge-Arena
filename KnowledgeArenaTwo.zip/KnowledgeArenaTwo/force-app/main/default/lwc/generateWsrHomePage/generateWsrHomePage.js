import { LightningElement,track } from 'lwc';
import recalculateWeeklyStatusReportFromHome from '@salesforce/apex/GenerateWSRCtrl.recalculateWeeklyStatusReportFromHome';
import createWeeklyStatusReportFromHome from '@salesforce/apex/GenerateWSRCtrl.createWeeklyStatusReportFromHome';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class GenerateWsrHomePage extends LightningElement {

    @track isModalOpen = false;
    @track isRecalculateModalOpen = false;

    handleClick() {
        this.isModalOpen = true;
        this.isRecalculateModalOpen = false;
    }

    handleRecalculateClick(){
        this.isModalOpen = false;
        this.isRecalculateModalOpen = true;
    }

    closeModalHomePage() {
        this.isModalOpen = false;
        this.isRecalculateModalOpen = false;
    }

    submitDetailsHomePage() {

        createWeeklyStatusReportFromHome()
            .then(result => {

                this.isModalOpen = false;

                if (result == 'failed') {
                    this.showToast('Some error', 'error');
                } else {
                    this.showToast('Successfully Generated!', 'success');
                }
            })
            .catch(error => {
                this.error = error;
            });

    }

    onButtonClick(event) {
        var buttonName = event.target.dataset.name;
        
        recalculateWeeklyStatusReportFromHome({ week: buttonName })
            .then(result => {
                this.showToast(result.message, result.status);
                this.isRecalculateModalOpen = false;
            })
            .catch(error => {
                this.error = error;
                this.showToast(error, 'error');
            });
    }

    showToast(title, variant) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant
        });
        this.dispatchEvent(event);
    }
}