import { LightningElement,api,track,wire } from 'lwc';
//for category
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Category__c from '@salesforce/schema/Question__c.Category__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Question_OBJECT from '@salesforce/schema/Question__c';
//for tag
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import allTagList from '@salesforce/apex/factController.getAllTags';
import FactCategoryResponse from '@salesforce/apex/QuestionTagController.QuestionCategoryResponse';
import allQuestionsAndFacts from '@salesforce/apex/QuestionTagController.allQuestionsAndFacts';
import { CurrentPageReference } from 'lightning/navigation';
import { registerListener, unregisterAllListeners } from 'c/pubsub';

export default class FactTab extends LightningElement {
   openPostFactModal=false;
    
    @api factTabName='Fact';
    @track recordTypeName='Fact';


   postFactHandler(){
    this.openPostFactModal=true;
    }
    @wire(CurrentPageReference) pageRef; 
   connectedCallback()
   {
        this.getFeed();
        registerListener('selectedCategoryTagEvent', this.tagrelatedfacts, this);
        registerListener('getupdatedFeedAfterDelete', this.getupdatedFeed, this);
   }


  @track  allFactsComments;
  LoadedData;
  offSet=0;
  flag;
  @track
  isDisableLoadMore=false;
  @track isLoading = false;
   getFeed(){
        this.isLoading = true;
        allQuestionsAndFacts({recordType:this.recordTypeName,offSet:this.offSet})
        .then(result=>{
            
            if(result.successRespObj && result.successRespObj.length > 0){
                console.log('result'+result.successRespObj);
            console.log(result);
           // console.log('Parse' +JSON.parse(result.successRespObj));
           this.flag=0;
            this.allFactsComments=[...result.successRespObj];
             this.allQuestionAnswer=[...result.successRespObj];
             if(this.allFactsComments.length<10){
                this.isDisableLoadMore=true;
                console.log(this.isDisableLoadMore);
                }
    
            }
            this.isLoading = false;
     })
     .catch(error=>{
          this.isLoading = false;
          console.error(error);
      })  
   }



   loadMoreClick(){
    this.offSet=this.offSet+10;
    if(this.flag==0){
        this.isLoading = true;
    allQuestionsAndFacts({recordType:this.recordTypeName,offSet:this.offSet})
        .then(result=>{
            if(result.successRespObj && result.successRespObj.length > 0){
                console.log('result'+result.successRespObj);
            console.log(result);
           // console.log('Parse' +JSON.parse(result.successRespObj));
           this.LoadedData=[...result.successRespObj];
           this.allFactsComments=this.allFactsComments.concat(this.LoadedData);
           if(this.LoadedData.length<=10){
            this.isDisableLoadMore=true;
            }
    
            }
            this.isLoading = false;
     })
     .catch(error=>{
          console.error(error);
      })  
   }
   else if(this.flag==1){
    this.isLoading = true;
    FactCategoryResponse({searchArray:this.selectedTags,searchCategory:this.selectedCategory,recordType:this.recordTypeName,offSet:this.offSet}) 
            .then(result => {
            this.allFactsComments =[...result.successRespObj];
            console.log('result'+result.successRespObj);
            this.LoadedData=[...result.successRespObj];
           this.allFactsComments=this.allFactsComments.concat(this.LoadedData);
            
      
        })
        .catch(error => {
            console.log(error);
        });
        this.isLoading = false;
   }
}

   @wire(getObjectInfo, { objectApiName: Question_OBJECT })
   categoryInfo;

   @wire(getPicklistValues,
       {
           recordTypeId: '$categoryInfo.data.defaultRecordTypeId',
           fieldApiName: Category__c
       }
   )
   categoryValue;


@track picklistOptions;
@track tagsfromApex;
@wire(allTagList, {})
tagsfromApex({ error, data }) {

   if (data) {
      try {
           let options = [];
           for (var key in data) {
               options.push({ label: data[key].Name, value: data[key].Name });
           }
           this.picklistOptions = options;

       } catch (error) {
           console.error('check error here', error);
       }
   } else if (error) {
       console.error('check error here', error);
   }
}


@track selectedTags=[];

handleGetSelectedTag(event)
{
    
 if(!this.selectedTags.includes(event.target.value))
 {
    
 this.selectedTags.push(event.target.value);
 console.log(this.selectedTags);

}

}

handleRemoveTag(event)
   {
       const removeValue=event.target.name;
       this.selectedTags.splice(this.selectedTags.indexOf(removeValue),1);
   }

   handleFactMessage(event){
    if(event.detail.value=='factsuccess'){
        console.log('in event.detail.value');
        this.getSelectedTagQuestion();
        this.getFeed();
        
    }

   }
   handleFactDownVotes(event){
    if(event.detail.value=='factdownVotesuccess'){
        console.log('in event.detail.value');
        this.getSelectedTagQuestion();
        this.getFeed();
        
    }
   }


   selectedCategory;
   handleCategoryChange(event) {
       this.selectedCategory = event.target.value;
   }


    ///filtering of facts and tags
   
    getSelectedTagQuestion()

    {
        console.log('Onclick1');
        console.log('Slecteed Ctaegory'+this.selectedCategory);
        console.log('Tags'+this.selectedTags);
        this.isLoading = true;
        //category selected
        if((this.selectedTags.length<=0) && (this.selectedCategory!=null  || this.selectedCategory=='None'))
         {
            console.log('Onclick');
            //this.selectedCategory=null;
            FactCategoryResponse({searchArray:this.selectedTags,searchCategory:this.selectedCategory,recordType:this.recordTypeName,offSet:this.offSet}) 
            .then(result => {
            this.allFactsComments =[...result.successRespObj];
            console.log('result'+result.successRespObj);
            this.flag=1;
            
            this.isLoading = false;
        })
        .catch(error => {
            console.log()
        });
        }

        //tags selected
        else if((this.selectedTags.length>0) && (this.selectedCategory==null || this.selectedCategory=='None'))
         {
            console.log('Onclick Tag');
            FactCategoryResponse({searchArray:this.selectedTags,searchCategory:this.selectedCategory,recordType:this.recordTypeName,offSet:this.offSet}) 
            .then(result => {
            this.allFactsComments =[...result.successRespObj];
            console.log('result'+result.successRespObj);
            this.flag=1;
            this.isLoading = false;
      
        })
        .catch(error => {
            console.log()
        });
   }
   
   //both category and tag selected
   else if((this.selectedTags.length>0) && (this.selectedCategory!=null || this.selectedCategory=='None'))
   {
    console.log('Onclick Tag and Category');
    //this.selectedCategory=null;
        FactCategoryResponse({searchArray:this.selectedTags,searchCategory:this.selectedCategory,recordType:this.recordTypeName,offSet:this.offSet}) 
        .then(result => {
        this.allFactsComments =[...result.successRespObj];
        console.log('result'+result.successRespObj);
        this.flag=1;
        this.isLoading = false;
  
    })
    .catch(error => {
        console.log()
    });
   }
}


     handleClick(event)
     {
        //this.value=null;
        this.multiValue=null;
        this.selectedTags=null;
        this.selectedCategory=null;
     }



     setfalse(event)
     {
        this.openPostFactModal=false;
     }


     @track message;
     getUpdatedValue(event)
     {
        this.message=event.detail;
        if(this.message=='Success')
        {
            this.getFeed();
        }
     }

      
     tagrelatedfacts(event)
     {
        this.allFactsComments=event;
        //this.allFactsComments=[...allData];
        console.log('allfactsCommments',this.allFactsComments);
     }


     get options() {
        
        return [
                 { label:'None', value:'None'},
                 { label: 'My Approved Facts', value: 'My Approved Facts'},
                 { label: 'My Rejected Facts', value: 'My Rejected Facts'},
                 { label: 'Mulesoft', value: 'Mulesoft' },
                 { label: 'Salesforce', value: 'Salesforce' },
                 { label: 'Finance', value: 'Finance' },
                 { label: 'Marketing', value: 'Marketing' },
                 { label: 'Human Resources', value: 'Human Resources' },
                 { label: 'RPA', value: 'RPA' },
                 { label: 'Architecture', value: 'Architecture' },
                 { label: 'Others', value: 'Others' },
                 
               ];
        }


        deleteMessage;
        getupdatedFeed(event)
        {
            this.deleteMessage=event;
            //console.log('message',event);
            if(this.deleteMessage=='Success')
            {
                this.getFeed();
            }
        }
}