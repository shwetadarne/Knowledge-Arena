import { LightningElement,api,track} from 'lwc';
import giveBonus from '@salesforce/apex/BonuslyApiCallouts.giveBonus';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


export default class BonuslyCmp extends LightningElement {
   @api recipent;
   @api articleid;
   @api type;
   amount;
   message;
   hashtag;
   bonusResponse;
   @track closeModal=true; 
    closeHandler(){
    this.closeModal=false;
    const custEvent = new CustomEvent('callpasstoparent', {detail: 'false'});
    this.dispatchEvent(custEvent);
    }
    connectedCallback()
    {
        console.log(this.recipent);
        console.log('again');
        console.log(this.articleid);
        console.log(this.type);



    }
    amounthanlder(event)
    {
        this.amount=event.target.value;

    }
    msghanlder(event)
    {
        this.message=event.target.value;

    }
    taghanlder(event)
    {
        this.hashtag=event.target.value;

    }
    submitHandler()
    {
        // this.closeModal=false;
        giveBonus({userId:this.recipent,amount: this.amount,msg:this.message,hasgtag:this.hashtag,articleid:this.articleid,rectype:this.type})
        .then(result=>{
            this.bonusResponse=result;
            console.log('bonus id '+result);
            console.log(this.closeModal);
            const custEvent = new CustomEvent('callpasstoparent', {detail: 'false'});
            this.dispatchEvent(custEvent);
            this.closeModal=false;
            console.log(this.closeModal);


            if(this.bonusResponse==true)
            {
                this.handleSuccess(this.bonusResponse);


            }
            else
            {
                this.handlefail(this.bonusResponse);
               


            }



        })
        .catch(error=>{
            console.log(error);
        })
    }
    handleSuccess(){
    const evt = new ShowToastEvent({
        title: "Success!",
        message: "You have successfully given Bonusly! ",
        variant: "success",
    });
   this.dispatchEvent(evt);
}
 handlefail(){
    const evt = new ShowToastEvent({
        title: "Failed!",
        message: "You cannot give bonus points to yourself",
        variant: "warning",
    });
   this.dispatchEvent(evt);
}
}