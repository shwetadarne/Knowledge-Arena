import { LightningElement } from 'lwc';

export default class OuterRankingLeaderBoard extends LightningElement {}