import { LightningElement,api } from 'lwc';
const columns = [
    { label: 'Weekly Rank', fieldName: 'name' },
    { label: 'Profile Picture', fieldName: 'website', type: 'url' },
    { label: 'Nmae', fieldName: 'phone', type: 'phone' },
    { label: 'Balance', fieldName: 'amount', type: 'currency' },
    { label: 'Career Rank', fieldName: 'closeAt', type: 'date' },
];

export default class LeaderboardDetails extends LightningElement {
    
    data = [];
    columns = columns;
    showLeaderBoard=true;
    connectedCallback() {
        //const data = generateData({ amountOfRecords: 100 });
        //this.data = data;
    }
    
    hideModalBox(){
        this.showLeaderBoard=false;
    }
}