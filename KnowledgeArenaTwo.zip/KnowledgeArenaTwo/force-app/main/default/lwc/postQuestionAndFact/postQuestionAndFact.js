import { LightningElement,track,api,wire } from 'lwc';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Category__c from '@salesforce/schema/Question__c.Category__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Question_OBJECT from '@salesforce/schema/Question__c';

import getSearchedTags from '@salesforce/apex/factController.getSearchedTags';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import insertQuestion from '@salesforce/apex/QuestionAdapter.insertQuestion';
import updateData from '@salesforce/apex/QuestionAdapter.updateData';
import getTag from '@salesforce/apex/QuestionAdapter.getTag';
import getAllQuestion from '@salesforce/apex/QuestionDomain.getAllQuestion';
import { CurrentPageReference } from 'lightning/navigation';
import { registerListener, unregisterAllListeners } from 'c/pubsub';
import questionDetails from '@salesforce/apex/MyQuestionDetails.questionDetails';


export default class PostQuestionAndFact extends LightningElement {
    //@api getCategoryFromParent;
    prevSize=1;
    cominationlst;
    @track filterlist = [];
    @api showModal;
    @track allData={QuestionTitle:'',tagDetailsWrapper:[]};
    isEditQuestion;
    @track
    myQuestion;
    @track containsAllTags;
    @track categoryValue;
    selectedCategoryValue

    @wire(getObjectInfo, { objectApiName: Question_OBJECT })
   categoryInfo;
   

   @wire(getPicklistValues,
       {
           recordTypeId: '$categoryInfo.data.defaultRecordTypeId',
           fieldApiName: Category__c
       }
   )
   categoryValue;


    stopwords = ['i','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s',
    't','u','v','w','x','y','z','me','my','myself','we','our','ours','ourselves','you','your','yours',
    'yourself','yourselves','he','him','his','himself','she','her','hers','herself','it','its',
    'itself','they','them','their','theirs','themselves','what','which','who','whom','this','that'
    ,'these','those','am','is','are','was','were','be','been','being','have','has','had','having',
    'do','does','did','doing','a','an','the','and','but','if','or','because','as','until','while',
    'of','at','by','for','with','about','against','between','into','through','during','before','after',
    'above','below','to','from','up','down','in','out','on','off','over','under','again','further','then'
    ,'once','here','there','when','where','why','how','all','any','both','each','few','more','most',
    'other','some','such','no','nor','not','only','own','same','so','than','too','very','s','t','can',
    'will','just','don','should','now','What','Why','How','The'];
    comination;
   // @api showmodal;

    @api isShowAskQuestion=false;
    //isShowAskQuestion=this.showModal;
    tagValue;
   
    opensldsbox=false;
    @track
    opensldsBoxTitle=false;
    tabName;
    fireArray=[];
    buffer=0;
    openActivityModal=false;
    @api get name()
    {
        return this.tabName;
    }

    set name(value)
    {
        this.tabName=value;
    }

    //@track allData;
    // @api  get editwrapper(){
    //     console.log('All comments',this.allData)
    //     return this.allData;
    //   }
    
    //   set editwrapper(value){
    //     this.allData=value;
    //     console.log('Setter all commenst',this.allData);
    //   }


      
    @wire(CurrentPageReference) pageRef; 
    connectedCallback()
    {
        registerListener('editableData', this.editEvent,this);
        getAllQuestion()
        .then(result=>{
            this.cominationlst=result;
            console.log( this.cominationlst);
            
        })
        .catch(error=>{
            console.log('error');
        })

       
        //this.editEvent();
        
    }

    
   @track allTags=[];
    editEvent(event)
    {
        this.isEditQuestion=true;
        //console.log('Event',allComments)
        let allData2=event;
        this.allData={...allData2};
        //=this.allData.tagDetailsWrapper;
        
        //this.allData=event;
        console.log('AllData',this.allData);
        for (let i = 0; i < this.allData.tagDetailsWrapper.length; i++) {
            this.allTagValues.push(this.allData.tagDetailsWrapper[i].tagName);
          }
    }
    
    
    hidePostQuestion(){
        this.allData=[];
        this.allData=null;
        this.allTagValues=[];
        this.isShowAskQuestion=false;
        this.isEditQuestion=false;
        console.log('It became false');
        //this.sendUpdatedModalValue();
        const updateEvent= new CustomEvent("getupdatedmodalvalue",{detail:this.isShowAskQuestion});
     this.dispatchEvent(updateEvent);
    }

    questionTitleHandler()
    {
        // setTimeout(function(){
        //     this.filterlist=[];
        // this.opensldsBoxTitle=false;
        // },300);
        
        this.filterlist=[];
        this.opensldsBoxTitle=false;
    }
    askedQuestion;
    //////////////////////////////////////////End DYnamic Search Login////////////////////////////////////////////////////////////////////

    questionTitleChange(event)
    {   
        var newthis=this;
        this.askedQuestion=event.target.value;
        let text=event.target.value;
        if(text.length==0)
        {
             this.opensldsBoxTitle=false;
             this.fireArray=[];

        }
        let myArray = text.split(" ");
        console.log('my array'+myArray);
        myArray = myArray.filter((x, i, a) => a.indexOf(x) === i);   //remove duplicates keywords   
        console.log('this.prevSize '+this.prevSize);
        console.log('myArray.length  '+myArray.length);
        if(this.prevSize!=myArray.length)
        {
            console.log('new word inserted');
            let word=myArray[this.prevSize-1];
            
            console.log('new word'+word);
            myArray = myArray.filter( x => !newthis.stopwords.includes(x) );
           
                newthis.fireArray=myArray;
                console.log(' assign new array'+myArray);
                console.log(' assign new array'+newthis.fireArray);
                newthis.fireArray = newthis.fireArray.filter(Boolean); //remove null values
                newthis.fireArray = newthis.fireArray.filter((x, i, a) => a.indexOf(x) === i);
                    if(newthis.fireArray.length>1)
                    {
                        newthis.filterlist=[];
                        console.log('fired from 2'+newthis.fireArray);
                        this.getCombinationFunction(newthis.fireArray);
                    }
                    this.prevSize=myArray.length;
        }

        if(this.prevSize>myArray.length)
        {
            let newMyArray = text.split(" ");
            newMyArray = newMyArray.filter((x, i, a) => a.indexOf(x) === i);   //remove duplicates keywords   
            newMyArray = newMyArray.filter( x => !newthis.stopwords.includes(x) );
            console.log('newMyarray '+newMyArray);
            newMyArray = newMyArray.filter(Boolean);
            if(newMyArray.length>1)
            {
                newthis.filterlist=[];
                console.log('null filter list'+newthis.filterlist);
                console.log('newMyarray FIRED from 2'+newMyArray);
                this.getCombinationFunction(newMyArray);
            }
            this.prevSize=newMyArray.length;

        }
        
    }
    getCombinationFunction(a)
    {
    var testThis=this;
	function combinationUtil(arr,data,start,end,index,r,clist)
	{

		if (index == r)
		{
            clist.forEach(myFunction);
            function myFunction(item) {
            if (index == r)
            {
                let str='';
                let i=0;
                for (let j=0; j<r; j++)
                {
                    //console.log('data:  '+data[j]);
                    if((item.Question_Header__c).includes(data[j]))
                    {
                        i++;
                    }
                }
                if(i==r)
                {
                    console.log('flit'+testThis.filterlist);
                    testThis.filterlist.push(item);
                    testThis.filterlist = testThis.filterlist.filter((x, i, a) => a.indexOf(x) === i);   //remove duplicates keywords   
                    testThis.buffer=1;
                    testThis.opensldsBoxTitle=true;
                    console.log('buffer '+testThis.buffer);
                    console.log('flit'+testThis.filterlist);
                    console.log('flit'+testThis.filterlist[0].Question_Header__c);
                }
                else
                {
                    console.log('not found');
                }

            }
            }
            
		}
		
		
		for (let i=start; i<=end && end-i+1 >= r-index; i++)
		{
			data[index] = arr[i];
			combinationUtil(arr, data, i+1, end, index+1, r,clist);
		}
	}
	
	function printCombination(arr,n,r,clist)
	{
		let data = new Array(r);
		
		combinationUtil(arr, data, 0, n-1, 0, r,clist);
	}
    let arr=arguments[0];
    console.log('inside js function'+arr);
	let n = arr.length;
    console.log('lenth of array'+n);
    let r = Math.round((n * 60) / 100);
	printCombination(arr, n, r,this.cominationlst);	

    }

    //////////////////////////////////////////End DYnamic Search Login////////////////////////////////////////////////////////////////////

    questionDescription;
    questionDesHandleChange(event)
    {
        this.questionDescription=event.target.value;
        console.log("Description: " + this.questionDescription)
    }


    @track containsTag;
    containsAllTags=[];
    handleChangeTag(event){

        if(event.target.value.length>0){
             this.opensldsbox=true;
        }
        else{
            this.opensldsbox=false;
        }
        
        this.containsAllTags=[];
        this.containsTag=event.target.value;
        console.log(event.target.value);
        
        getSearchedTags({tagSearched:this.containsTag})
        .then(result => {
            this.containsAllTags = result;
            console.log(result);
      
        })
        .catch(error => {
            console.log(error);
        });
		
    }

   


    //for inserting a new tag
    @track allTagValues=[];
    @track isTagAdded;
    postTagTosf;
    inputTag;
    handleEnter(event) {
    
    if(event.keyCode === 13) {
            //this.postTagTosf=this.containsTag;
            this.postTagTosf=event.target.value;
            console.log('postTagTosf',event.target.value);
            if(this.postTagTosf!='')
            {
            getTag({tagName:this.postTagTosf})
            .then(result=>{
                this.allTagValues.push(this.postTagTosf);
                this.postTagTosf=null;
                this.inputTag=null;
                console.log('postTagto Sf empty');
                this.isTagAdded=result;
                console.log(this.isTagAdded);
             })
             .catch(error=>{
                 console.error(error);
             })

           
            
            
            this.containsTag='';
            this.inputTag='';
        }
     }
     

       
    }



    //for getting all tags
   
    findTag;
    handleChangeSearchedTag(event)
      {
  
          this.findTag=event.currentTarget.dataset.name;
          console.log(this.findTag);
          if(!this.allTagValues.includes(this.findTag) )
          {
              this.allTagValues.push(this.findTag);
             
          }
          this.inputTag=null;
          console.log(this.allTagValues);
          this.opensldsbox=false;
          
      }



      clearInputTag(){
        this.inputTag='';
         this.opensldsbox=false;

    }

    callpasstoparent(event)
    {
        console.log('false');
        this.openActivityModal=false; 

    }
    //removing selected tag
    handleRemoveTag(event)
    {
        const removeValue=event.target.name;
        this.allTagValues.splice(this.allTagValues.indexOf(removeValue),1);
    }

    handleRemoveTag1(event)
    {
        const removeValue=event.target.name;

        console.log('AllTags',this.allTags);
        this.allTags = this.allTags.filter(value => value !== event.target.label);
    }


    //posting a question
    text;
    postQuestionClick()
    {
       
        if(this.handleCheckValidation()&& this.allTagValues.length>2)
        {
            const event = new ShowToastEvent({
                // title: 'Toa',
                message: 'Congrats, You have successfully posted to Knowledge Arena ',
                variant: 'success',
                mode: 'dismissable',
                });
                 this.dispatchEvent(event);
        this.isShowAskQuestion=false;
        this.isEditQuestion=false;
        insertQuestion({Qtitle:this.askedQuestion,Qdescription:this.questionDescription,tagArray:this.allTagValues,Qcategory:this.selectedCategoryValue,recordType:this.tabName})
        .then(result=>{
             
            this.sendUpdatedFacts();
            //this.firetoquestion();
           
            console.log('result----------'+result);
                
         })
        .catch(error=>{
          console.error(error);
        })

        const updateEvent= new CustomEvent("getupdatedmodalvalue",{detail:this.isShowAskQuestion});
     this.dispatchEvent(updateEvent);
        
      } 



    else{
            const evt = new ShowToastEvent({
            title: "ERROR",
            message: "Please insert Title,Description,Select Category add minimum of three tags",
            variant: "warning",
                
        });
            this.dispatchEvent(evt);
            }
        
    }

    @wire(CurrentPageReference) pageRef;
    firetoquestion()
    {
        this.text='Unasnwered';
        fireEvent(this.pageRef, 'unanswer', this.text);
    }



    
     //dispatchEvent

    @api  msg;
    sendUpdatedFacts()
    {
     this.msg='Success';
     const updateEvent= new CustomEvent("getupdatedfacts",{detail:this.msg});
     this.dispatchEvent(updateEvent);
    }


    
    
    
    //success message
    // handleSuccess (){
    //     const evt = new ShowToastEvent({
    //         title: "Success!",
    //         message: "Congrats, You Contributed towards Knowledge Arena",
    //         variant: "success",
    //     });
    //    this.dispatchEvent(evt);
    // }
    

    //warning message
    // handleUnSuccess(){
    //     console.log('handleunsuccess');
    //     const evt = new ShowToastEvent({
    //         title: "ERROR",
    //         message: "Please insert Title,Description,Select Category add minimum of three tags",
    //         variant: "warning",
    //     });
    //    this.dispatchEvent(evt);
    // }



    
    handleTagChange(event) {
        this.tagValue = event.detail.value;
    }

    
    handleCategoryChange(event){
       
        this.selectedCategoryValue = event.detail.value;
        console.log('In category change',this.selectedCategoryValue)
    }
    



    handleCheckValidation() {
        let isValid = true;
        let inputFields = this.template.querySelectorAll('.fieldvalidate');
        inputFields.forEach(inputField => {
            if(!inputField.checkValidity()) {
                inputField.reportValidity();
                isValid = false;
            }
        });
        return isValid;
    }
 


    ///editable data
    question;
    questionflag;
    updateQuestionHandlerChage(event)
    {
        this.question=event.target.value;
        console.log('New title',this.question);
        this.questionflag=1;

        //this.question=event.target.value;
    }

    updatedDescription;
    updatedDescriptionFlag;
    updateDescriptionHandler(event)
    {
        this.updatedDescription=event.target.value;
        this.updatedDescriptionFlag=1;
    }


    updateRecord()
    {
        if(this.questionflag!=1)
        {
            this.question=this.allData.QuestionTitle;
        }
        if(this.updatedDescriptionFlag!=1)
        {
            this.updatedDescription=this.allData.QuestionDesc;
        }

        if(this.handleCheckValidation()&& this.allTagValues.length>2)
        {
        this.isShowAskQuestion=false;
        this.isEditQuestion=false;
        updateData({Qtitle:this.question,Qdescription:this.updatedDescription,tagArray:this.allTagValues,Qcategory:this.selectedCategoryValue,recordId:this.allData.QuestionId})
        .then(result=>{
            this.sendUpdatedFacts();
        })
        .catch(error=>{
          console.error(error);
        })

        const updateEvent= new CustomEvent("getupdatedmodalvalue",{detail:this.isShowAskQuestion});
        this.dispatchEvent(updateEvent);
    } 

}


dynamicSearchHnadler(event){
    console.log('------------quesId'+event.currentTarget.dataset.id);
    // alert("aaaaaa");
    questionDetails({ recId:event.currentTarget.dataset.id}) 
        .then(result => {
            this.myQuestion=JSON.stringify(result);;
            // this.isLoaded=false;
            this.openActivityModal=true;
            console.log('here');
            console.log(this.myQuestion);
            // this.myVar = {
            //     author: this.myQuestion.author
            // };
            
        })
        .catch(error => {
            console.log()
        });
        event.stopPropagation();
}
passToParent(event)
    {
        console.log('false');
        this.openActivityModal=false; 
    }
   


    clearInput(event)
    {
       // this.inputTag='';
        event.target.value='';
    }

}