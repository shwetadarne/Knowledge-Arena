import { LightningElement, track, api } from 'lwc';
import recalculateWeeklyStatusReport from '@salesforce/apex/GenerateWSRCtrl.recalculateWeeklyStatusReport';
import { CloseActionScreenEvent } from 'lightning/actions';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class RecalculateWSR extends NavigationMixin(LightningElement)  {
    error;
    _recordId;

    @api set recordId(value) {
        this._recordId = value;
    }

    get recordId() {
        return this._recordId;
    }

    connectedCallback() {
        
    }

    closeModal() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    submitDetails() {

        recalculateWeeklyStatusReport({wsrId: this.recordId })
            .then(result => {
                this.showToast(result.message, result.status);
                if (result.status == 'success') {
                    this[NavigationMixin.Navigate]({
                        type: 'standard__recordPage',
                        attributes: {
                            recordId: this.recordId,
                            objectApiName: 'Weekly_Status_Report__c',
                            actionName: 'view'
                        }
                    });
                }
                    
                this.dispatchEvent(new CloseActionScreenEvent());
            })
            .catch(error => {
                this.error = error;
                this.showToast(error, 'error');
            });
    }

    showToast(title,variant) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant
        });
        this.dispatchEvent(event);
    }
}