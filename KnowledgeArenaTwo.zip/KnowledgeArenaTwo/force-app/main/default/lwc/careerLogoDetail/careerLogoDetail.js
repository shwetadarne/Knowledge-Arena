import { LightningElement } from 'lwc';
import Advisor from '@salesforce/resourceUrl/advisor';
import Apprentice from '@salesforce/resourceUrl/Apprentice';
import Marshal from '@salesforce/resourceUrl/Marshal';
import Mentor from '@salesforce/resourceUrl/Mentor';
import Prophet from '@salesforce/resourceUrl/Prophet';
import Scholar from '@salesforce/resourceUrl/Scholar';
import Specialist from '@salesforce/resourceUrl/Specialist';
import Ambassador from '@salesforce/resourceUrl/Ambassador';

export default class CareerLogoDetail extends LightningElement {
    AdvisorLogo=Advisor;
    ApprenticeLogo=Apprentice;
    MarshalLogo=Marshal;
    MentorLogo=Mentor;
    ProphetLogo=Prophet;
    ScholarLogo=Scholar;
    SpecialistLogo=Specialist;
    AmbassadorLogo=Ambassador;
    openLogoDetailModal=true;
    hideModalBox(){
        this.openLogoDetailModal=false;
        const custEvent = new CustomEvent('callpasstoparent', {detail: 'false'});
        this.dispatchEvent(custEvent);
    }
}