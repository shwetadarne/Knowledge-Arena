import { LightningElement, track, wire, api } from 'lwc';

import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Category__c from '@salesforce/schema/Question__c.Category__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Question_OBJECT from '@salesforce/schema/Question__c';
import { CurrentPageReference } from 'lightning/navigation';
import { registerListener, unregisterAllListeners } from 'c/pubsub';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import allTagList from '@salesforce/apex/QuestionAdapter.getAllTags';
import QuestionCategoryResponse from '@salesforce/apex/QuestionTagController.QuestionCategoryResponse';
import allQuestionsAndFacts from '@salesforce/apex/QuestionTagController.allQuestionsAndFacts';
import ContactMobile from '@salesforce/schema/Case.ContactMobile';



export default class QaTab extends LightningElement {

    //isOpenAskQuestionModal=false;
    qaTabOpen = true;
    postQuestion = false;
    //qaTabName='Question';
    opensldsbox = false;
    @track selectedTags = [];
    @track isLoading = false;
    @api recordname;

    @wire(CurrentPageReference) pageRef;
    connectedCallback() {

        registerListener('getupdatedFeed', this.updateFeed, this);
        registerListener('selectTag', this.handleSelectTagChange, this);
        registerListener('selectedCategory', this.handleSelectCategoryChange, this);
        console.log('Connected Callback');
        this.getFeed();
        // this.updateFeed();
    }


    @track message1 = '';
    updateFeed(event) {
        this.message1 = event;
        console.log('message1', event);
        if (this.message1 == 'Success') {
            this.getFeed();
        }
    }

    allData;
    offSet = 0;
    flag;
    @track
    isDisableLoadMore = false;
    getFeed() {
        this.isLoading = true;
        allQuestionsAndFacts({ recordType: this.recordname, offSet: this.offSet })
            .then(result => {
                console.log(result.successRespObj);
                console.log('result' + result.successRespObj);
                if (result.successRespObj && result.successRespObj.length > 0) {
                    console.log(result);
                    this.flag = 0;
                    this.allQuestionAnswer = [...result.successRespObj];

                    if (this.allQuestionAnswer.length < 10) {
                        this.isDisableLoadMore = true;
                    }
                    else {
                        this.isDisableLoadMore = false;
                    }

                }
                this.isLoading = false;
            })
            .catch(error => {
                console.error(error);
            })
    }

    loadMoreClick(event) {
        //event.preventDefault();

        if (this.flag == 0) {
            this.offSet = this.offSet + 10;
            allQuestionsAndFacts({ recordType: this.recordname, offSet: this.offSet })
                .then(result => {
                    console.log('result' + result.successRespObj);
                    if (result.successRespObj && result.successRespObj.length > 0) {
                        console.log(result);
                        // console.log('Parse' +JSON.parse(result.successRespObj));
                        this.loadedData = [...result.successRespObj];
                        this.allQuestionAnswer = this.allQuestionAnswer.concat(this.loadedData);
                        if (this.loadedData.length < 10) {
                            this.isDisableLoadMore = true;
                            console.log('in loadmore ' + this.loadedData.length);
                        } else {
                            this.isDisableLoadMore = false;
                        }

                    }
                })
                .catch(error => {
                    console.error(error);
                })
        }
        else if (this.flag == 1) {
            if ((this.selectedTags.length <= 0) && (this.selectedCategory != null || this.selectedCategory == 'None')) {
                this.offSet = this.offSet + 10;
                QuestionCategoryResponse({ searchArray: this.selectedTags, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                    .then(result => {
                        this.loadedData = [...result.successRespObj];
                        this.allQuestionAnswer = this.allQuestionAnswer.concat(this.loadedData);
                        if (this.loadedData.length < 10) {
                            this.isDisableLoadMore = true;
                            console.log('in loadmore ' + this.loadedData.length);
                        }
                        else {
                            this.isDisableLoadMore = false;
                        }

                    })
                    .catch(error => {
                        console.log(error);
                    });

            }
            else if ((this.selectedTags.length > 0) && (this.selectedCategory == null || this.selectedCategory == 'None')) {
                this.offSet = this.offSet + 10;
                QuestionCategoryResponse({ searchArray: this.selectedTags, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                    .then(result => {
                        this.loadedData = [...result.successRespObj];
                        this.allQuestionAnswer = this.allQuestionAnswer.concat(this.loadedData);
                        if (this.loadedData.length < 10) {
                            this.isDisableLoadMore = true;
                            console.log('in loadmore ' + this.loadedData.length);
                        }
                        else {
                            this.isDisableLoadMore = false;
                        }

                    })
                    .catch(error => {
                        console.log(error);
                    });
            }
            else if ((this.selectedTags.length > 0) && (this.selectedCategory != null || this.selectedCategory == 'None')) {
                this.offSet = this.offSet + 10;
                QuestionCategoryResponse({ searchArray: this.selectedTags, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                    .then(result => {
                        this.loadedData = [...result.successRespObj];
                        this.allQuestionAnswer = this.allQuestionAnswer.concat(this.loadedData);
                        if (this.loadedData.length < 10) {
                            this.isDisableLoadMore = true;
                            console.log('in loadmore ' + this.loadedData.length);
                        }
                        else {
                            this.isDisableLoadMore = false;
                        }

                    })
                    .catch(error => {
                        console.log(error);
                    });
            }

        }
        if (this.flag == 2) {

            console.log(this.offSet);
            let questionsBasedOnTags;
            if ((this.selectedTagFeed != null) && (this.selectedCategory == null)) {
                this.offSet = this.offSet + 10;
                console.log(this.selectedTagFeed);
                QuestionCategoryResponse({ searchArray: this.selectedTagFeed, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                    .then(result => {
                        questionsBasedOnTags = [...result.successRespObj];
                        this.allQuestionAnswer = this.allQuestionAnswer.concat(questionsBasedOnTags);
                        console.log('questionsBasedOnTags--', questionsBasedOnTags);
                        if (questionsBasedOnTags.length < 10) {
                            this.isDisableLoadMore = true;
                            console.log('in loadmore ' + questionsBasedOnTags.length);
                        }
                        else {
                            this.isDisableLoadMore = false;
                        }
                    })
                    .catch(error => {
                        console.log();
                        this.isLoading = false;
                    });
            }
        }
        if (this.flag == 3) {
            console.log(this.offSet);
            let questionsBasedOnCategory;
            if ((this.selectedTagFeed == null) && (this.selectedCategoryFeed != null)) {
                this.offSet = this.offSet + 10;
                QuestionCategoryResponse({ searchArray: this.selectedTag, searchCategory: this.selectedCategoryFeed, recordType: this.recordname, offSet: this.offSet })
                    .then(result => {
                        questionsBasedOnCategory = [...result.successRespObj];
                        this.allQuestionAnswer = this.allQuestionAnswer.concat(questionsBasedOnCategory);
                        console.log('questionsBasedOnTags--', questionsBasedOnCategory);
                        if (questionsBasedOnCategory.length < 10) {
                            this.isDisableLoadMore = true;
                            console.log('in loadmore ' + questionsBasedOnCategory.length);
                        }
                        else {
                            this.isDisableLoadMore = false;
                        }

                    })
                    .catch(error => {
                        console.log();
                        this.isLoading = false;
                    });
            }
        }

    }

    @track StatePicklistValues;
    @wire(getObjectInfo, { objectApiName: Question_OBJECT })
    categoryInfo;

    @wire(getPicklistValues,
        {
            recordTypeId: '$categoryInfo.data.defaultRecordTypeId',
            fieldApiName: Category__c
        }
    )


    getPicklistValues(result) {
        if (result.data) {
            console.log(JSON.stringify('valeus of category', result.data));
            if (this.recordname == 'Question') {
                this.StatePicklistValues = [{ label: 'None', value: 'None' }, { label: 'My Questions', value: 'My Questions' }, ...result.data.values];
            }
            else {
                this.StatePicklistValues = [{ label: 'None', value: 'None' }, { label: 'My Approved Facts', value: 'My Approved Facts' }, { label: 'My Rejected Facts', value: 'My Rejected Facts' }, ...result.data.values];
            }
        } else if (result.error) {
            alert('ERROR');
        }
    }






    @track picklistOptions;
    @track tagsfromApex;
    @wire(allTagList, {})
    tagsfromApex({ error, data }) {

        if (data) {
            try {
                let options = [];
                for (var key in data) {
                    options.push({ label: data[key].Name, value: data[key].Name });
                }
                this.picklistOptions = options;

            } catch (error) {
            }
        } else if (error) {
        }
    }




    handleGetSelectedTag(event) {
        if (!this.selectedTags.includes(event.target.value)) {
            this.selectedTags.push(event.target.value);
            console.log(this.selectedTags);
        }

    }

    handleRemoveTag(event) {
        const removeValue = event.target.name;
        this.selectedTags.splice(this.selectedTags.indexOf(removeValue), 1);
    }




    //clearing filters
    clearFilterHandler(event) {
        this.selectedCategory = 'Select Progress';
    }

    selectedCategory;
    handleCategoryChange(event) {
        this.selectedCategory = event.target.value;
        console.log('Selected Category', this.selectedCategory)

    }


    askQuestionHandler() {
        this.postQuestion = true;
    }


    handleMessage(event) {
        if (event.detail.value == 'success') {
            console.log('in event.detail.value');
            this.getSelectedTagQuestion();
            this.getFeed();

        }
    }
    handleDownVotes(event) {
        if (event.detail.value == 'downVotesuccess') {
            console.log('in event.detail.value');
            this.getSelectedTagQuestion();
            this.getFeed();

        }
    }


    ///filtering of facts and tags
    @track allQuestionAnswer;
    @track flag;
    @track isNoData = false;

    getSelectedTagQuestion() {
        console.log('Onclick1');
        console.log('Slecteed Ctaegory' + this.selectedCategory);
        console.log('Tags' + this.selectedTags);
        this.isLoading = true;


        if ((this.selectedTags.length <= 0) && (this.selectedCategory != null || this.selectedCategory == 'None')) {
            console.log('Onclick');
            this.offSet = 0;
            //this.selectedCategory=null;
            QuestionCategoryResponse({ searchArray: this.selectedTags, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                .then(result => {
                    this.allQuestionAnswer = [...result.successRespObj];
                    console.log('result ' + result.successRespObj);
                    if (this.allQuestionAnswer.length == 0) {
                        this.isNoData = true;
                    }
                    this.flag = 1;
                    this.isLoading = false;
                    if (this.allQuestionAnswer.length < 10) {
                        this.isDisableLoadMore = true;
                        console.log(this.isDisableLoadMore);
                    }
                    else {
                        this.isDisableLoadMore = false;
                    }
                })
                .catch(error => {
                    console.log()
                });
        }

        else if ((this.selectedTags.length > 0) && (this.selectedCategory == null || this.selectedCategory == 'None')) {
            this.offSet = 0;
            console.log('Onclick Tag');
            //this.selectedCategory=null;
            QuestionCategoryResponse({ searchArray: this.selectedTags, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                .then(result => {
                    this.allQuestionAnswer = [...result.successRespObj];
                    if (this.allQuestionAnswer.length == 0) {
                        this.isNoData = true;
                    }
                    console.log('result' + result.successRespObj);
                    this.flag = 1;
                    this.isLoading = false;
                    if (this.allQuestionAnswer.length < 10) {
                        this.isDisableLoadMore = true;
                        console.log(this.isDisableLoadMore);
                    }
                    else {
                        this.isDisableLoadMore = false;
                    }
                })
                .catch(error => {
                    console.log()
                });
        }
        else if ((this.selectedTags.length > 0) && (this.selectedCategory != null || this.selectedCategory == 'None')) {
            this.offSet = 0;
            console.log('Onclick Tag and Category');
            //this.selectedCategory=null;
            QuestionCategoryResponse({ searchArray: this.selectedTags, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                .then(result => {
                    this.allQuestionAnswer = [...result.successRespObj];
                    console.log('result' + result.successRespObj);
                    if (this.allQuestionAnswer.length == 0) {
                        this.isNoData = true;
                    }
                    this.flag = 1;
                    this.isLoading = false;
                    if (this.allQuestionAnswer.length < 10) {
                        this.isDisableLoadMore = true;
                        console.log(this.isDisableLoadMore);
                    }
                    else {
                        this.isDisableLoadMore = false;
                    }
                })
                .catch(error => {
                    console.log()
                });
        }




    }

    setfalse(event) {
        this.postQuestion = false;
    }

    @track message;
    getUpdatedQuestions(event) {
        this.message = event.detail;
        console.log('recieved after inserting question', this.message);
        if (this.message == 'Success') {
            this.getFeed();
        }
    }

    selectedTagFeed;
    handleSelectTagChange(event) {
        let questionsBasedOnTags;
        this.selectedTagFeed = event;
        console.log(this.selectedTagFeed);
        this.offSet = 0;
        if ((this.selectedTagFeed != null) && (this.selectedCategory == null))
            QuestionCategoryResponse({ searchArray: this.selectedTagFeed, searchCategory: this.selectedCategory, recordType: this.recordname, offSet: this.offSet })
                .then(result => {
                    questionsBasedOnTags = [...result.successRespObj];
                    console.log('questionsBasedOnTags--', questionsBasedOnTags);
                    //fireEvent(this.pageRef, 'selectTag', questionsBasedOnTags);
                    this.allQuestionAnswer = questionsBasedOnTags;
                    this.flag = 2;
                    console.log(this.flag);
                    if (this.allQuestionAnswer.length < 10) {
                        this.isDisableLoadMore = true;
                    }
                    else {
                        this.isDisableLoadMore = false;
                    }
                    this.isLoading = false;

                })
                .catch(error => {
                    console.log();
                    this.isLoading = false;
                });


    }


    selectedCategoryFeed;
    handleSelectCategoryChange(event) {
        let questionsBasedOnCategory;
        this.selectedCategoryFeed = event;
        console.log(this.selectedCategoryFeed);
        this.offSet = 0;
        if ((this.selectedTag == null) && (this.selectedCategoryFeed != null)){
            QuestionCategoryResponse({ searchArray: this.selectedTag, searchCategory: this.selectedCategoryFeed, recordType: this.recordname, offSet: this.offSet })
                .then(result => {
                    questionsBasedOnCategory = [...result.successRespObj];
                    console.log('questionsBasedOnCategorys--', questionsBasedOnCategory);
                    //fireEvent(this.pageRef, 'selectTag', questionsBasedOnTags);
                    this.allQuestionAnswer = questionsBasedOnCategory;
                    this.flag = 3;
                    console.log(this.flag);
                    if (this.allQuestionAnswer.length < 10) {
                        this.isDisableLoadMore = true;
                    }
                    else {
                        this.isDisableLoadMore = false;
                    }
                    this.isLoading = false;

                })
                .catch(error => {
                    console.log();
                    this.isLoading = false;
                });
        }

    }





}