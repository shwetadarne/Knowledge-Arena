/**
 * @name        cWerxOneWerx_Phase2_TimeCardApproval
 * @Author      Nishant Singh and Namrata Ingale.
 * @Date        08-12-2021
 * @Description Timecard Component for Approval and Rejection.
 */



 import { LightningElement,track,wire } from 'lwc';
 import { ShowToastEvent } from 'lightning/platformShowToastEvent';
 import timecardlistaprrovallist from '@salesforce/apex/timecardController.timecardlistaprrovallist';
 import modifiedTimecards from '@salesforce/apex/timecardController.modifiedTimecards';
 import aprrovingTimecards from '@salesforce/apex/timecardController.aprrovingTimecards';
 import rejectTimecards from '@salesforce/apex/timecardController.rejectTimecards';
 const columns = [{  
         label: 'TimeCard Id',  
         fieldName: 'recordLink',  
         type: 'url', 
         sortable: true,
         initialWidth: 167, 
         typeAttributes: { label: { fieldName: 'Name' }, target: '_blank'}  
        }, 
         
         {
             label: 'Resource',
             fieldName: 'resourceName',
             type: 'text',
             initialWidth: 110,
             sortable: true,
         },
         {
             label: 'Project',
             fieldName: 'projectName',
             type: 'text',
             initialWidth: 160,
             sortable: true,
         },
         {  
             label: 'Assignment',
             fieldName: 'AssignmentName',
             type: 'text',
             initialWidth: 96,
             sortable: true,
         },   
 
         {
             label: 'Start Date',
             fieldName: 'startDate',
             type: 'date',
             initialWidth: 84,
             sortable: true,
         },
         {
             label: 'Total Hours',
             fieldName: 'totalHours',
             type: 'decimal',
             initialWidth: 75,
             cellAttributes: { alignment: 'right' },
         typeAttributes: {
             maximumFractionDigits: '3'},
             sortable: true,
         },
         {
             label: 'Sun',
             fieldName: 'Sunday',
             type: 'decimal',
             initialWidth: 70,
             cellAttributes: { alignment: 'right' },
             sortable: true,
         },
         {
             label: 'Mon',
             fieldName: 'Monday',
             type: 'Decimal',
             initialWidth: 70,
             cellAttributes: { alignment: 'right' },
             sortable: true,
         },
         {
             label: 'Tues',
             fieldName: 'Tuesday',
             type: 'Decimal',
             initialWidth: 70,
             cellAttributes: { alignment: 'right' },
             sortable: true,
         },
         {
             label: 'Wed',
             fieldName: 'Wednesday',
             type: 'Decimal',
             initialWidth: 70,
             cellAttributes: { alignment: 'right' },
             sortable: true,
         },
         {
             label: 'Thurs',
             fieldName: 'Thursday',
             type: 'Decimal',
             initialWidth: 70,
             cellAttributes: { alignment: 'right' },
             sortable: true,
         },
         {
             label: 'Fri',
             fieldName: 'Friday',
             type: 'Decimal',
             initialWidth: 70,
             cellAttributes: { alignment: 'right' },
             sortable: true,
         },
         {
             label: 'Sat',
             fieldName: 'Saturday',
             type: 'Decimal',
             initialWidth: 70,
             cellAttributes: { alignment: 'right' },
             sortable: true,
         },
         {
             label: 'End Date',
             fieldName: 'endDate',
             type: 'date',
             initialWidth: 180,
             sortable: true,
         }
 
        
     ];
     const maxTotalHours = 40;
     const maxdailyHours = 8;
     const weekend_working_hours = 0;
 export default class cWerxOneWerx_Phase2_TimeCardApproval extends LightningElement {
         @track lstLeads;
         @track days = {mon:1,tue:2,wed:3,thu:4,fri:5,sat:6,sun:7};
         @track nonbillabledays = {mon:1,tue:2,wed:3,thu:4,fri:5,sat:6,sun:7};
         @track obj;
         @track project;
         @track startDate;
         @track endDate;
         @track lstSelectedLeads;
         @track record = [];
         @track accList = [];
         @track maxTotalHours;
         @track Monday;
         @track Tuesday;
         @track Wednesday;
         @track Thursday;
         @track Friday;
         @track Saturday;
         @track Sunday;
         @track recordId;
         @track totalHours;
         @track comment;
         @track nodata = true;
         @track showspinner = false;
         error;
         isEditable = false;
         showmodal = false;
         columns = columns;
         @track resource_n_projectList = [];
         @track original_timecard = {};
         @track modifytime_card = {};
         @track nonbillable_timecard = {};
         rowLimit =25;
         rowOffSet=0;
         @track sortBy;
         @track sortDirection;
         @track projectStartDate;
         @track projectEndDate;
 
 
 
         connectedCallback(){
                      this.loadData();
 
         }
 
         
 
         loadMoreData(event) {
             const currentRecord = this.resource_n_projectList;
             const { target } = event;
             target.isLoading = true;
     
             this.rowOffSet = this.rowOffSet + this.rowLimit;
             this.loadData()
                 .then(()=> {
                     target.isLoading = false;
                     
                 });   
         }
 
 
 
         doSorting(event) {
         this.sortBy = event.detail.fieldName;
         this.sortDirection = event.detail.sortDirection;
         this.sortData(this.sortBy, this.sortDirection);
         console.log(JSON.stringify(this.sortData(this.sortBy, this.sortDirection)));
     }
 
     sortData(fieldname, direction) {
         let parseData = JSON.parse(JSON.stringify(this.resource_n_projectList));
         // Return the value stored in the field
         let keyValue = (a) => {
             return a[fieldname];
         };
         // cheking reverse direction
         let isReverse = direction === 'asc' ? 1: -1;
         // sorting data
         parseData.sort((x, y) => {
             x = keyValue(x) ? keyValue(x) : ''; // handling null values
             y = keyValue(y) ? keyValue(y) : '';
             console.log('sncj-->'+x);
             console.log('djsbdcs---->'+y);
             // sorting values based on direction
             return isReverse * ((x > y) - (y > x));
         });
         this.resource_n_projectList = parseData;
     }    
 
         loadData(){
             return  timecardlistaprrovallist({ limitSize: this.rowLimit , offset : this.rowOffSet })
             .then(result => {
                 let baseUrl = 'https://'+location.host+'/';
                 result.forEach(Rec => {
                     // Rec.urlpath = baseUrl+Rec.Id;
                     Rec.recordLink =   '/' +Rec.Id;
                 });
                 let templist=[];
                 let updatedRecords = [...this.accList, ...result];
                 this.accList = updatedRecords;
                 console.log('data--->'+JSON.stringify(this.accList));
                 for(let i=0;i<this.accList.length;i++){
                     let resource_n_project={};
                     resource_n_project.resourceName = this.accList[i].pse__Resource__r.Name;
                     resource_n_project.projectName = this.accList[i].pse__Project__r.Name;
                     resource_n_project.tcId = this.accList[i].Id;
                     resource_n_project.Name = this.accList[i].Name;
                     resource_n_project.recordLink = this.accList[i].recordLink;
                     resource_n_project.Monday = this.accList[i].pse__Monday_Hours__c;
                     resource_n_project.Tuesday = this.accList[i].pse__Tuesday_Hours__c;
                     resource_n_project.Wednesday = this.accList[i].pse__Wednesday_Hours__c;
                     resource_n_project.Thursday = this.accList[i].pse__Thursday_Hours__c;
                     resource_n_project.Friday = this.accList[i].pse__Friday_Hours__c;
                     resource_n_project.Saturday = this.accList[i].pse__Saturday_Hours__c;
                     resource_n_project.Sunday = this.accList[i].pse__Sunday_Hours__c;
                     resource_n_project.totalHours = this.accList[i].pse__Total_Hours__c;
                     resource_n_project.projectStartDate = this.accList[i].pse__Project__r.pse__Start_Date__c;
                     resource_n_project.projectEndDate = this.accList[i].pse__Project__r.pse__End_Date__c;
                     resource_n_project.startDate = this.accList[i].pse__Start_Date__c;
                     resource_n_project.endDate = this.accList[i].pse__End_Date__c;

                    // console.log('assignment'+this.accList[i].pse__Assignment__c);
                     
                     if(this.accList[i].pse__Assignment__c == undefined ){
                         resource_n_project.AssignmentName = ' ';
                     }
                     else{
                         resource_n_project.AssignmentName = this.accList[i].pse__Assignment__r.Name;
                     }
                     templist.push(resource_n_project);  
                 }
                 this.resource_n_projectList=templist;
                 if(this.resource_n_projectList.length == 0){
                     this.nodata = false;
                 }
 
                 // this.error = undefined;
             })
             .catch(error => {
                 console.log('Error'+JSON.stringify(error));
                 this.error = error;
                 
                 this.accounts = undefined;
             });
         }
     
     
     getSelectedRec(event) {
     
         this.record =  this.template.querySelector('lightning-datatable').getSelectedRows();
         console.log('recordselected'+JSON.stringify(this.record));
         if(this.record.length>0){
             
         this.obj = this.record[0].resourceName;
         this.project = this.record[0].projectName;
         this.projectStartDate = this.record[0].startDate;
         this.projectStartDate = this.projectStartDate.split('-');
         var startday = this.projectStartDate[2];
         var startmonth = this.projectStartDate[1];
         var startYear = this.projectStartDate[0];
         this.projectStartDate = startday + '/' + startmonth + '/'+ startYear;
         this.projectEndDate   = this.record[0].endDate;
        
         this.projectEndDate = this.projectEndDate.split('-');
         var endDay = this.projectEndDate[2];
         var endmonth = this.projectEndDate[1];
         var endYear = this.projectEndDate[0];
         this.projectEndDate = endDay + '/' + endmonth + '/'+ endYear;
         
         
 
         this.original_timecard.tcId = this.record[0].tcId;
         this.original_timecard.Monday = this.record[0].Monday;
         this.original_timecard.Tuesday = this.record[0].Tuesday;
         this.original_timecard.Wednesday = this.record[0].Wednesday;
         this.original_timecard.Thursday = this.record[0].Thursday;
         this.original_timecard.Friday = this.record[0].Friday;
         this.original_timecard.Saturday = this.record[0].Saturday;
         this.original_timecard.Sunday = this.record[0].Sunday;
         this.original_timecard.totalHours = this.record[0].totalHours;
         this.original_timecard.StartDate = this.record[0].StartDate;
         this.original_timecard.EndDate = this.record[0].EndDate;
         this.original_timecard.resourceName = this.record[0].resourceName;
         this.original_timecard.projectName = this.record[0].projectName;
         this.totalHours=this.record[0].totalHours > maxTotalHours;
 
 
 
         this.modifytime_card.tcId = this.record[0].tcId;
         this.modifytime_card.Monday = this.record[0].Monday;
         this.modifytime_card.Tuesday = this.record[0].Tuesday;
         this.modifytime_card.Wednesday = this.record[0].Wednesday;
         this.modifytime_card.Thursday = this.record[0].Thursday;
         this.modifytime_card.Friday = this.record[0].Friday;
         this.modifytime_card.Saturday = this.record[0].Saturday;
         this.modifytime_card.Sunday = this.record[0].Sunday;
         this.modifytime_card.totalHours = this.record[0].totalHours;
         this.modifytime_card.StartDate = this.record[0].StartDate;
         this.modifytime_card.EndDate = this.record[0].EndDate;
         this.modifytime_card.resourceName = this.record[0].resourceName;
         this.modifytime_card.projectName = this.record[0].projectName;
 
    if(this.original_timecard.totalHours >= maxTotalHours){
        
         this.nonbillable_timecard.tcId = this.record[0].tcId;
         this.nonbillable_timecard.Monday = 0;
         this.nonbillable_timecard.Tuesday = 0;
         this.nonbillable_timecard.Wednesday = 0;
         this.nonbillable_timecard.Thursday = 0;
         this.nonbillable_timecard.Friday = 0;
         this.nonbillable_timecard.Saturday = weekend_working_hours;
         this.nonbillable_timecard.Sunday = weekend_working_hours;
         this.nonbillable_timecard.totalHours = 0;
         this.nonbillable_timecard.StartDate = this.record[0].StartDate;
         this.nonbillable_timecard.EndDate = this.record[0].EndDate;
         this.nonbillable_timecard.resourceName = this.record[0].resourceName;
         this.nonbillable_timecard.projectName = this.record[0].projectName;

    }
 
         }
 
  
 
         }
         
       
   @track isModalOpenApprove = false;
   @track isModalOpenModify = false;
   @track isModalOpenReject = false;
   @track isModalConfirm = false;
 
   
     openModalApprove() {
         this.isModalOpenApprove = true;
         if(this.record.length == 0){
             const event = new ShowToastEvent({
                 title: 'Error!',
                 message: 'Please select Atleast one row for Approval ! ',
                 variant: 'Error',
             });
             this.dispatchEvent(event);
             this.isModalOpenApprove = false;
         }
        
     }
     openModalReject() {
 
         this.isModalOpenReject = true;
         if( this.record.length == 0){
             const event = new ShowToastEvent({
                 title: 'Error!',
                 message: 'Please select Atleast one row for Rejection ! ',
                 variant: 'Error',
             });
             this.dispatchEvent(event);
             this.isModalOpenReject = false;
         }
        
     }
     openModalModify() {
         this.isModalOpenModify = true;
 
         if(this.record.length>1 || this.record.length==0 ){
                 const event = new ShowToastEvent({
                     title: 'Error!',
                     message: 'Please select one row for Modification ',
                     variant: 'Error',
 
                 });
                 this.dispatchEvent(event);
             
         this.isModalOpenModify = false;
         }
         
     }
     closeModal() {

         eval("$A.get('e.force:refreshView').fire();");
         this.isModalOpenApprove = false;
         this.isModalOpenModify = false;
         this.isModalOpenReject = false;
         this.isModalConfirm = false;
 
     }
     approveclickhandler(event){
       var idList=[];
       
         for(let i=0; i < this.record.length; i++){
             idList.push(this.record[i].tcId);
         }
        this.showspinner=true;
        
         aprrovingTimecards({ idlist : idList , approveComment : this.comment})
             .then(result => {
                 this.isModalOpenApprove = false;
                 console.log('approved');
                 this.dispatchEvent(
                     new ShowToastEvent({
                         title: 'Success',
                         message: 'Approved Succefully',
                         variant: 'success',
                     }),
                     
                 );
                 eval("$A.get('e.force:refreshView').fire();");
                 this.showspinner=false;
                 
                 
             })
             .catch(error => {
                 this.error = error;
             });
             this.isModalOpenApprove = false;
             
     }
     
     rejectclickhandler(event){
         var idList=[];
           for(let i=0;i<this.record.length;i++){
               idList.push(this.record[i].tcId);
           }
            this.showspinner=true;
          
           rejectTimecards({idlist : idList , rejectComment : this.comment})
               .then(result => {
                   this.isModalOpenReject = false;
                   console.log('Rejects');
                   this.dispatchEvent(
                       new ShowToastEvent({
                           title: 'Rejected',
                           message: 'Timecard Rejected',
                           variant: 'info',
                       }),
                   );
                   eval("$A.get('e.force:refreshView').fire();");
                 this.showspinner=false;
                   
               })
               .catch(error => {
                   this.error = error;
               });
               this.isModalOpenReject = false;
              
       }
 
       Commentchange(event){         
 
           this.comment = event.target.value;
       }
 
     confirmhandler(event){              
                                         
         this.isModalOpenModify = false;
          
                
                
                
         if(this.original_timecard.totalHours != (this.modifytime_card.totalHours + this.nonbillable_timecard.totalHours) && (this.nonbillable_timecard.Monday >= 0 && this.nonbillable_timecard.Tuesday >= 0 && this.nonbillable_timecard.Wednesday >= 0 && this.nonbillable_timecard.Thursday >=0 
                    && this.nonbillable_timecard.Friday >= 0 && this.nonbillable_timecard.Saturday >= 0 && this.nonbillable_timecard.Sunday >= 0  && 
                    this.modifytime_card.Monday >= 0 && this.modifytime_card.Tuesday >= 0 && this.modifytime_card.Wednesday >= 0 && this.modifytime_card.Thursday >=0 
                    && this.modifytime_card.Friday >= 0 && this.modifytime_card.Saturday >= 0 && this.modifytime_card.Sunday >= 0 && this.original_timecard.totalHours >= maxTotalHours)){
             this.isModalOpenModify = true;
             const toastEvent = new ShowToastEvent({
                 title:'Error Occured ',
                 message:'Total Work Hours for the Non-Billable and Modiefied TimeCard should be same as Original Total Work Hours',
                 variant:'Info',
              })
              console.log('after toast');
              this.dispatchEvent(toastEvent);
               this.isModalOpenModify = true;
              this.isModalConfirm = false;
         }
         
            if(this.nonbillable_timecard.Monday < 0 || this.nonbillable_timecard.Tuesday < 0 || this.nonbillable_timecard.Wednesday < 0 || this.nonbillable_timecard.Thursday <0 
             || this.nonbillable_timecard.Friday < 0 || this.nonbillable_timecard.Saturday < 0 || this.nonbillable_timecard.Sunday < 0  || 
             this.modifytime_card.Monday < 0 || this.modifytime_card.Tuesday < 0 || this.modifytime_card.Wednesday < 0 || this.modifytime_card.Thursday <0 
             || this.modifytime_card.Friday < 0 || this.modifytime_card.Saturday < 0 || this.modifytime_card.Sunday < 0){

                  
                const toastEvent = new ShowToastEvent({
                 title:'Error Occured ',
                 message:'TimeCard hours cannot be in negative',
                 variant:'Info',
              })
              this.dispatchEvent(toastEvent);
               this.isModalOpenModify = true;
              this.isModalConfirm = false;

              }  

              if( this.original_timecard.totalHours < maxTotalHours && (this.nonbillable_timecard.Monday >= 0 || this.nonbillable_timecard.Tuesday >= 0 || this.nonbillable_timecard.Wednesday >= 0 || this.nonbillable_timecard.Thursday >=0 
                    || this.nonbillable_timecard.Friday >= 0 || this.nonbillable_timecard.Saturday >= 0 || this.nonbillable_timecard.Sunday >= 0  || 
                    this.modifytime_card.Monday >= 0 || this.modifytime_card.Tuesday >= 0 || this.modifytime_card.Wednesday >= 0 || this.modifytime_card.Thursday >=0 
                    || this.modifytime_card.Friday >= 0 || this.modifytime_card.Saturday >= 0 || this.modifytime_card.Sunday >= 0)){
                  
                    this.isModalOpenModify = false;
                    this.isModalConfirm = true;
              }

              if(this.original_timecard.totalHours == (this.nonbillable_timecard.totalHours + this.modifytime_card.totalHours) && (this.nonbillable_timecard.Monday < 0 || this.nonbillable_timecard.Tuesday < 0 || this.nonbillable_timecard.Wednesday < 0 || this.nonbillable_timecard.Thursday <0 
                    || this.nonbillable_timecard.Friday < 0 || this.nonbillable_timecard.Saturday < 0 || this.nonbillable_timecard.Sunday < 0  || 
                    this.modifytime_card.Monday < 0 || this.modifytime_card.Tuesday < 0 || this.modifytime_card.Wednesday < 0 || this.modifytime_card.Thursday <0 
                    || this.modifytime_card.Friday < 0 || this.modifytime_card.Saturday < 0 || this.modifytime_card.Sunday < 0)){
                 
                    this.isModalOpenModify = true;
                    this.isModalConfirm = false;
              }

                if(this.original_timecard.totalHours == (this.nonbillable_timecard.totalHours + this.modifytime_card.totalHours) && (this.nonbillable_timecard.Monday >= 0 && this.nonbillable_timecard.Tuesday >= 0 && this.nonbillable_timecard.Wednesday >= 0 && this.nonbillable_timecard.Thursday >=0 
                    && this.nonbillable_timecard.Friday >= 0 && this.nonbillable_timecard.Saturday >= 0 && this.nonbillable_timecard.Sunday >= 0  && 
                    this.modifytime_card.Monday >= 0 && this.modifytime_card.Tuesday >= 0 && this.modifytime_card.Wednesday >= 0 && this.modifytime_card.Thursday >=0 
                    && this.modifytime_card.Friday >= 0 && this.modifytime_card.Saturday >= 0 && this.modifytime_card.Sunday >= 0)){
                        this.isModalOpenModify = false;
                        this.isModalConfirm = true;
                }



         
         
     }
 
     rebalanceHandler(){                         
 
         if(this.original_timecard.totalHours == maxTotalHours){
             this.modifytime_card.Monday = maxdailyHours;
             this.modifytime_card.Tuesday = maxdailyHours;
             this.modifytime_card.Wednesday = maxdailyHours;
             this.modifytime_card.Thursday = maxdailyHours;
             this.modifytime_card.Friday = maxdailyHours;
             this.modifytime_card.Saturday = weekend_working_hours;
             this.modifytime_card.Sunday = weekend_working_hours;
         }
 
          if(this.original_timecard.totalHours > maxTotalHours){
 
             this.modifytime_card.Monday = maxdailyHours;
             this.modifytime_card.Tuesday = maxdailyHours;
             this.modifytime_card.Wednesday = maxdailyHours;
             this.modifytime_card.Thursday = maxdailyHours;
             this.modifytime_card.Friday = maxdailyHours;
             this.modifytime_card.Saturday = weekend_working_hours;
             this.modifytime_card.Sunday = weekend_working_hours;
             
             
             let mondaydiffValue = this.original_timecard.Monday-this.modifytime_card.Monday;
             let tuesdaydiffValue = this.original_timecard.Tuesday-this.modifytime_card.Tuesday;
             let WednesdaydiffValue = this.original_timecard.Wednesday-this.modifytime_card.Wednesday;
             let thursdaydiffValue = this.original_timecard.Thursday-this.modifytime_card.Thursday;
             let fridaydiffValue = this.original_timecard.Friday-this.modifytime_card.Friday;
             if((this.original_timecard.Monday >= maxdailyHours && this.original_timecard.Tuesday >= maxdailyHours && this.original_timecard.Wednesday >= maxdailyHours && this.original_timecard.Thursday >= maxdailyHours
                 && this.original_timecard.Friday >= maxdailyHours ) ){
 
             
 
 
             this.nonbillable_timecard.Monday = this.original_timecard.Monday-this.modifytime_card.Monday;
             this.nonbillable_timecard.Tuesday = this.original_timecard.Tuesday-this.modifytime_card.Tuesday;
             this.nonbillable_timecard.Wednesday = this.original_timecard.Wednesday-this.modifytime_card.Wednesday;
             this.nonbillable_timecard.Thursday = this.original_timecard.Thursday-this.modifytime_card.Thursday;
             this.nonbillable_timecard.Friday = this.original_timecard.Friday-this.modifytime_card.Friday;
             this.nonbillable_timecard.Saturday = this.original_timecard.Saturday-this.modifytime_card.Saturday;
             this.nonbillable_timecard.Sunday = this.original_timecard.Sunday-this.modifytime_card.Sunday;
 
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                     + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
             
 
                 }
                 
              if(this.original_timecard.Monday<maxdailyHours){
                 this.modifytime_card.Monday = maxdailyHours;
                 this.modifytime_card.Tuesday = maxdailyHours;
                 this.modifytime_card.Wednesday = maxdailyHours;
                 this.modifytime_card.Thursday = maxdailyHours;
                 this.modifytime_card.Friday = maxdailyHours;
                 this.modifytime_card.Saturday = weekend_working_hours;
                 this.modifytime_card.Sunday = weekend_working_hours;
                 this.modifytime_card.Monday = maxdailyHours;
                 mondaydiffValue=Math.abs(mondaydiffValue);
                
                 if(tuesdaydiffValue >= mondaydiffValue && mondaydiffValue > 0 ){
                     this.nonbillable_timecard.Monday = 0;
                     this.nonbillable_timecard.Tuesday = this.original_timecard.Tuesday-this.modifytime_card.Tuesday;
                     this.nonbillable_timecard.Tuesday = this.nonbillable_timecard.Tuesday-mondaydiffValue;
                     tuesdaydiffValue = tuesdaydiffValue-mondaydiffValue;
                     mondaydiffValue = 0;
                 }
 
                 else if(tuesdaydiffValue > mondaydiffValue  && mondaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Tuesday = tuesdaydiffValue;
                 }
 
                 else if(mondaydiffValue > tuesdaydiffValue){
                     mondaydiffValue = mondaydiffValue-tuesdaydiffValue;
                     tuesdaydiffValue = 0;
                     if(mondaydiffValue == 0){
                         this.nonbillable_timecard.Monday = 0;
                     }
                 }
                 
                 if(WednesdaydiffValue >= mondaydiffValue && mondaydiffValue>0 ){
                     this.nonbillable_timecard.Monday = 0;
                     this.nonbillable_timecard.Wednesday = this.original_timecard.Wednesday-this.modifytime_card.Wednesday;
                     this.nonbillable_timecard.Wednesday = this.nonbillable_timecard.Wednesday-mondaydiffValue;
                     WednesdaydiffValue = WednesdaydiffValue - mondaydiffValue;
                     mondaydiffValue = 0;
                 }
                 else if(WednesdaydiffValue > mondaydiffValue  && mondaydiffValue==0  ){
                     
                     this.nonbillable_timecard.Wednesday = WednesdaydiffValue;
                 }
 
                 else if(mondaydiffValue > WednesdaydiffValue){
                     mondaydiffValue = mondaydiffValue - WednesdaydiffValue;
                     WednesdaydiffValue = 0;
                     if(mondaydiffValue == 0){
                         this.nonbillable_timecard.Monday = 0;
                     }
                 }
 
                 if(fridaydiffValue >= mondaydiffValue && mondaydiffValue > 0 ){
                     this.nonbillable_timecard.Monday = 0;
                     this.nonbillable_timecard.Friday = this.original_timecard.Friday - this.modifytime_card.Friday;
                     this.nonbillable_timecard.Friday = this.nonbillable_timecard.Friday - mondaydiffValue;
                     fridaydiffValue = fridaydiffValue - mondaydiffValue;
                     mondaydiffValue = 0;
                 }
                 else if(fridaydiffValue > mondaydiffValue  && mondaydiffValue==0  ){
                     
                     this.nonbillable_timecard.Friday=fridaydiffValue;
                 }
 
                 else if(mondaydiffValue > fridaydiffValue){
                     mondaydiffValue = mondaydiffValue - fridaydiffValue;
                     fridaydiffValue = 0;
                     if(mondaydiffValue == 0){
                         this.nonbillable_timecard.Monday = 0;
                     }
                 }
                 
                 if(thursdaydiffValue >= mondaydiffValue  && mondaydiffValue > 0  ){
                     this.nonbillable_timecard.Monday = 0;
                     this.nonbillable_timecard.Thursday = this.original_timecard.Thursday - this.modifytime_card.Thursday;
                     this.nonbillable_timecard.Thursday = this.nonbillable_timecard.Thursday - mondaydiffValue;
                     thursdaydiffValue = thursdaydiffValue - mondaydiffValue;
                     mondaydiffValue = 0;
                 }
                 else if(thursdaydiffValue > mondaydiffValue  && mondaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Thursday = thursdaydiffValue;
                 }
 
                 else if(mondaydiffValue > thursdaydiffValue){
                     mondaydiffValue = mondaydiffValue-thursdaydiffValue;
                     thursdaydiffValue = 0;
                     if(mondaydiffValue == 0){
                         this.nonbillable_timecard.Monday = 0;
                     }
                 }
 
                 
 
             }
                
              if(this.original_timecard.Tuesday < maxdailyHours){
                 tuesdaydiffValue=Math.abs(tuesdaydiffValue);
                 if(WednesdaydiffValue >= tuesdaydiffValue && tuesdaydiffValue > 0 ){
                     this.nonbillable_timecard.Tuesday = 0;
                     this.nonbillable_timecard.Wednesday = this.original_timecard.Wednesday - this.modifytime_card.Wednesday;
                     this.nonbillable_timecard.Wednesday = this.nonbillable_timecard.Wednesday - tuesdaydiffValue;
                     WednesdaydiffValue = WednesdaydiffValue - tuesdaydiffValue;
                     tuesdaydiffValue = 0;
                 }
                 else if(WednesdaydiffValue > tuesdaydiffValue  && tuesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Wednesday = WednesdaydiffValue;
                 }
 
                 else if(tuesdaydiffValue > WednesdaydiffValue){
                     tuesdaydiffValue = tuesdaydiffValue-WednesdaydiffValue;
                     WednesdaydiffValue = 0;
                     if(tuesdaydiffValue == 0){
                         this.nonbillable_timecard.Tuesday = 0;
                     }
                 }
                 if(thursdaydiffValue >= tuesdaydiffValue  && tuesdaydiffValue > 0  ){
                     this.nonbillable_timecard.Tuesday = 0;
                     this.nonbillable_timecard.Thursday = this.original_timecard.Thursday - this.modifytime_card.Thursday;
                     this.nonbillable_timecard.Thursday = this.nonbillable_timecard.Thursday - tuesdaydiffValue;
                     thursdaydiffValue = thursdaydiffValue - tuesdaydiffValue;
                     tuesdaydiffValue=0;
                 }
 
 
                 else if(thursdaydiffValue > tuesdaydiffValue  && tuesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Thursday = thursdaydiffValue;
                 }
 
                 else if(tuesdaydiffValue > thursdaydiffValue){
                     tuesdaydiffValue = tuesdaydiffValue-thursdaydiffValue;
                     thursdaydiffValue = 0;
                     if(tuesdaydiffValue == 0){
                         this.nonbillable_timecard.Tuesday = 0;
                     }
                 }
 
                 if(fridaydiffValue >= tuesdaydiffValue && tuesdaydiffValue > 0 ){
                     this.nonbillable_timecard.Friday = 0;
                     this.nonbillable_timecard.Friday = this.original_timecard.Friday-this.modifytime_card.Friday;
                     this.nonbillable_timecard.Friday = this.nonbillable_timecard.Friday-tuesdaydiffValue;
                     fridaydiffValue = fridaydiffValue-tuesdaydiffValue;
                     tuesdaydiffValue = 0;
                 }
 
                 else if(fridaydiffValue > tuesdaydiffValue  && tuesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Friday = fridaydiffValue;
                 }
 
                 else if(tuesdaydiffValue >fridaydiffValue){
                     tuesdaydiffValue = tuesdaydiffValue - fridaydiffValue;
                     fridaydiffValue = 0;
                     if(tuesdaydiffValue == 0){
                         this.nonbillable_timecard.Tuesday = 0;
                     }
                 }
 
                 if(mondaydiffValue >= tuesdaydiffValue && tuesdaydiffValue > 0 ){
                     this.nonbillable_timecard.Tuesday = 0;
                     this.nonbillable_timecard.Monday = this.original_timecard.Monday - this.modifytime_card.Monday;
                     this.nonbillable_timecard.Monday = this.nonbillable_timecard.Monday - tuesdaydiffValue;
                     mondaydiffValue = mondaydiffValue - tuesdaydiffValue;
                     tuesdaydiffValue = 0;
                 }
                 else if(mondaydiffValue > tuesdaydiffValue  && tuesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Monday=mondaydiffValue;
                 }
 
                 else if(tuesdaydiffValue > mondaydiffValue){
                     tuesdaydiffValue = tuesdaydiffValue-mondaydiffValue;
                     mondaydiffValue = 0;
                     if(tuesdaydiffValue == 0){
                         this.nonbillable_timecard.Tuesday = 0;
                     }
                 }
 
             }
 
              if(this.original_timecard.Wednesday < maxdailyHours){
                 WednesdaydiffValue = Math.abs(WednesdaydiffValue);
                 
 
                 
 
                 if(thursdaydiffValue >= WednesdaydiffValue  && WednesdaydiffValue > 0  ){
                     this.nonbillable_timecard.Wednesday = 0;
                     this.nonbillable_timecard.Thursday = this.original_timecard.Thursday - this.modifytime_card.Thursday;
                     this.nonbillable_timecard.Thursday = this.nonbillable_timecard.Thursday - WednesdaydiffValue;
                     thursdaydiffValue = thursdaydiffValue - WednesdaydiffValue;
                     WednesdaydiffValue = 0;
                 }
 
                 else if(thursdaydiffValue > WednesdaydiffValue  && WednesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Thursday = thursdaydiffValue;
                 }
 
                 else if(WednesdaydiffValue > thursdaydiffValue){
                     WednesdaydiffValue = WednesdaydiffValue - thursdaydiffValue;
                     thursdaydiffValue = 0;
                     if(WednesdaydiffValue == 0){
                         this.nonbillable_timecard.Wednesday = 0;
                     }
                 }
 
                 if(fridaydiffValue >= WednesdaydiffValue && WednesdaydiffValue > 0 ){
                     console.log('fridaydiffValue'+fridaydiffValue);
                     this.nonbillable_timecard.Friday = 0;
                     this.nonbillable_timecard.Friday = this.original_timecard.Friday - this.modifytime_card.Friday; 
                     this.nonbillable_timecard.Friday = this.nonbillable_timecard.Friday - WednesdaydiffValue;
                     fridaydiffValue = fridaydiffValue - WednesdaydiffValue;
                     WednesdaydiffValue = 0;
                 }
 
                 else if(fridaydiffValue > WednesdaydiffValue  && WednesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Friday = fridaydiffValue;
                 }
 
                 else if(WednesdaydiffValue > fridaydiffValue){
                     WednesdaydiffValue = WednesdaydiffValue - fridaydiffValue;
                     fridaydiffValue = 0;
                     if(WednesdaydiffValue == 0){
                         this.nonbillable_timecard.Wednesday = 0;
                     }
                 }
 
                 if(mondaydiffValue >= WednesdaydiffValue && WednesdaydiffValue > 0 ){
                     this.nonbillable_timecard.Wednesday = 0;
                     this.nonbillable_timecard.Monday = this.original_timecard.Monday - this.modifytime_card.Monday;
                     this.nonbillable_timecard.Monday = this.nonbillable_timecard.Monday - WednesdaydiffValue;
                     mondaydiffValue = mondaydiffValue - WednesdaydiffValue;
                     WednesdaydiffValue = 0;
                 }
 
                 else if(mondaydiffValue > WednesdaydiffValue  && WednesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Monday = mondaydiffValue;
                 }
 
                 else if(WednesdaydiffValue > mondaydiffValue){
                     WednesdaydiffValue = WednesdaydiffValue - mondaydiffValue;
                     mondaydiffValue = 0;
                     if(WednesdaydiffValue == 0){
                         this.nonbillable_timecard.Wednesday = 0;
                     }
                 }

                 if(tuesdaydiffValue >= WednesdaydiffValue && WednesdaydiffValue > 0 ){
                     this.nonbillable_timecard.Wednesday = 0;
                     this.nonbillable_timecard.Tuesday = this.original_timecard.Tuesday - this.modifytime_card.Tuesday;
                     this.nonbillable_timecard.Tuesday = this.nonbillable_timecard.Tuesday - WednesdaydiffValue;
                     tuesdaydiffValue = tuesdaydiffValue - WednesdaydiffValue;
                     WednesdaydiffValue = 0;
                 }
 
                 else if(tuesdaydiffValue > WednesdaydiffValue  && WednesdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Tuesday = tuesdaydiffValue;
                 }
 
                 else if(WednesdaydiffValue > tuesdaydiffValue){
                     WednesdaydiffValue = WednesdaydiffValue - tuesdaydiffValue;
                     tuesdaydiffValue = 0;
                     if(WednesdaydiffValue == 0){
                         this.nonbillable_timecard.Wednesday = 0;
                     }
                 }
 
                 
 
             }
 
 
              if(this.original_timecard.Thursday < maxdailyHours){
                 thursdaydiffValue=Math.abs(thursdaydiffValue);
                 
                 if(fridaydiffValue >= thursdaydiffValue && thursdaydiffValue > 0 ){
                     this.nonbillable_timecard.Thursday = 0;
                     this.nonbillable_timecard.Friday = this.original_timecard.Friday - this.modifytime_card.Friday;
                     this.nonbillable_timecard.Friday = this.nonbillable_timecard.Friday - thursdaydiffValue;
                     fridaydiffValue = fridaydiffValue - thursdaydiffValue;
                     thursdaydiffValue = 0;
                 }
 
                 else if(fridaydiffValue > thursdaydiffValue  && thursdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Friday = fridaydiffValue;
                 }
 
                 else if(thursdaydiffValue > fridaydiffValue){
                     thursdaydiffValue = thursdaydiffValue - fridaydiffValue;
                     fridaydiffValue = 0;
                     if(thursdaydiffValue == 0){
                         this.nonbillable_timecard.Thursday = 0;
                     }
                 }
 
                 if(mondaydiffValue >= thursdaydiffValue && thursdaydiffValue > 0 ){
                     this.nonbillable_timecard.Thursday = 0;
                     this.nonbillable_timecard.Monday = this.original_timecard.Monday - this.modifytime_card.Monday;
                     this.nonbillable_timecard.Monday = this.nonbillable_timecard.Monday - thursdaydiffValue;
                     mondaydiffValue = mondaydiffValue - thursdaydiffValue;
                     thursdaydiffValue=0;
                 }
                 else if(mondaydiffValue > thursdaydiffValue  && thursdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Monday = mondaydiffValue;
                 }
 
                 else if(thursdaydiffValue > mondaydiffValue){
                     thursdaydiffValue = thursdaydiffValue - mondaydiffValue;
                     mondaydiffValue = 0;
                     if(thursdaydiffValue == 0){
                         this.nonbillable_timecard.Thursday = 0;
                     }
                 }
 
                 if(tuesdaydiffValue >= thursdaydiffValue && thursdaydiffValue > 0 ){
                     this.nonbillable_timecard.Thursday = 0;
                     this.nonbillable_timecard.Tuesday = this.original_timecard.Tuesday - this.modifytime_card.Tuesday;
                     this.nonbillable_timecard.Tuesday = this.nonbillable_timecard.Tuesday - thursdaydiffValue;
                     tuesdaydiffValue = tuesdaydiffValue - thursdaydiffValue;
                     thursdaydiffValue=0;
                 }
 
                 else if(tuesdaydiffValue > thursdaydiffValue  && thursdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Tuesday = tuesdaydiffValue;
                 }
 
                 else if(thursdaydiffValue > tuesdaydiffValue){
                     thursdaydiffValue = thursdaydiffValue - tuesdaydiffValue;
                     tuesdaydiffValue = 0;
                     if(thursdaydiffValue == 0 ){
                         this.nonbillable_timecard.Thursday = 0;
                     }
                 }
 
                 if(WednesdaydiffValue >= thursdaydiffValue  && thursdaydiffValue > 0  ){
                     this.nonbillable_timecard.Thursday = 0;
                     this.nonbillable_timecard.Wednesday = this.original_timecard.Wednesday - this.modifytime_card.Wednesday;
                     this.nonbillable_timecard.Wednesday = this.nonbillable_timecard.Wednesday - thursdaydiffValue;
                     WednesdaydiffValue = WednesdaydiffValue - thursdaydiffValue;
                     thursdaydiffValue = 0;
                 }
 
                 else if(WednesdaydiffValue > thursdaydiffValue  && thursdaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Wednesday = WednesdaydiffValue;
                 }
 
                 else if(thursdaydiffValue > WednesdaydiffValue){
                     thursdaydiffValue = thursdaydiffValue - WednesdaydiffValue;
                     WednesdaydiffValue = 0 ;
                     if(thursdaydiffValue == 0){
                         this.nonbillable_timecard.Thursday = 0;
                     }
                 }
 
             }
 
 
              if(this.original_timecard.Friday < maxdailyHours){
                 fridaydiffValue=Math.abs(fridaydiffValue);
                 
 
                 if(tuesdaydiffValue >= fridaydiffValue && fridaydiffValue > 0 ){
                     this.nonbillable_timecard.Friday = 0;
                     this.nonbillable_timecard.Tuesday = this.original_timecard.Tuesday - this.modifytime_card.Tuesday;
                     this.nonbillable_timecard.Tuesday = this.nonbillable_timecard.Tuesday - fridaydiffValue;
                     tuesdaydiffValue = tuesdaydiffValue - fridaydiffValue;
                     fridaydiffValue=0;
                 }
 
                 else if(tuesdaydiffValue > fridaydiffValue  && fridaydiffValue==0  ){
                     
                     this.nonbillable_timecard.Tuesday=tuesdaydiffValue;
                 }
 
                 else if(fridaydiffValue >tuesdaydiffValue){
                     fridaydiffValue = fridaydiffValue - tuesdaydiffValue;
                     tuesdaydiffValue = 0;
                     if(fridaydiffValue == 0){
                         this.nonbillable_timecard.Friday = 0;
                     }
                 }
 
                 if(WednesdaydiffValue >= fridaydiffValue  && fridaydiffValue>0  ){
                     this.nonbillable_timecard.Friday = 0;
                     this.nonbillable_timecard.Wednesday = this.original_timecard.Wednesday - this.modifytime_card.Wednesday;
                     this.nonbillable_timecard.Wednesday = this.nonbillable_timecard.Wednesday - fridaydiffValue;
                     WednesdaydiffValue = WednesdaydiffValue - fridaydiffValue;
                     fridaydiffValue = 0;
                 }
 
                 else if(WednesdaydiffValue > fridaydiffValue  && fridaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Wednesday = WednesdaydiffValue;
                 }
 
                 else if(fridaydiffValue > WednesdaydiffValue){
                     fridaydiffValue = fridaydiffValue - WednesdaydiffValue;
                     WednesdaydiffValue = 0;
                     if(fridaydiffValue == 0){
                         this.nonbillable_timecard.Friday = 0;
                     }
                 }
                 if(thursdaydiffValue >= fridaydiffValue && fridaydiffValue > 0 ){
                     this.nonbillable_timecard.Friday = 0;
                     this.nonbillable_timecard.Thursday = this.original_timecard.Thursday - this.modifytime_card.Thursday;
                     this.nonbillable_timecard.Thursday = this.nonbillable_timecard.Thursday - fridaydiffValue;
                     thursdaydiffValue = thursdaydiffValue - fridaydiffValue;
                     fridaydiffValue = 0;
                 }
 
                 else if(thursdaydiffValue > fridaydiffValue  && fridaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Thursday = thursdaydiffValue;
                 }
 
                 else if(fridaydiffValue > thursdaydiffValue){
                     fridaydiffValue = fridaydiffValue - thursdaydiffValue;
                     thursdaydiffValue = 0;
                     if(fridaydiffValue == 0){
                         this.nonbillable_timecard.Friday = 0;
                     }
                 }
 
                 if(mondaydiffValue >= fridaydiffValue && fridaydiffValue > 0 ){
                     this.nonbillable_timecard.Friday = 0;
                     this.nonbillable_timecard.Monday = this.original_timecard.Monday - this.modifytime_card.Monday;
                     this.nonbillable_timecard.Monday = this.nonbillable_timecard.Monday - fridaydiffValue;
                     mondaydiffValue = mondaydiffValue-  fridaydiffValue;
                     fridaydiffValue = 0;
                 }
 
                 else if(mondaydiffValue > fridaydiffValue  && fridaydiffValue == 0  ){
                     
                     this.nonbillable_timecard.Monday = mondaydiffValue;
                 }
 
                 else if(fridaydiffValue > mondaydiffValue){
                     fridaydiffValue = fridaydiffValue - mondaydiffValue;
                     mondaydiffValue = 0;
                     if(fridaydiffValue == 0){
                         this.nonbillable_timecard.Friday = 0;
                     }
                 }
 
 
             }
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
             this.nonbillable_timecard.totalHours=parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
             
         }
     
       
              
 
     }
 
     secondApprovehandler(event){
         this.modifyapprovalhandler()
         this.isModalConfirm = false;
         this.isModalOpenModify = false;
 
     }
 
     

     blurHandler(event){
         if(this.modifytime_card.Monday ==''){
            this.modifytime_card.Monday = 0;
            this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday); 
         }

         if(this.modifytime_card.Tuesday ==''){
            this.modifytime_card.Tuesday = 0;
            this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday); 
         }

         if(this.modifytime_card.Wednesday ==''){
            this.modifytime_card.Wednesday = 0;
            this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday); 
         }
         if(this.modifytime_card.Thursday ==''){
            this.modifytime_card.Thursday = 0;
            this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday); 
         }

         if(this.modifytime_card.Friday ==''){
            this.modifytime_card.Friday = 0;
            this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday); 
         }

         if(this.modifytime_card.Saturday ==''){
            this.modifytime_card.Saturday = 0;
            this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday); 
         }

         if(this.modifytime_card.Sunday ==''){
            this.modifytime_card.Sunday = 0;
            this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday); 
         }

         if(this.nonbillable_timecard.Monday ==''){
            this.nonbillable_timecard.Monday = 0;
            this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday); 
         }


        if(this.nonbillable_timecard.Tuesday ==''){
            this.nonbillable_timecard.Tuesday = 0;
            this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday); 
         }

         if(this.nonbillable_timecard.Wednesday ==''){
            this.nonbillable_timecard.Wednesday = 0;
            this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday); 
         }

         if(this.nonbillable_timecard.Thursday ==''){
            this.nonbillable_timecard.Thursday = 0;
            this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday); 
         }

         if(this.nonbillable_timecard.Friday ==''){
            this.nonbillable_timecard.Friday = 0;
            this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday); 
         }

         if(this.nonbillable_timecard.Saturday ==''){
            this.nonbillable_timecard.Saturday = 0;
            this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday); 
         }

         if(this.nonbillable_timecard.Sunday ==''){
            this.nonbillable_timecard.Sunday = 0;
            this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday); 
         }


     }


     changeHandler(event){
         let dayIndex = event.target.dataset.id;
         let dayValue = event.target.value;
         console.log('gfhgv');
         if(this.days.mon == dayIndex){
             this.modifytime_card.totalHours = 0;
             this.modifytime_card.Monday = dayValue;
             if(this.original_timecard.totalHours >=40){
                 
             this.nonbillable_timecard.Monday = this.original_timecard.Monday - this.modifytime_card.Monday;

             }
             
 
             this.nonbillable_timecard.totalHours = this.nonbillable_timecard.Monday + this.nonbillable_timecard.Tuesday + this.nonbillable_timecard.Wednesday + this.nonbillable_timecard.Thursday
                                                  + this.nonbillable_timecard.Friday + this.nonbillable_timecard.Saturday + this.nonbillable_timecard.Sunday;
 
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
         }
         if(this.days.tue == dayIndex){
             this.modifytime_card.totalHours = 0;
             this.modifytime_card.Tuesday = dayValue;

             if(this.original_timecard.totalHours >=40){
                 
             this.nonbillable_timecard.Tuesday = this.original_timecard.Tuesday - this.modifytime_card.Tuesday;

             }
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
 
 
             this.nonbillable_timecard.totalHours = this.nonbillable_timecard.Monday + this.nonbillable_timecard.Tuesday + this.nonbillable_timecard.Wednesday + this.nonbillable_timecard.Thursday
                                                  +this.nonbillable_timecard.Friday + this.nonbillable_timecard.Saturday + this.nonbillable_timecard.Sunday;
         }
         if(this.days.wed == dayIndex){
             this.modifytime_card.totalHours = 0;
             this.modifytime_card.Wednesday = dayValue;

             if(this.original_timecard.totalHours >=40){
                 
             this.nonbillable_timecard.Wednesday = this.original_timecard.Wednesday - this.modifytime_card.Wednesday;

             }
 
             this.nonbillable_timecard.totalHours = this.nonbillable_timecard.Monday + this.nonbillable_timecard.Tuesday + this.nonbillable_timecard.Wednesday + this.nonbillable_timecard.Thursday
                                                  + this.nonbillable_timecard.Friday + this.nonbillable_timecard.Saturday + this.nonbillable_timecard.Sunday;
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
         }
         if(this.days.thu == dayIndex){
             this.modifytime_card.totalHours = 0;
             this.modifytime_card.Thursday = dayValue;

             if(this.original_timecard.totalHours >=40){
                 
             this.nonbillable_timecard.Thursday = this.original_timecard.Thursday - this.modifytime_card.Thursday;

             }
             this.nonbillable_timecard.totalHours = this.nonbillable_timecard.Monday + this.nonbillable_timecard.Tuesday + this.nonbillable_timecard.Wednesday + this.nonbillable_timecard.Thursday
                                                  + this.nonbillable_timecard.Friday + this.nonbillable_timecard.Saturday + this.nonbillable_timecard.Sunday;
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
         }
         if(this.days.fri == dayIndex){
             this.modifytime_card.totalHours = 0;
             this.modifytime_card.Friday = dayValue;

            if(this.original_timecard.totalHours >=40){
                 
             this.nonbillable_timecard.Friday = this.original_timecard.Friday - this.modifytime_card.Friday;

             }
             this.nonbillable_timecard.totalHours = this.nonbillable_timecard.Monday + this.nonbillable_timecard.Tuesday + this.nonbillable_timecard.Wednesday + this.nonbillable_timecard.Thursday
                                                  + this.nonbillable_timecard.Friday + this.nonbillable_timecard.Saturday + this.nonbillable_timecard.Sunday;
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
         }
         if(this.days.sat == dayIndex){
             this.modifytime_card.totalHours = 0;
             this.modifytime_card.Saturday = dayValue;

             if(this.original_timecard.totalHours >=40){
                 
             this.nonbillable_timecard.Saturday = this.original_timecard.Saturday - this.modifytime_card.Saturday;

             }
 
             this.nonbillable_timecard.totalHours = this.nonbillable_timecard.Monday + this.nonbillable_timecard.Tuesday + this.nonbillable_timecard.Wednesday + this.nonbillable_timecard.Thursday
                                                  + this.nonbillable_timecard.Friday + this.nonbillable_timecard.Saturday + this.nonbillable_timecard.Sunday;
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday)+parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
         }
         if(this.days.sun == dayIndex){
             this.modifytime_card.totalHours = 0;
             this.modifytime_card.Sunday = dayValue;

             if(this.original_timecard.totalHours >=40){
                 
             this.nonbillable_timecard.Sunday = this.original_timecard.Sunday - this.modifytime_card.Sunday;

             }
 
 
             this.nonbillable_timecard.totalHours = this.nonbillable_timecard.Monday + this.nonbillable_timecard.Tuesday + this.nonbillable_timecard.Wednesday + this.nonbillable_timecard.Thursday
                                                  + this.nonbillable_timecard.Friday+this.nonbillable_timecard.Saturday + this.nonbillable_timecard.Sunday;
 
             this.modifytime_card.totalHours = parseFloat(this.modifytime_card.Monday) + parseFloat(this.modifytime_card.Tuesday) + parseFloat(this.modifytime_card.Wednesday) + parseFloat(this.modifytime_card.Thursday)
                                                  + parseFloat(this.modifytime_card.Friday) + parseFloat(this.modifytime_card.Saturday) + parseFloat(this.modifytime_card.Sunday);
         }
     }
 
     get disableRebalance() {
         return this.record[0].totalHours >= maxTotalHours ? false : true;
     }
 
 
     modifyapprovalhandler(){
         let modifiedList = [];
         modifiedList.push(this.modifytime_card);
         let nonbillableList = [];
         nonbillableList.push(this.nonbillable_timecard);
         
         this.showspinner=true;
           modifiedTimecards({modifydata:JSON.stringify(this.modifytime_card),nonbillabledata:JSON.stringify(this.nonbillable_timecard),modifyComment:this.comment})
             .then(result => {
                 console.log("approval called");
                 
                  this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Approved Succefully',
                        variant: 'success',
                    }),
                );
                eval("$A.get('e.force:refreshView').fire();");
                this.showspinner=false;
             })
             .catch(error => {
                 console.log(error);
                 this.dispatchEvent(
                     new ShowToastEvent({
                         title: 'Error creating record',
                         message: error.body.message,
                         variant: 'error',
                     }),
                 );
             });
     }
 
     nonbillablechangeHandler(event){
 
         let dayIndex=event.target.dataset.id;
         let dayValue=event.target.value;
 
         if(this.nonbillabledays.mon == dayIndex){

             this.nonbillable_timecard.totalHours = 0;
             this.nonbillable_timecard.Monday = dayValue;
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
 
         }
 
         if(this.nonbillabledays.tue == dayIndex){
             this.nonbillable_timecard.totalHours = 0;
             this.nonbillable_timecard.Tuesday = dayValue;
 
 
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  +parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
         }
 
         if(this.nonbillabledays.wed == dayIndex){
             this.nonbillable_timecard.totalHours = 0;
             this.nonbillable_timecard.Wednesday = dayValue;
 
 
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
         }
 
         if(this.nonbillabledays.thu == dayIndex){
             this.nonbillable_timecard.totalHours = 0;
             this.nonbillable_timecard.Thursday = dayValue;
 
 
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillabledays.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
         }
 
         if(this.nonbillabledays.fri == dayIndex){
             this.nonbillable_timecard.totalHours = 0;
             this.nonbillable_timecard.Friday = dayValue;
 
 
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
         }
 
         if(this.nonbillabledays.sat == dayIndex){
             this.nonbillable_timecard.totalHours = 0;
             this.nonbillable_timecard.Saturday = dayValue;
 
 
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
             
         }
 
         if(this.nonbillabledays.sun == dayIndex){
             this.nonbillable_timecard.totalHours = 0;
             this.nonbillable_timecard.Sunday = dayValue;
 
 
             this.nonbillable_timecard.totalHours = parseFloat(this.nonbillable_timecard.Monday) + parseFloat(this.nonbillable_timecard.Tuesday) + parseFloat(this.nonbillable_timecard.Wednesday) + parseFloat(this.nonbillable_timecard.Thursday)
                                                  + parseFloat(this.nonbillable_timecard.Friday) + parseFloat(this.nonbillable_timecard.Saturday) + parseFloat(this.nonbillable_timecard.Sunday);
             
         }
 
 
 
 
     }
 
 }