import { LightningElement } from 'lwc';

export default class FactDetailsAndComments extends LightningElement {}