import { LightningElement, track } from 'lwc';

export default class Onboarding_EmployeeInformation extends LightningElement {
    @track email = '';
    
    EmailInputChangeHandler(event) {
        console.log('hello');
        this.email = event.target.value;
        console.log(this.email);
    }
    LoginClickHandler(){
        
    }

}