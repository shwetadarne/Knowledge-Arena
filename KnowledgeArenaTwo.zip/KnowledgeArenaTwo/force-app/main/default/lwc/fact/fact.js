import { LightningElement,api,wire,track } from 'lwc';

export default class Fact extends LightningElement {
    @api factWrapper;
    updatedUpVote;
    updatedDownVote;
    updatedUpVoteFact;
    updatedDownVoteFact;
    commentForFact;
    
    openfactDetailAndComments=false;
    connectedCallback(){

        //comment count
    //     let newData= JSON.parse(JSON.stringify(this.factWrapper));
    //     this.factWrapper=newData;
    //     this.factCount();
    // }

    // factCount()
    // {
    // if(this.factWrapper.TotalAnswers>0){
    //     if(this.factWrapper.TotalAnswers===1){
    //         this.commentForFact=this.factWrapper.TotalAnswers+' Comment';
    //     }
    //     else{
    //         this.commentForFact=this.factWrapper.TotalAnswers+' Comments';
    //     }
    // }
    // else{
    //      this.commentForFact=' Uncommented';
    // }
    // }


    // totalAnswerCount
    // newCommentCount(event)
    // {
    //     console.log(event);
    //     this.totalAnswerCount=event.detail;
    //     console.log('event recieved from question answer for new answer count',this.totalAnswerCount);
    //     this.factWrapper.TotalAnswers=this.totalAnswerCount;
    //     console.log('Total answers',this.factWrapper.TotalAnswers)
       
    //     this.factCount();
        
    }

    cardOnClickHandler(event){
        if(this.openfactDetailAndComments===true){
            this.openfactDetailAndComments=false;
        }
        else{
            this.openfactDetailAndComments=true;
        }
        event.currentTarget.parentElement.classList.toggle('slds-open')
        
    }
    handleUpVoteMessage(event){
        this.updatedUpVote=event.detail.value;
        let newData= JSON.parse(JSON.stringify(this.factWrapper));
        newData.AnswerDetailsWrapper=this.updatedUpVote;
        console.log(this.updatedUpVote);
        this.factWrapper=newData; 
    
    }
    handleDownVoteMessage(event){
        this.updatedDownVote=event.detail.value;
        let newData= JSON.parse(JSON.stringify(this.factWrapper));
        newData.AnswerDetailsWrapper=this.updatedDownVote;
        this.factWrapper=newData; 
        console.log(this.updatedUpVote);
    }
    handleUpVoteFactMessage(event){
        this.updatedUpVoteFact=event.detail.value;
        let newData= JSON.parse(JSON.stringify(this.factWrapper));
        newData=this.updatedUpVoteFact;
        this.factWrapper=newData; 
        console.log(this.updatedUpVoteFact);


    }
    handleDownVoteFactMessage(event){
        this.updatedDownVoteFact=event.detail.value;
        let newData= JSON.parse(JSON.stringify(this.factWrapper));
        newData=this.updatedDownVoteFact;
        this.factWrapper=newData; 
        console.log(this.updatedDownVoteFact);

    }


}