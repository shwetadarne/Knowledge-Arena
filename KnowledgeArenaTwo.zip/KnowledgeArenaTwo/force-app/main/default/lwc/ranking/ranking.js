import { LightningElement } from 'lwc';

export default class Ranking extends LightningElement {}