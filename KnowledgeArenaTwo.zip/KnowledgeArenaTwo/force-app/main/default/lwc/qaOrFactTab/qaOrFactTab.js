import { LightningElement } from 'lwc';

export default class QaOrFactTab extends LightningElement {}