import { LightningElement, track, api } from 'lwc';
import createWeeklyStatusReport from '@salesforce/apex/GenerateWSRCtrl.createWeeklyStatusReport';
import checkWsrExists from '@salesforce/apex/GenerateWSRCtrl.checkWsrExists';
import { CloseActionScreenEvent } from 'lightning/actions';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';

export default class GenerateWeeklyStatusReport extends NavigationMixin(LightningElement) {

    error;
    _recordId;
    @track firstday;
    @track lastday;
    @api isLoaded = false;
    @api recordId;
    @track retrievedRecordId = false;
    

    renderedCallback() {

        if (!this.retrievedRecordId && this.recordId) {
            this.retrievedRecordId = true;
            checkWsrExists({ projectRecordId: this.recordId })
                .then(result => {

                    if (result.status == 'error') {
                        this.showToast(result.message, result.status);
                        this.dispatchEvent(new CloseActionScreenEvent());
                    } else {
                        var curr = new Date; // get current date

                        var first = curr.getDate() - curr.getDay() + 1; // First day is the day of the month - the day of the week + 1 to get monday
                        var last = first + 6; // last day is the first day + 6

                        this.firstday = new Date(curr.setDate(first)).toDateString();
                        this.lastday = new Date(curr.setDate(last)).toDateString();
                    }
                    this.isLoaded = !this.isLoaded;
                })
                .catch(error => {
                    this.error = error;
                    this.showToast(error, 'error');
                });
        }

    }

    closeModal() {
        this.dispatchEvent(new CloseActionScreenEvent());
    }

    submitDetails() {

        createWeeklyStatusReport({ projectRecordId: this.recordId })
            .then(result => {
                console.log(result.createdWsrId);

                this.showToast(result.message, result.status);
                if (result.status == 'success') {
                    this[NavigationMixin.Navigate]({
                        type: 'standard__recordPage',
                        attributes: {
                            recordId: result.createdWsrId,
                            objectApiName: 'Weekly_Status_Report__c',
                            actionName: 'view'
                        }
                    });
                }

                this.dispatchEvent(new CloseActionScreenEvent());
            })
            .catch(error => {
                this.error = error;
                this.showToast(error, 'error');
            });
    }

    showToast(title, variant) {
        const event = new ShowToastEvent({
            title: title,
            variant: variant
        });
        this.dispatchEvent(event);
    }
}