import { LightningElement,api,track } from 'lwc';
import getAllInfoForHomeTab from '@salesforce/apex/HomeTabController.getAllInfoForHomeTab';
import questionDetails from '@salesforce/apex/MyQuestionDetails.questionDetails';
export default class Leaderboard extends LightningElement {
    isShowleaderBoard=false;
    @api
    leaderboarddata;
    @track
    rankingDetails;
    @track
    factheader;
    @track
    isLoaded=false;
    @track
    heroName;
    @track
    secondHero;
    @track
    thirdHero;
    @track
    heroNameimg;
    @track
    secondHeroimg;
    @track
    thirdHeroimg;
    @track
    weekList;
    @track
    MonthList;
    @track
    factOf=' Fact of the week:';
    @track
    heroOf='Hero of the week:';
    @track
    factId;
    myQuestion;
    myVar;
    from=false;
    @track
    wselect='brand';
    @track
    mselect;
    heroOfweekMonthImg;
    openActivityModal=false;
    leaderBoardHandler(){
        this.weekList=this.rankingDetails.rankinfo.weekRanklist;
        this.MonthList=this.rankingDetails.rankinfo.monthRanklist;
        this.isShowleaderBoard=true;
    }
    callpasstoparent(event)
    {
        console.log('isShowleaderBoard');
        console.log(this.isShowleaderBoard);
        this.isShowleaderBoard=false;
        console.log(this.isShowleaderBoard);
        this.openActivityModal=false;
    }
    connectedCallback(){
        console.log('abcd');
        getAllInfoForHomeTab()
        .then(result => {
                                this.rankingDetails = result.successRespObj;
                                console.log(this.rankingDetails);
                                this.factheader=this.rankingDetails.rankinfo.factOfWeek;
                                this.factId=this.rankingDetails.rankinfo.factOfWeekId;
                                this.heroName=this.rankingDetails.rankinfo.weekRanklist[0].name;
                                this.secondHero=this.rankingDetails.rankinfo.weekRanklist[1].name;
                                this.thirdHero=this.rankingDetails.rankinfo.weekRanklist[2].name;
                                this.heroNameimg=this.rankingDetails.rankinfo.weekRanklist[0].profileImg;
                                this.secondHeroimg=this.rankingDetails.rankinfo.weekRanklist[1].profileImg;
                                this.thirdHeroimg=this.rankingDetails.rankinfo.weekRanklist[2].profileImg;
                                this.heroOfweekMonthImg=this.rankingDetails.rankinfo.weekRanklist[0].profileImg;
                                console.log(this.factheader);
                             console.log('result '+this.rankingDetails.rankinfo.weekRanklist[0].profileImg);
        })
        .catch(error => {
            console.log()
        });
                    // console.log('resultt'+this.userDetails);
                    // console.log('w'+this.userDetails.user);
    }
    weeklyClickHandler()
    {
                    this.wselect='brand';
                    this.mselect='';
                    this.isShowleaderBoard=false;
                    console.log('week '+this.isShowleaderBoard);
                    this.factOf='Fact of the week:';
                    this.heroOf='Hero of the week:';
                    this.factheader=this.rankingDetails.rankinfo.factOfWeek;
                    this.factId=this.rankingDetails.rankinfo.factOfWeekId;
                    console.log(this.factId);
                    this.heroName=this.rankingDetails.rankinfo.weekRanklist[0].name;
                    this.secondHero=this.rankingDetails.rankinfo.weekRanklist[1].name;
                    this.thirdHero=this.rankingDetails.rankinfo.weekRanklist[2].name;
                    this.heroNameimg=this.rankingDetails.rankinfo.weekRanklist[0].profileImg;
                    this.secondHeroimg=this.rankingDetails.rankinfo.weekRanklist[1].profileImg;
                    this.thirdHeroimg=this.rankingDetails.rankinfo.weekRanklist[2].profileImg;
                    this.heroOfweekMonthImg=this.rankingDetails.rankinfo.weekRanklist[0].profileImg;
    }
    MonthlyClickHandler()
    {
                    this.wselect='';
                    this.mselect='brand';
                    this.isShowleaderBoard=false;
                    this.factOf='Fact of the month:';
                    this.heroOf='Hero of the month:';
                    this.factheader=this.rankingDetails.rankinfo.factOfMonth;
                    this.factId=this.rankingDetails.rankinfo.factOfMonthId;
                    this.heroName=this.rankingDetails.rankinfo.monthRanklist[0].name;
                    this.secondHero=this.rankingDetails.rankinfo.monthRanklist[1].name;
                    this.thirdHero=this.rankingDetails.rankinfo.monthRanklist[2].name;
                    this.heroNameimg=this.rankingDetails.rankinfo.monthRanklist[0].profileImg;
                    this.secondHeroimg=this.rankingDetails.rankinfo.monthRanklist[1].profileImg;
                    this.thirdHeroimg=this.rankingDetails.rankinfo.monthRanklist[2].profileImg;
                    this.heroOfweekMonthImg=this.rankingDetails.rankinfo.weekRanklist[0].profileImg;
    }
    factheaderHandler(event){
       this.isLoaded=true;
        questionDetails({ recId:event.currentTarget.dataset.id})
        .then(result => {
            this.myQuestion=JSON.stringify(result);
            this.isLoaded=false;
            this.openActivityModal=true;
            console.log(this.openActivityModal);
            console.log('here');
            console.log(this.myQuestion);
            // this.myVar = {
            //     author: this.myQuestion.author
            // };
        })
        .catch(error => {
            console.log()
        });
    }
    passToParent(event)
    {
        console.log('false');
        this.isShowleaderBoard=false;
    }
}