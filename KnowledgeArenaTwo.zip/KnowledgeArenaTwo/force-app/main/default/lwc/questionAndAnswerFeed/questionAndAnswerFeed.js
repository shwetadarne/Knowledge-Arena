import { LightningElement, track,api,wire } from 'lwc';
import insertUserDetails from '@salesforce/apex/enterQuestionDetails.insertUserDetails';
import getUserDetails from '@salesforce/apex/enterQuestionDetails.getUserDetails';
import getTag from '@salesforce/apex/enterQuestionDetails.getTag';
import allTagList from '@salesforce/apex/enterQuestionDetails.getAllTags';
import getAllQuestionsForTag from '@salesforce/apex/enterQuestionDetails.getAllQuestionsForTag';
import {CurrentPageReference} from 'lightning/navigation'
import { fireEvent } from 'c/pubsub';
import { registerListener,unregisterAllListeners } from 'c/pubsub';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Category__c from '@salesforce/schema/Question__c.Category__c';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Question_OBJECT from '@salesforce/schema/Question__c';
export default class QuestionAndAnswerFeed extends LightningElement {

   isShowModal=false;
    @track
    askedSubQuestion;
    @track
    askedQuestion;
    description;
    postedQuestion;
    postedSubQuestion;
    @track
    QAValue;
    HomeValue;
    FactValue;
    allQuestions;
    @track
    QuestionFeed=[];
    searchedRecords=[];
    searchedFactRecords=[];
    recordId;
    onlySearchedQuestion=[];
    onlySearchedFact=[];
    giveAnswerOpenModal;
    publisherName;
    qList;
    allTags;
    @api payload;
    @wire(CurrentPageReference)pageRef;

    isShowqaTab=false;
    isShowHomeTab=false;
    isShowFactTab=false;
    hasSearchResults=false;
    allTagsForQuestion;
    questionIdForTags;
    allQueBaseOnTag;
    tagggggggggg=true;
    showTages=false;

connectedCallback(){
//      registerListener("tabEvent",this.QATab,this);
//      registerListener("tabEventHome",this.homeTab,this);
//     registerListener("tabEventFact",this.factTab,this);
 }
QATab(eventData){
    this.QAValue=eventData;
    console.log('this home tab value  '+this.QAValue);
    if(this.QAValue=='tab-2'){
        this.isShowqaTab=true;
        console.log('value:'+this.isShowqaTab);
        this.isShowHomeTab=false;
        this.isShowFactTab=false;
    }

}
homeTab(eventData){
    this.HomeValue=eventData;
    console.log('this home tab value  '+this.HomeValue);
    if(this.HomeValue=='tab-1'){
        this.isShowHomeTab=true;
        console.log('value:'+this.isShowHomeTab);
        this.isShowqaTab=false;
        this.isShowFactTab=false;
    }
}
factTab(eventData){
    this.FactValue=eventData;
    console.log('this home tab value  '+this.FactValue);
    if(this.FactValue=='tab-3'){
        this.isShowFactTab=true;
        console.log('value:'+this.isShowFactTab);
        this.isShowqaTab=false;
        this.isShowHomeTab=false;
    }

}
 showModal(event){
        this.isShowModal=true;
    }
   hideModalBox() {  
       this.isShowModal = false;
    }
     
   postClick(){
        this.isShowModal = false;
        this.category=this.selecteCat;
        this.postedSubQuestion=this.askedSubQuestion;
        this.description=this.askedQuestion;
        this.pickListTag2=this.pickListTag;
        console.log(this.postedSubQuestion);
        console.log(this.description);
        this.clickHandler();
    }

     clickHandler(){
     console.log('creating question')
     insertUserDetails({sub:this.postedSubQuestion,main:this.description,tag:this.pickListTag2,cat:this.category})
        .then(result=>{
            
          console.log('in result');
          console.log(result);
     })
     .catch(error=>{
          console.error(error);
      })
   }
   
    getFeed(){
        getUserDetails()
        .then(result=>{
            this.allQuestions=result;

            console.log('all questionssssssss  '+this.allQuestions[0].Tags__c);
            for(let  i=0;i<this.allQuestions.length;i++)
            {
                console.log('all question ids  '+this.allQuestions[i].Tags__c);
            }
            // this.learningPathContactValues = result.map(tagsOfQuestion => {
            //                 return{...tagsOfQuestion, allTagsForQue: tagsOfQuestion.Tags__c,}
                                
            //             })
            
     })
     .catch(error=>{
          console.error(error);
      })  
   }
    giveAnswerClick(event){
      
        this.recordId=event.target.value;
        console.log('the id'+this.recordId);
        this.payload=this.recordId;
        this.giveAnswerOpenModal=true;
        fireEvent(this.pageRef,"AnswerOpenModal",this.giveAnswerOpenModal);
        fireEvent(this.pageRef,"userPublisher",this.payload);

   }


//    publisherOnClick(event){
//     this.publisherName=event.target.id;
//     this.payload=this.publisherName;
//     console.log('publisher id  '+this.publisherName);
//     fireEvent(this.pageRef,"Publisher",this.payload);

//    }
}