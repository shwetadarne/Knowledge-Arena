import { LightningElement } from 'lwc';

export default class Recent_Activity extends LightningElement {}