import { api, LightningElement, track } from 'lwc';
import pendingFactData from '@salesforce/apex/pendingApprovalFact.pendingFactData';
import getArticleDetails from '@salesforce/apex/QuestionDomain.getArticleDetails';


export default class PendingForApproval extends LightningElement {
    @api
    cat;
    @track
    factInfo;
    @track
    factInfoDetails;
    factDetailAndComments=false;
    openfactDetailAndComments=false;
    openfactDetailAndComments1=false;
    openTakeActionModal=false;
    openQuestionDetail(){
        this.questionDetailAnswer=true;
    }
    cardOnClickHandler(){
        this.openfactDetailAndComments=true;
    }
    cardOnClickHandler1(){
        this.openfactDetailAndComments1=true;
    }
    takeActionHandler(event){
        getArticleDetails({recId:event.currentTarget.dataset.id})
        .then(result=>{
            this.factInfoDetails=result;
            this.openTakeActionModal=true;
           console.log(this.factInfoDetails.Id);       
        })
        .catch(error=>{
            console.log(error);
        });
    }
    passToParent(event)
    {
        console.log(event.detail);
        this.openTakeActionModal=false; 
        if(event.detail)
        {
            pendingFactData({category:this.cat})
            .then(result=>{
               this.factInfo=result;
               console.log(this.factInfo);       
            })
            .catch(error=>{
                console.log(error);
            });
        }

    }
    connectedCallback()
    {
        pendingFactData({category:this.cat})
        .then(result=>{
           this.factInfo=result;
           console.log(this.factInfo);       
        })
        .catch(error=>{
            console.log(error);
        });
    }
}