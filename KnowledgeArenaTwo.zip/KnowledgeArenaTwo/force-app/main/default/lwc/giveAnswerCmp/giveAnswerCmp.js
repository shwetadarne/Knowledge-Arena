import { LightningElement, api, track, wire } from 'lwc';
import { CurrentPageReference } from 'lightning/navigation'
import { registerListener } from 'c/pubsub';

export default class GiveAnswerCmp extends LightningElement {
    countUp=0;
    countDown=0;
    answeredComment;
    comments;
    isShowVotes=false;
    @api
    openComment;
    @track
    ThankMsg
    handleUpvoteButtonClick(){
        this.countUp=this.countUp+1;
        console.log(this.countUp);
    }
    handleDownvoteButtonClick(){
        this.countDown=this.countDown+1;
        console.log(this.countDown);
    }
    commentCard(event){
        this.answeredComment=event.target.value;
    }
    commentHandleClick(){
        this.comments=this.answeredComment;
        this.isShowVotes=true;
        console.log('this is true');
        ThankMsg= 'Thank you for Your support !';
        
    }


    // ******************* for subsub calling
    viewMessage=false;
    @wire (CurrentPageReference)pageRef;
    connectedCallback(){
        registerListener("userPublisher",this.getUserDetails,this);
    }
   
    getUserDetails(data){
      this.viewMessage=data;
    //   viewMessage=this.result.name;
      console.log(data);
    }
    cancleHandler(event){
        this.viewMessage=false;
    }
}