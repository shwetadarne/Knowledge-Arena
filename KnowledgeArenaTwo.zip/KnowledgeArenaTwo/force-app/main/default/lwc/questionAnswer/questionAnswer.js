import { LightningElement, api, track, wire } from 'lwc';
//import insertUpVote from '@salesforce/apex/VoteDomain.insertUpVote';
//import insertDownVote from '@salesforce/apex/VoteDomain.insertDownVote';
import { deleteRecord } from 'lightning/uiRecordApi';
import { fireEvent } from 'c/pubsub';
import { CurrentPageReference } from 'lightning/navigation';
import VoteInsertion from '@salesforce/apex/QuestionTagController.VoteInsertion';
import insertAnswer from '@salesforce/apex/QuestionTagController.insertAnswerComments';
import updateBestAnswer from '@salesforce/apex/QuestionTagController.updateBestAnswer';
//import VoteVisibilityUpDown from '@salesforce/apex/QuestionTagController.VoteVisibilityUpDown';
import QuestionCategoryResponse from '@salesforce/apex/QuestionTagController.QuestionCategoryResponse';
//import getUpdatedCount from '@salesforce/apex/AnswerDomain.getUpdatedCount';
//import answerVotes from '@salesforce/apex/AnswerDomain.answerVotes';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import bonuslylogo from '@salesforce/resourceUrl/bonuslylogo';
export default class QuestionAnswer extends LightningElement {

    bonuslyLogoImg = bonuslylogo;
    isLoading = false;
    @api recordtype;
    @track
    copyOfans;
    @track
    qid;
    isShowCommentButton = false;
    isBonusly = false;
    typeOfVote;
    comment;
    qid;
    answerId;
    authorId;
    UpdatedVotes;
    newList;
    buttonDisableForBestAns;
    answerList;
    connectedanswerList;
    isLoaded = false;
    bestAnsButtonClick = false;
    count = 0;
    offSet = 0;
    @track visibilityOfVotes;
    factList;
    questionId;
    factVotes;
    index = 0;
    newListForbtAns = [];
    @track onlyOneAnswer;
    @track bestAnswerList = [];
    readonly=true;
    //from parent
    @track answerWrapper;
    @track sortedUpVotes;
    @api get allAnswers() {
        console.log('All comments', this.answerWrapper)
        return this.answerWrapper;
    }

    set allAnswers(value) {
        this.answerWrapper = { ...value };
        console.log('Setter all commenst', this.answerWrapper);
    }


    commentCard(event) {
        this.isShowCommentButton = true;
        this.comment = event.target.value;
    }


    connectedCallback() {
        //console.log('--Before the answer wrapper');

        //console.log(JSON.parse(JSON.stringify(this.answerWrapper)));
        this.copyOfans = JSON.parse(JSON.stringify(this.answerWrapper));
        let CUserId = this.copyOfans.CurrentUserId;
        let AuthorIdOfQue = JSON.stringify(this.answerWrapper.AuthorId);
        let UserId=JSON.stringify(this.answerWrapper.CurrentUserId);

        this.copyOfans.AnswerDetailsWrapper.sort((a, b) => b.upVotes - a.upVotes);

        for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
            console.log(this.copyOfans.AnswerDetailsWrapper[i].answeredBy);
            if (this.copyOfans.AnswerDetailsWrapper[i].answeredBy == CUserId) {
                this.copyOfans.AnswerDetailsWrapper[i].isDisabled = true;

            }
            else {
                this.copyOfans.AnswerDetailsWrapper[i].isDisabled = false;

            }
            if ((this.copyOfans.AnswerDetailsWrapper[i].upVotes == null) && (this.copyOfans.AnswerDetailsWrapper[i].downVotes == null)) {
                this.copyOfans.AnswerDetailsWrapper[i].upVotes = 0;
                this.copyOfans.AnswerDetailsWrapper[i].downVotes = 0;
            }
            if (this.copyOfans.AnswerDetailsWrapper[i].bestAnswer == true) {
                this.bestAnswerList[0] = this.copyOfans.AnswerDetailsWrapper[i];
                this.index = i;
            }

        }
        if (this.copyOfans.isQuestion == true && this.bestAnswerList.length > 0 && this.bestAnswerList[0].bestAnswer == true) {
            for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
                if (i != this.index) {
                    this.bestAnswerList.push(this.copyOfans.AnswerDetailsWrapper[i]);
                }
            }
            this.copyOfans.AnswerDetailsWrapper = this.bestAnswerList;
        }
        if (AuthorIdOfQue == UserId) {
            if (this.copyOfans.AnswerDetailsWrapper.length > 0 && this.copyOfans.AnswerDetailsWrapper[0].bestAnswer == true) {
                this.buttonDisableForBestAns = true;
            }
            else {
                this.buttonDisableForBestAns = false;
            }
        }
        else {
            this.buttonDisableForBestAns = true;
        }

        if ((this.copyOfans.upVotes == null) && (this.copyOfans.downVotes == null)) {
            this.copyOfans.upVotes = 0;
            this.copyOfans.downVotes = 0;
        }
        if (this.copyOfans.AuthorId == CUserId) {
            this.copyOfans.isDisabled = true;
        }
        else {
            this.copyOfans.isDisabled = false;
        }

    }

    BonuslyOnClickHandler(event) {
        this.authOrEmail = event.currentTarget.dataset.email;
        this.qid = event.currentTarget.dataset.id;
        console.log('this.qid' + this.qid);
        this.isBonusly = true;
    }
    passToParent(event) {
        console.log('false');
        this.isBonusly = false;

    }
    questionId;
    handleUpvoteButtonClick(event) {
        this.answerId = event.target.value;
        console.log('--After answerId', this.answerId);
        this.authorId = event.currentTarget.dataset.author;
        this.questionId = event.currentTarget.dataset.quesid;
        console.log('question', this.questionId);
        console.log('authorId', this.authorId);
        this.isLoading = true;
        //vote visibilty
        if(this.answerId!=null && this.questionId!=null){
        VoteInsertion({ TypeOfVote: 'up', answerOrFactId: this.answerId, ansOrFact: 'answer', questionOfAnswer: this.questionId})
            .then(result => {
                //this.answerWrapper.AnswerDetailsWrapper.voteDetailList=JSON.parse(JSON.stringify(result.successRespObj));
                console.log(result);
                this.visibilityOfVotes = result.successRespObj;
                // console.log('this.visibilityOfVotes Up');
                console.log(result.successRespObj);
                console.log(this.visibilityOfVotes);
                this.isLoading = false;
                this.answerList = JSON.parse(JSON.stringify(this.copyOfans.AnswerDetailsWrapper));


                console.log('before');
                console.log(this.copyOfans.AnswerDetailsWrapper);
                for (let i = 0; i < this.answerList.length; i++) {
                    if (this.answerId == this.answerList[i].ansId) {
                        if (this.visibilityOfVotes && this.visibilityOfVotes.answerId == this.answerList[i].ansId) {
                            console.log('Inside if');
                            this.answerList[i].isUpVote = true;
                            this.answerList[i].isDownVote = false;
                            this.answerList[i].isDisabled = false;
                            this.answerList[i].upVotes = this.visibilityOfVotes.updatedUpVote;
                            this.answerList[i].downVotes = this.visibilityOfVotes.updatedDownVote;
                            console.log('new updated vote' + this.answerList[i].upVotes);
                            console.log('new updated vote' + this.answerList[i].downVotes);
                            this.copyOfans.AnswerDetailsWrapper[i] = this.answerList[i];
                            console.log('after');
                            console.log(this.copyOfans.AnswerDetailsWrapper[i]);
                            console.log(this.answerList[i]);

                        }
                        else {
                            console.log('Inside else');
                            this.answerList[i].isUpVote = false;
                            this.answerList[i].isDownVote = false;
                            this.answerList[i].isDisabled = false;
                            this.answerList[i].upVotes = this.visibilityOfVotes.updatedUpVote;
                            this.answerList[i].downVotes = this.visibilityOfVotes.updatedDownVote;
                            console.log('new updated vote' + this.answerList[i].upVotes);
                            console.log('new updated vote' + this.answerList[i].downVotes);
                            this.copyOfans.AnswerDetailsWrapper[i] = this.answerList[i];
                        }
                    }
                }

                console.log(this.answerList);
                let handleVoteUpEvent = new CustomEvent('upvotemessage', {
                    detail: {
                        value: this.copyOfans.AnswerDetailsWrapper
                    },
                    bubbles: true,
                    composed: true
                });
                this.dispatchEvent(handleVoteUpEvent);

            })
            .catch(error => {
                console.log(error);
                this.isLoading = false;
            })
        }
        //get the votes

    }
    handleDownvoteButtonClick(event) {

        this.answerId = event.target.value;
        this.authorId = event.currentTarget.dataset.author;
        this.questionId = event.currentTarget.dataset.quesid;
        console.log('--After authorId', this.authorId);
        console.log('question', this.questionId);
        this.isLoading = true;
        if(this.answerId!=null && this.questionId!=null){
        VoteInsertion({ TypeOfVote: 'down', answerOrFactId: this.answerId, ansOrFact: 'answer', questionOfAnswer: this.questionId })
            .then(result => {
                console.log(result);
                //this.answerWrapper.AnswerDetailsWrapper.voteDetailList=JSON.parse(JSON.stringify(result.successRespObj));
                console.log('this.visibilityOfVotes');
                this.visibilityOfVotes = result.successRespObj;
                console.log(result.successRespObj);
                this.isLoading = false;
                this.answerList = JSON.parse(JSON.stringify(this.answerWrapper.AnswerDetailsWrapper));
                for (let i = 0; i < this.answerList.length; i++) {
                    if (this.answerId == this.answerList[i].ansId) {
                        if (this.visibilityOfVotes.answerId == this.answerList[i].ansId) {
                            this.answerList[i].isUpVote = false;
                            this.answerList[i].isDownVote = true;
                            this.answerList[i].isDisabled = false;
                            this.answerList[i].downVotes = this.visibilityOfVotes.updatedDownVote;
                            this.answerList[i].upVotes = this.visibilityOfVotes.updatedUpVote;
                            this.copyOfans.AnswerDetailsWrapper[i] = this.answerList[i];
                            // console.log('after');
                            // console.log(this.copyOfans.AnswerDetailsWrapper[i]);
                            // console.log(this.answerList[i]);
                            console.log('new updated vote' + this.answerList[i].upVotes);
                            console.log('new updated vote' + this.answerList[i].downVotes);
                        }
                        else {
                            console.log('Inside else');
                            this.answerList[i].isUpVote = false;
                            this.answerList[i].isDownVote = false;
                            this.answerList[i].isDisabled = false;
                            this.answerList[i].downVotes = this.visibilityOfVotes.updatedDownVote;
                            this.answerList[i].upVotes = this.visibilityOfVotes.updatedUpVote;
                            this.copyOfans.AnswerDetailsWrapper[i] = this.answerList[i];
                            console.log('new updated vote' + this.answerList[i].upVotes);
                            console.log('new updated vote' + this.answerList[i].downVotes);
                        }
                    }
                }
                let handleVoteDownEvent = new CustomEvent('downvotemessage', {
                    detail: {
                        value: this.copyOfans.AnswerDetailsWrapper
                    },
                    bubbles: true,
                    composed: true
                });
                this.dispatchEvent(handleVoteDownEvent);

            })
            .catch(error => {
                console.log(error);
                this.isLoading = false;
            })
        }




    }
    handleUpvoteFactButtonClick(event) {
        this.questionId = event.target.value;
        this.isLoading = true;
        if(this.questionId!=null){
        VoteInsertion({ TypeOfVote: 'up', answerOrFactId: this.questionId, ansOrFact: 'fact' })
            .then(result => {
                console.log(result);
                this.factVotes = result.successRespObj;
                this.isLoading = false;
                console.log(this.factVotes);
                this.factList = JSON.parse(JSON.stringify(this.copyOfans));
                console.log(this.factList);
                if (this.factVotes.questionId) {
                    this.factList.isUpVote = true;
                    this.factList.isDownVote = false;
                    this.factList.isDisabled = false;
                    this.factList.upVotes = this.factVotes.updatedUpVote;
                    this.factList.downVotes = this.factVotes.updatedDownVote;
                    console.log('new updated vote' + this.factList.upVotes);
                    console.log('new updated vote' + this.factList.downVotes);
                    this.copyOfans = this.factList;
                } else {
                    this.factList.isUpVote = false;
                    this.factList.isDownVote = false;
                    this.factList.isDisabled = false;
                    this.factList.upVotes = this.factVotes.updatedUpVote;
                    this.factList.downVotes = this.factVotes.updatedDownVote;
                    this.copyOfans = this.factList;
                    console.log(this.factList);
                }

                let handleVoteFactUpEvent = new CustomEvent('upvotefactmessage', {
                    detail: {
                        value: this.copyOfans
                    },
                    bubbles: true,
                    composed: true
                });
                this.dispatchEvent(handleVoteFactUpEvent);
                console.log(result);



            })
            .catch(error => {
                console.log(error);
                this.isLoading = false;
            })
        }
    }
    handleDownvoteFactButtonClick(event) {
        this.questionId = event.target.value;
        this.isLoading = true;
        if(this.questionId!=null){
        VoteInsertion({ TypeOfVote: 'down', answerOrFactId: this.questionId, ansOrFact: 'fact' })
            .then(result => {
                console.log(result);
                this.factVotes = result.successRespObj;
                this.isLoading = false;
                console.log(this.factVotes);
                this.factList = JSON.parse(JSON.stringify(this.copyOfans));
                console.log(this.factList);
                if (this.factVotes.questionId) {
                    this.factList.isUpVote = false;
                    this.factList.isDownVote = true;
                    this.factList.isDisabled = false;
                    this.factList.upVotes = this.factVotes.updatedUpVote;
                    this.factList.downVotes = this.factVotes.updatedDownVote;
                    console.log('new updated vote' + this.factList.upVotes);
                    console.log('new updated vote' + this.factList.downVotes);
                    this.copyOfans = this.factList;
                } else {
                    this.factList.isUpVote = false;
                    this.factList.isDownVote = false;
                    this.factList.isDisabled = false;
                    this.factList.upVotes = this.factVotes.updatedUpVote;
                    this.factList.downVotes = this.factVotes.updatedDownVote;
                    this.copyOfans = this.factList;
                    console.log(this.copyOfans);
                }
                let handleVoteFactDownEvent = new CustomEvent('downvotefactmessage', {
                    detail: {
                        value: this.copyOfans
                    },
                    bubbles: true,
                    composed: true
                });
                this.dispatchEvent(handleVoteFactDownEvent);
                console.log(result);

            })
            .catch(error => {
                console.log(error);
                this.isLoading = false;
            })
        }
    }
    voteInsertionFunc() {

    }
bestAnswernewList=[];
    BestAnswerHandler(event) {
        if (event.target.dataset.id) {
            for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
                if (event.target.dataset.id == this.copyOfans.AnswerDetailsWrapper[i].ansId) {
                    updateBestAnswer({ ansId: event.target.dataset.id, questionId: this.copyOfans.AnswerDetailsWrapper[i].quesId })
                        .then(result => {
                            // if (result.successRespObj.bestAnswer == true) {
                            //     this.copyOfans.AnswerDetailsWrapper[i].bestAnswer = true;
                            //     this.buttonDisableForBestAns = true;
                            //     let temp = this.copyOfans.AnswerDetailsWrapper[0];
                            //     this.copyOfans.AnswerDetailsWrapper[0] = this.copyOfans.AnswerDetailsWrapper[i];
                            //     this.copyOfans.AnswerDetailsWrapper[i] = temp;
                            // }

                            // **********************
                            if (result.successRespObj.bestAnswer == true) {
                                 this.copyOfans.AnswerDetailsWrapper[i].bestAnswer = true;
                                 this.buttonDisableForBestAns = true;
                                 this.bestAnswernewList[0] =this.copyOfans.AnswerDetailsWrapper[i];
                            }
                        })
                        .catch(error => {
                            console.log(error);
                        })
                }
            }
             if (this.copyOfans.isQuestion == true && this.bestAnswernewList.length > 0 && this.bestAnswernewList[0].bestAnswer == true) {
                for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
                    if (i != this.index) {
                        this.bestAnswernewList.push(this.copyOfans.AnswerDetailsWrapper[i]);
                    }
                }
                this.copyOfans.AnswerDetailsWrapper = this.bestAnswernewList;
                }


        }
    }






    isExpand = false;
    openModalForTag = false;
    expandOnClick() {
        this.isExpand = true;
        console.log('test' + categoryWrapper);
    }
    closeHandler() {
        this.isExpand = false;
    }




    ////inserting answer
    answer;
    @track buttonDisable = true;
    buttonDisableHandler(event) {

        this.answer = event.target.value;

        if (this.answer.length > 0) {
            this.buttonDisable = false;
        }
    }






    recordId;
    quesId;
    insertAnswerOnclick(event) {
        
        let tempAllAnswers;
        this.recordId = event.target.value;
        console.log('Question Id' + this.recordId);
        //this.quesId=event.currentTarget.dataset.quesId;
        
        insertAnswer({Ans:this.answer, recordId: this.recordId })
            .then(result => {
                tempAllAnswers = result.successRespObj;
                console.log(result);
                //this.answerWrapper.AnswerDetailsWrapper=[...tempAllAnswers];this is Saurabhs 
                this.copyOfans.AnswerDetailsWrapper.push(tempAllAnswers);

                console.log(this.copyOfans);
                let CUserId = this.copyOfans.CurrentUserId;
                let AuthorIdOfQue = JSON.stringify(this.answerWrapper.AuthorId);
                let UserId=JSON.stringify(this.answerWrapper.CurrentUserId);
                //this.copyOfans.AnswerDetailsWrapper.sort((a, b) => b.upVotes - a.upVotes);

                    let insertEvent = new CustomEvent('insertmessage',{
                    detail:  this.copyOfans
                    });
                    this.dispatchEvent(insertEvent);
                for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
                    console.log(this.copyOfans.AnswerDetailsWrapper[i].answeredBy);
                    if (this.copyOfans.AnswerDetailsWrapper[i].answeredBy == CUserId) {
                        this.copyOfans.AnswerDetailsWrapper[i].isDisabled = true;

                    }
                    else {
                        this.copyOfans.AnswerDetailsWrapper[i].isDisabled = false;

                    }
                    // if (this.copyOfans.AnswerDetailsWrapper[i].bestAnswer == true) {
                    //             this.bestAnswerList[0] = this.copyOfans.AnswerDetailsWrapper[i];
                    //             this.index = i;
                    //         }

                }
                // if (this.copyOfans.isQuestion == true && this.bestAnswerList.length > 0 && this.bestAnswerList[0].bestAnswer == true) {
                //     for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
                //         if (i != this.index) {
                //             this.bestAnswerList.push(this.copyOfans.AnswerDetailsWrapper[i]);
                //         }
                //     }
                //     this.copyOfans.AnswerDetailsWrapper = this.bestAnswerList;
                // }
                // // ***********************

                // for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
                //     console.log(this.copyOfans.AnswerDetailsWrapper[i].answeredBy);
                //     if (this.copyOfans.AnswerDetailsWrapper[i].answeredBy == CUserId) {
                //         this.copyOfans.AnswerDetailsWrapper[i].isDisabled = true;

                //     }
                //     else {
                //         this.copyOfans.AnswerDetailsWrapper[i].isDisabled = false;

                //     }
                //     if (this.copyOfans.AnswerDetailsWrapper[i].bestAnswer == true) {
                //         this.bestAnswerList[0] = this.copyOfans.AnswerDetailsWrapper[i];
                //         this.index = i;
                //     }

                // }
                // if (this.copyOfans.isQuestion == true && this.bestAnswerList.length > 0 && this.bestAnswerList[0].bestAnswer == true) {
                // for (let i = 0; i < this.copyOfans.AnswerDetailsWrapper.length; i++) {
                //     if (i != this.index) {
                //         this.bestAnswerList.push(this.copyOfans.AnswerDetailsWrapper[i]);
                //     }
                // }
                // this.copyOfans.AnswerDetailsWrapper = this.bestAnswerList;
                // }

            //*****************
                    if ((this.copyOfans.upVotes == null) && (this.copyOfans.downVotes == null)) {
                        this.copyOfans.upVotes = 0;
                        this.copyOfans.downVotes = 0;
                    }
                    if (this.copyOfans.AuthorId == CUserId) {
                        this.copyOfans.isDisabled = true;
                    }
                    else {
                        this.copyOfans.isDisabled = false;
                    }
               
                this.sendupdatedAnswerCount();

            })
            .catch(error => {
                console.error(error);
            })

        this.comment = null;
        this.handleClearInputField();

    }

    handleClearInputField() {
        this.template.querySelector('lightning-textarea').value = null;
    }


    @track newCount;
    sendupdatedAnswerCount() {
        console.log('event fired for updated count');
        this.newCount = this.copyOfans.AnswerDetailsWrapper.length;
        const selectedEvent = new CustomEvent("answervaluechange", {
            detail: this.newCount
        });

        this.dispatchEvent(selectedEvent);

    }

    //clickable tags and category
    selectedTag;
    tagRelatedQuestion;

    @track allComments1;
    isTagClicked;
    tagClickHandler(event) {
        this.isTagClicked=false;
                    let tagClickedEvent = new CustomEvent('tagclickmessage',{
                    detail:  this.isTagClicked
                    });
                    this.dispatchEvent(tagClickedEvent);
        let questionsBasedOnTags;
        this.isLoading = true;
        this.selectedTag = event.target.value;
        //this.selectedCategory = null;
        fireEvent(this.pageRef, 'selectTag', this.selectedTag);
       
    }


    CategoryClickHandler(event) {
        this.isTagClicked=false;
                    let tagClickedEvent = new CustomEvent('tagclickmessage',{
                    detail:  this.isTagClicked
                    });
                    this.dispatchEvent(tagClickedEvent);
        let questionsBasedOnTags;
        this.isLoading = true;
        this.selectedCategory = event.target.value;
        this.selectedTag = [];
        console.log('selectedCategory --', this.selectedCategory);
        fireEvent(this.pageRef, 'selectedCategory', this.selectedCategory);
        // if (this.selectedCategory != null)
        //     QuestionCategoryResponse({ searchArray: this.selectedTag, searchCategory: this.selectedCategory, recordType: this.recordtype, offSet: this.offSet })
        //         .then(result => {

        //             questionsBasedOnTags = [...result.successRespObj];
        //             fireEvent(this.pageRef, 'selectTag', questionsBasedOnTags);
                    
        //             //this.fireEventToParent();
        //             this.isLoading = false;

        //         })
        //         .catch(error => {
        //             console.log();
        //             this.isLoading = false;
        //         });
    }



    @wire(CurrentPageReference) pageRef;
    fireEventToParent() {
        fireEvent(this.pageRef, 'selectedCategoryTagEvent', this.allComments1);
    }




    ///edit and delete data
    get disableButton() {
        let noOfAnswer = this.answerWrapper.TotalAnswers;
        let bestAnswer = this.answerWrapper.AnswerDetailsWrapper.bestAnswer

        let newComments = this.answerWrapper;
        let AuthorIdOfQue = newComments.AuthorId;

        console.log('Author Id', AuthorIdOfQue);

        let UserId = newComments.CurrentUserId;
        console.log('User Id', UserId);
        let answeredId = newComments.AnswerDetailsWrapper.answeredBy;
        console.log('Answered By Id', answeredId);

        if (AuthorIdOfQue == UserId && noOfAnswer == 0) {

            return false;
        }

        else {
            return true;
        }
    }


    editRecord = true;
    @wire(CurrentPageReference) pageRef;
    editQuestionEvent() {
        this.editRecord = true;
        console.log('AllComments', this.answerWrapper);
        fireEvent(this.pageRef, 'editableData', this.answerWrapper);
        console.log('Event fired', JSON.stringify(this.answerWrapper));
    }


    //delete record
    @track error;
    recordDelete(event) {
        this.isTagClicked=false;
                    let tagClickedEvent = new CustomEvent('tagclickmessage',{
                    detail:  this.isTagClicked
                    });
                    this.dispatchEvent(tagClickedEvent);
        this.recordId = event.target.value;
        this.hideDeleteModalBox();
        console.log('Record Id', this.recordId);
        deleteRecord(this.recordId)
            .then(() => {
                const event = new ShowToastEvent({
                    message: 'Congrats, You have successfully deleted a question ',
                    variant: 'success',
                    mode: 'dismissable',
                });
                this.dispatchEvent(event);
                this.updateRecordView();

            })
            .catch(error => {
                // this.showNotificationError();
            });

        this.showNotificationSuccess();
    }


    msg;
    @wire(CurrentPageReference) pageRef;
    updateRecordView() {

        this.msg = 'Success';
        console.log('event fired');
        fireEvent(this.pageRef, 'getupdatedFeed', this.msg);
        this.dispatchEvent(updateEvent);
    }

    showNotificationSuccess() {
        const evt = new ShowToastEvent({
            title: 'Success',
            message: 'Question deleted',
            variant: 'success'
        });

    }

    showNotificationError() {

        const evt = new ShowToastEvent({
            title: 'Error deleting record',
            message: 'Error deleting record',
            variant: 'error'
        });
        this.dispatchEvent(evt);
    }



    answerEdit = false;
    editAnswerHandler(event) {
        this.answerEdit = true;
        let newComments = this.answerWrapper;
        let UserId = newComments.CurrentUserId;
        console.log('User Id', UserId);
        let answeredId = event.target.dataset.id;
        console.log('Answered By Id', answeredId);
        // if(UserId==answeredId)
        // {
        // this.answerEdit=true;
        // }
        // else{
        //     this.answerEdit=false;
        //     alert('You cannot edit others answer');
        // }
    }


    answerRecordId;

    updateAnswerOnclick(event) {

        this.answerRecordId = event.target.value;

        console.log('Question Id', answerRecordId);

    }



    @track isDeleteShowModal = false;

    showModalBox() {
        this.isDeleteShowModal = true;
    }

    hideDeleteModalBox() {
        this.isDeleteShowModal = false;
    }

}