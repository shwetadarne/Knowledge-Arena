import { LightningElement,api,wire,track} from 'lwc';
import { registerListener, unregisterAllListeners } from 'c/pubsub';

import { CurrentPageReference } from 'lightning/navigation';

export default class Question extends LightningElement {
    @api questionsWrapper;
    @api recordTypeName;
    newMessage;
   // @api messagefromparent;

    
    
    
    openQuestionAndAnswerDetail=false;
    data;
    authorIdOfQue;
    updatedUpVote;
    updatedDownVote;
    answerText;
    multianswerText;
    noAnswers;
    answerForQue;
    //TotalCount=0;


    connectedCallback()
    {
        
        let TotalCount=this.questionsWrapper.TotalAnswers;
        this.answerCount(TotalCount);

    }

    renderedCallback()
    {

        if(this.newMessage='Success')
        {
             let TotalCount=this.questionsWrapper.TotalAnswers;
             this.answerCount(TotalCount);
         }
         this.newMessage='';
    }

    handleTagClick(event){
    this.openQuestionAndAnswerDetail=event.detail;
    }

   answerCount(answerCount)
   {
   
    let TotalCount=answerCount;
    console.log('Counte after new question--',TotalCount);
    if(this.questionsWrapper.isQuestion==true)
    {
       this.answerText=' Answer';
       this.multianswerText=' Answers';
       this.noAnswers='Unanswered';
    }
    else
    {
       this.answerText=' Comment';
       this.multianswerText=' Comments';
       this.noAnswers='No comments';
   }

   if(TotalCount!=0)
   {
   
       console.log('TotalCount',TotalCount);
       if(TotalCount==1)
       {
           this.answerForQue=TotalCount+this.answerText;
           console.log(this.answerForQue);
       }
       else
       {
           this.answerForQue=TotalCount+this.multianswerText;
           console.log(this.answerForQue);
       }
   }
   else{
        
        this.answerForQue=this.noAnswers;
        console.log(this.answerForQue);
   }

   }



    get messagefromparent() {
        return this.newMessage;
    }

    set messagefromparent(value) {
       this.newMessage = value;
    }

    


   handleAnswerList(event){
        let data=event.detail;
        let newData= JSON.parse(JSON.stringify(this.questionsWrapper));
        newData=data;
        this.questionsWrapper=newData;
   }
        
    
 

   

    newCount;
    newAnswerCount(event)
    {
        this.answerForQue='';
        let totalAnswerCount=event.detail;
        console.log('Answer count--',totalAnswerCount);
        this.newCount=totalAnswerCount;
        //this.answerCount(this.newCount);
        this.answerForQue=totalAnswerCount+' Answers';
    
    }

   

    
    styleHandler(event){
        this.data=event.detail;
        console.log('dispatch value of data '+JSON.stringify(this.data));
        let newData= JSON.parse(JSON.stringify(this.questionsWrapper));
        newData.AnswerDetailsWrapper=this.data;
        this.questionsWrapper=newData; 
        console.log('questionwrapper '+JSON.stringify(this.questionsWrapper));

    }

    handleUpVoteMessage(event){
        this.updatedUpVote=event.detail.value;
        let newData= JSON.parse(JSON.stringify(this.questionsWrapper));
        newData.AnswerDetailsWrapper=this.updatedUpVote;
        console.log(this.updatedUpVote);
        this.questionsWrapper=newData; 

    }

    handleDownVoteMessage(event){
        this.updatedDownVote=event.detail.value;
        let newData= JSON.parse(JSON.stringify(this.questionsWrapper));
        newData.AnswerDetailsWrapper=this.updatedDownVote;
        this.questionsWrapper=newData; 
        console.log(this.updatedUpVote);
    }
    




    cardOnClickHandler(){
        //console.log(categoryWrapper)
        if(this.openQuestionAndAnswerDetail==true){
            this.openQuestionAndAnswerDetail=false;
        }
        else{
            this.openQuestionAndAnswerDetail=true;
        }
        
    }

}