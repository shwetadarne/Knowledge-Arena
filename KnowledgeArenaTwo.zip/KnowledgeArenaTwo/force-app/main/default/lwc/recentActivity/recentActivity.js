import { api, LightningElement, track } from 'lwc';
import getAllInfoForHomeTab from '@salesforce/apex/HomeTabController.getAllInfoForHomeTab';
import questionDetails from '@salesforce/apex/MyQuestionDetails.questionDetails';
export default class RecentActivity extends LightningElement {
   @track
   recentActivity;
   @api
   activitydata;
   myQuestion;
    isShowFact=false;
    openActivityModal=false;
    factHandler(){
       this.isShowFact=true;
    }
    connectedCallback(){
        //console.log('abcd');
        getAllInfoForHomeTab()
        .then(result => {
            //console.log('result'+result);
                        this.recentActivity = result.successRespObj.activity;
                        console.log(this.recentActivity);
                        // this.name=this.userDetails.user.name;
                        // this.img=this.userDetails.user.img;
                        // this.des=this.userDetails.user.Designation;
                        // this.email=this.userDetails.user.email;
        })
        .catch(error => {
            console.log()
        });
                    // console.log('resultt'+this.userDetails);
                    // console.log('w'+this.userDetails.user);
    }
    activitydetails(event){
        console.log('abc'+event.target.dataset.id);
        questionDetails({ recId:event.target.dataset.id })
        .then(result => {
            this.myQuestion=JSON.stringify(result);
            this.openActivityModal=true;
            console.log('abc');
            console.log(this.myQuestion);
        })
        .catch(error => {
            console.log()
        });
    }
    passToParent(event)
    {
        console.log('false');
        this.openActivityModal=false;
    }
}