import { LightningElement,track,wire } from 'lwc';
import QuestionTagMethods from '@salesforce/apex/QuestionTagController.QuestionTagMethods';
// import FactTagMethods from '@salesforce/apex/QuestionTagController.FactTagMethods';
import { loadStyle } from 'lightning/platformResourceLoader';
import knowledgeArena from '@salesforce/resourceUrl/knowledgeArena';
import getModeratorInfo from '@salesforce/apex/MetaDataDomain.getModeratorInfo';
import { publish,subscribe,MessageContext} from 'lightning/messageService';
import KnowledgeArena from '@salesforce/messageChannel/KnowledgeArena__c';


import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class Container extends LightningElement {
    

    //activeTab = 'home';
    moderatorInfo;
    isShowSearchTab=false;
    isShowApprovalTab=false;
    searchKeyWord;
    filterType;
    isCloseButton=false;
    isSearchActive=false;
    offSet=0;
    question='Question';
    fact='Fact';
    @wire(MessageContext)
    messageContext;


    @track activeTab='home';
    @track isLoading = false;

    @track searchRecords=[];
    @track searchRecordsFacts=[];
    @track recordCount;


    connectedCallback(){
        console.log('inside call');
        getModeratorInfo()
        .then(result=>{
           this.moderatorInfo=result;
           if(this.moderatorInfo)
           {
            this.isShowApprovalTab=true;
           
           }
        })
        .catch(error=>{
            console.log(error);
        });

        
    }
    removeSearchTab(){
        
        this.isShowSearchTab=false;
        this.activeTab='home';
    }




 
    isSearchTabOpen(event){
        
        console.log('isShowSearch'+event.detail.boolOpenClose);
        this.isShowSearchTab=event.detail.boolOpenClose;
        setTimeout(() => {
            this.activeTab = 'search';
        }, 100);
        
        //this.activeTab = 'search';
        console.log('In container'+event.detail.searchedWord);
        this.searchKeyWord=event.detail.searchedWord;
        this.filterType=event.detail.filter;
        console.log('In filter'+event.detail.filter)
    


        
        
        
        if(this.isShowSearchTab==true){
            console.log('searchWord'+this.searchKeyWord);
            console.log(this.filterType);
            this.searchRecords=[];
            this.isCloseButton=true;
            if(this.searchKeyWord!=null){
                this.isLoading=true;
                //how to force promises execution
                QuestionTagMethods({filterType:this.filterType,searchKey:this.searchKeyWord,offSet:this.offSet})
                .then(result=>{
                    console.log(result);
                    if(result.successRespObj && result.successRespObj.length > 0){
                        console.log(result.successRespObj);
                    this.searchRecords=result.successRespObj;
                    this.recordCount=this.searchRecords.length;
                    //call api function of child...update it's value in that func by passing this value
                    // console.log(this.recordCount);
                    // const payload = { recordCount: this.recordCount};

                    // publish(this.messageContext, KnowledgeArena, payload);
                    console.log('result'+this.searchRecords);
                    }
                    this.isLoading = false;
                
                })
                .catch(error=>{
                    console.log(error);
                    this.isLoading = false;
                });
                
            }
        }
        
            
    }
    
   
    renderedCallback(){
        Promise.all([
            loadStyle(this, knowledgeArena)
        ]);
        
    
    }
  

}