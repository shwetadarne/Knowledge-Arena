({
    noofkits : function(component, event, helper) {
        
        
        var kitprice = component.get("v.kitprice");
        var totalprice  = kitprice*component.get("v.donor.noofkits");
        component.set("v.totalAmount",totalprice);

    },
    init : function(component, event, helper) {
        component.set("v.kitprice",20);
        var donor = {noofkits:1, name:"", mobile:"", email:""};
        component.set("v.donor",donor);
        component.set("v.totalAmount",20);
      
    },
    handlepay: function(component, event, helper)
    {
        
    }
})